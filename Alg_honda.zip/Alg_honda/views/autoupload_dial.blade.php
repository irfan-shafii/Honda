@extends('layouts.master')
@section('title', 'Upload Auto Dial')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-sm-12">
                
                    <form  action="{{url('/autoupload/folder')}}" method="post" enctype="multipart/form-data">
                        {{csrf_field()}}
                    <section class="panel">
                        <header class="panel-heading">
                            Auto Dial Folder
                        </header>
                        <div class="panel-body">
                                <div class="form-group col-md-8">
                                    <label for="exampleInputEmail1">Folder Location</label>
                                    <input type="text" name="directory" value="{{$folder->location}}" class="form-control">
                                </div>
                                <div class="form-group col-md-4">
                                <button type="submit" class="form-control btn btn-success btn-block">Save</button>
                                </div>
                        </div>
                    </form>
                    </section>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-12">
                
                    <form  action="{{url('/autoupload/upload')}}" method="post" enctype="multipart/form-data">
                        {{csrf_field()}}
                    <section class="panel">
                        <header class="panel-heading">
                            Upload Auto Dial
                        </header>
                        @if (session('alert'))
                            <div class="alert alert-success fade in">
                                <button data-dismiss="alert" class="close close-sm" type="button">
                                    <i class="fa fa-times"></i>
                                </button>
                                <strong>Success!</strong> {{ session('alert') }}.
                            </div>
						@endif
                        <div class="panel-body">
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Campaign ID</label>
                                    <select class="form-control" name="campaignid" style="width: 300px" onChange="getlist(this);">
                                        <option value="">Select</option>
                                        @foreach($campaigns as $campaign)
                                        <option value="{{$campaign->campaign_id}}">{{$campaign->campaign_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">List ID</label>

                                    <select class="form-control" name="list1" style="width: 300px;" id="list1" onChange="getlistid(this);">
                                        <option value="">Select</option>
                                        @foreach($lists as $list)
                                        <option value="{{$list->list_id}}">{{$list->list_name}}</option>     
                                        @endforeach
                                    </select>
                                    @foreach($campaigns as $campaign)
                                    <select class="form-control" name="listid2" style="width: 300px;display: none;" id="list{{$campaign->campaign_name}}" onChange="getlistid(this);">
                                        <option value="">Select</option>
                                        <?php $inbounds = $lists->where('campaign_id',$campaign->campaign_name); ?>
                                        @foreach($inbounds as $list)
                                        <option value="{{$list->list_id}}">{{$list->list_name}}</option>
                                        @endforeach
                                    </select>
                                    @endforeach
                                </div>

                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Set Time</label>
                                <div class="col-md-12">
                                    <input size="16" type="text" value="{{date('Y-m-d H:i:s')}}" name="entry_date" id="entry_date"  class="form_datetime form-control">
                                </div>
                                </div>

                                <input type="hidden" name="listid" id="listid" value="0">
                                <input type="hidden" name="prevlistid" id="prevlistid" value="1">
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Choose File</label>
                                    <input type="file" name="import_file" class="form-control">
                                </div>
                                <div class="form-group col-md-4">
                                <button type="submit" class="form-control btn btn-success btn-block">Upload</button>
                                </div>
                                <div class="form-group col-md-4">
                                <a href="/centrix/public/test_number_format.csv" class="form-control btn btn-danger btn-block" download="">Download CSV Format</a>
                                </div>
                            </form>

                        </div>
                    </section>
            </div>
  
       
@stop
@section('ScriptPage')

<script type="text/javascript">
    function getlist(val) {
    var prevlist = document.getElementById("prevlistid").value;
    //alert(prevlist);
       document.getElementById("list"+prevlist).style.display = "none";
       var campaign = val.value;
       //alert(campaign);
       document.getElementById("list"+campaign).style.display = "block";
        document.getElementById("prevlistid").value = campaign;

    //alert(campaign);
    }
    function getlistid(val) {
       var listid = val.value;
       //alert(listid);
       document.getElementById("listid").value = listid;

    }
</script>


@stop
