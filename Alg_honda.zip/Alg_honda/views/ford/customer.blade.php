<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="ThemeBucket">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="shortcut icon" href="{{asset('/bucket')}}/images/favicon.html">

    <title>Customer Info page</title>


@include('layouts.css')

<style type="text/css">
  .form-control{
    color: #4c4a4a !important;
  }

a.ex2:hover, a.ex2:active {font-size: 150%;}


/* Paste this css to your style sheet file or under head tag */
/* This only works with JavaScript, 
if it's not present, don't show loader */
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url(http://i.stack.imgur.com/FhHRx.gif) center no-repeat #fff;
}
</style>

</head>

  <body class="full-width">

  <!-- Paste this code after body tag -->
  <div class="se-pre-con1"></div>
  <!-- Ends -->
  <section id="container" class="hr-menu">
      <!--header start-->
      <header class="header fixed-top">
          <div class="navbar-header">
              <button type="button" class="navbar-toggle hr-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span class="fa fa-bars"></span>
              </button>

              <!--logo start-->
              <!--logo start-->
              <div class="brand ">
                  <a href="#" class="logo">
                      <img src="http://subscriber.clgnote.in/assets/img/logo-full.png" alt="">
                  </a>
              </div>
              <!--logo end-->
              <!--logo end-->
              <div class="horizontal-menu navbar-collapse collapse ">

              </div>
              <div class="top-nav hr-top-nav">
              </div>

          </div>

      </header>
      <!--header end-->
      <!--sidebar start-->

      <!--sidebar end-->
<!--main content start-->
<section id="main-content">
<section class="wrapper">

            <!--tab nav start-->
            <section class="panel">
                <header class="panel-heading tab-bg-dark-navy-blue">
                    <ul class="nav nav-tabs">
                        <li class="active">
                            <a data-toggle="tab" href="#customer-info">
                                <i class="fa fa-home"></i>
                                Customer &amp; Vehicle Informations
                            </a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#vehicle-info">
                                <i class="fa fa-gears"></i>
                                Vehicle Details
                            </a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#contact-info">
                                <i class="fa fa-envelope-o"></i>
                                Contact Informations - Email &amp; SMS
                            </a>
                        </li>
                      @if($listid != '999')
                        <li>
                            <a data-toggle="tab" href="#csi-info" id="csibtn">
                                <i class="fa fa-keyboard-o"></i>
                                CSI Questions
                            </a>
                        </li>
                      @endif
                    </ul>
                </header>
                <div class="panel-body">
	                    <div class="tab-content">
	                    <div id="customer-info" class="tab-pane active">
      						@include('ford.ext_customer')
                        </div>
                        <div id="vehicle-info" class="tab-pane ">
                        @include('ford.ext_vehicle')
                    	</div>
                        <div id="contact-info" class="tab-pane ">
                        @include('ford.ext_contact')
                    	</div>
                        <div id="csi-info" class="tab-pane ">
                        @include('ford.ext_csi')
                      </div>
                    </div>
                </div>
            </section>
            <!--tab nav end-->

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">
Enquiry Details
</header>
<div class="panel-body">
<div class="form-group col-md-3">
<label for="exampleInputEmail1">Enquiry Category</label>
<select class="form-control" name="category" id="category" onChange="getcategory(this);" required="">
<option value="">Select</option>
@foreach($enquiry_categories as $category)
<option value="{{$category->id_enquiry_category}}">{{$category->category_name}}</option>
@endforeach
</select>
</div>
<div class="form-group col-md-3" id="subdiv1" style="display: none;">
<label for="exampleInputEmail1" id="subcatname1"></label>
<select class="form-control" name="subcategory1" id="subcategory1" onChange="getcategory(this);" required="">
<option value="">Select</option>
</select>
<!-- <div id="subcatdiv1"></div>  --> 
</div>
<div class="form-group col-md-3" id="subdiv2" style="display: none;">
<label for="exampleInputEmail1" id="subcatname2"></label>
<select class="form-control" name="subcategory2" id="subcategory2" onChange="getcategory(this);" required="">
<option value="">Select</option>
</select>
<!-- <div id="subcatdiv2"></div> -->
</div>
<div class="form-group col-md-3" id="subdiv3" style="display: none;">
<label for="exampleInputEmail1" id="subcatname3"></label>
<select class="form-control" name="subcategory3" id="subcategory3" onChange="getcategory(this);" required="">
<option value="">Select</option>
</select>
<!-- <div id="subcatdiv3"></div> -->
</div>
<div class="col-md-12"></div>
<div id="apptabdiv" style="display: none;">
<div class="form-group col-md-3">
<label for="exampleInputEmail1">Source Of Business</label>
<select class="form-control" name="source_name" id="source_name">
<option value="">Select</option>
@foreach($sourcebusiness as $source)
<option value="{{$source->source_name}}">{{$source->source_name}}</option>
@endforeach
</select>
</div>
<div class="form-group col-md-3">
<label for="exampleInputEmail1">Appointment Booked ?</label>
<select class="form-control" name="apptab" id="apptab" onChange="getapptab(this);">
<option value="">Select</option>
<option value="Yes">Yes</option>
<option value="No">No</option>
</select>
</div>
</div>

<div id="agentDiv" style="display: none;">
<div class="form-group col-md-3">
<label for="exampleInputPassword1">Call Center Agent Name</label>
<input type="text" class="form-control" value="{{$user_info}}" placeholder="{{$user_info}}" readonly="">
</div>
</div>
<input type="hidden" name="agent_name" id="agent_name"  value="{{$user_info}}">
<div id="subtype1" style="display: none;">

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Showroom Name</label>
<select class="form-control" name="showroomid" id="showroomid" onchange="getsalesman(this);">
    <option value="">Select</option>
@foreach($showrooms as $showroom)
    <option value="{{$showroom->id}}">{{$showroom->name}}</option>
@endforeach
</select>
<input type="hidden" name="showroom" id="showroom" value="">
</div>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Booked to Salesman</label>
<select class="form-control" name="salesman" id="salesman">
    <option value="">Select</option>
</select>
</div>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Brand</label>
<select class="form-control" name="interest" id="interest" onchange="getmodel(this);">
<option value="">Select</option>
<option value="Chevrolet">Chevrolet</option>
<option value="Cadillac">Cadillac</option>
</select>
</div>

<div class="form-group col-md-3" id="Chevroletdiv" style="display: none;">
<label for="exampleInputEmail1">Model Of Interest</label>
<select class="form-control" name="Chevrolet" id="Chevrolet">
<option value="">Select</option>
<option value="Aveo">Aveo</option>
<option value="Blazer">Blazer</option>
<option value="Captiva">Captiva</option>
<option value="Corvette">Corvette</option>
<option value="Bolt">Bolt</option>
<option value="Camaro">Camaro</option>
<option value="Silverado">Silverado</option>
<option value="Equinox">Equinox</option>
<option value="Express">Express</option>
<option value="Impala">Impala</option>
<option value="Malibu">Malibu</option>
<option value="Sonic">Sonic</option>
<option value="Spark">Spark</option>
<option value="Suburban">Suburban</option>
<option value="Tahoe">Tahoe</option>
<option value="Trail Blazer">Trail Blazer</option>
<option value="Traverse">Traverse</option>
<option value="Trax">Trax</option>
</select>
</div>

<div class="form-group col-md-3" id="Cadillacdiv" style="display: none;">
<label for="exampleInputEmail1">Model Of Interest</label>
<select class="form-control" name="Cadillac" id="Cadillac">
<option value="">Select</option>
<option value="ATS">ATS</option>
<option value="ATS Coupe">ATS Coupe</option>
<option value="CT5">CT5</option>
<option value="CT6">CT6</option>
<option value="CTS">CTS</option>
<option value="CTS-V">CTS-V</option>
<option value="Escalade">Escalade</option>
<option value="XT4">XT4</option>
<option value="XT5">XT5</option>
<option value="XT6">XT6</option>
<option value="XTS">XTS</option>
</select>
</div>

<div class="col-md-12"></div>
<div class="form-group col-md-3">
<label for="exampleInputPassword1">Type of Appoinment</label>
<select class="form-control" name="appointmenttype" id="appointmenttype" >
<option value="">Select</option>
<option value="ENO- Enquire Offers">ENO- Enquire Offers</option>
<option value="ENP- Enquire Price">ENP- Enquire Price</option>
<option value="ENS- Enquire Specifications">ENS- Enquire Specifications</option>
<option value="RQT- Request Quotation">RQT- Request Quotation</option>
<option value="SRA- Showroom Appointment">SRA- Showroom Appointment</option>
<option value="TDR- TestDrive Appointment">TDR- TestDrive Appointment</option>
<option value="VAV- Vehicle Availability">VAV- Vehicle Availability</option>
</select>
</div>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Appointment Code</label>
<select class="form-control" name="appointmentcode1" id="appointmentcode1" >
<option value="">Select</option>
<option value="APP- Mobile App">APP- Mobile App</option>
<option value="IPC- Incoming Phone Call">IPC- Incoming Phone Call</option>
<option value="SHZ- Showroomz App">SHZ- Showroomz App</option>
<option value="SOM- Social Media">SOM- Social Media</option>
<option value="WAP- Whatsapp">WAP- Whatsapp</option>
<option value="WLD- Dealer Website">WLD- Dealer Website</option>
<option value="WLM- Arabia Website">WLM- Arabia Website</option>
</select>
</div>

</div>

<div id="subtype2" style="display: none;">

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Service Center</label>
<select class="form-control" name="center_id" id="center_id" onchange="getadvisor(this);">
    <option value="">Select</option>
@foreach($centers as $center)
    <option value="{{$center->id}}">{{$center->name}}</option>
@endforeach
</select>
<input type="hidden" name="servicecenter" id="servicecenter" value="">
</div>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Service Advisor Name</label>
<select class="form-control" name="advisorname" id="advisorname">
    <option value="">Select</option>
</select>
</div>
<div class="form-group col-md-3">
<label for="exampleInputPassword1">Appointment Code</label>
<select class="form-control" name="appointmentcode" id="appointmentcode" >
<option value="">Select</option>
<option value="APC- Appointment Confirmation">APC- Appointment Confirmation</option>
<option value="APP- Mobile App">APP- Mobile App</option>
<option value="IPC- Incoming Phone Call">IPC- Incoming Phone Call</option>
<option value="SER- Service Reminder">SER- Service Reminder</option>
<option value="SHZ- Showroomz App">SHZ- Showroomz App</option>
<option value="SOM- Social Media">SOM- Social Media</option>
<option value="WLD- Dealer Website">WLD- Dealer Website</option>
</select>
</div>
</div>

<div class="form-group col-md-3" id="appointmentDiv" style="display: none;">
<label for="exampleInputPassword1">Appointment Date & Time</label>
<input size="16" type="text" value="" name="appointment" id="appointment" class="form_datetime form-control" autocomplete="off">
</div>

<div class="col-md-12"> </div>
<div class="form-group col-md-9">
<label for="exampleInputPassword1">Enquiry Description</label>
<textarea type="text" class="form-control" name="description" id="message"></textarea>
</div>

<input type="hidden" name="enq_account" id="enq_account" value="{{$id_account}}">
<input type="hidden" name="fname1" id="fname1" value="">
<input type="hidden" name="lname1" id="lname1" value="">
<input type="hidden" name="mobile2" id="amobile2" value="">
<input type="hidden" name="phone_number" id="phone_number" value="{{$mobile_number}}">
<input type="hidden" name="user_info" id="userid" value="{{$user_info}}">
<input type="hidden" name="listid" value="{{$listid}}">
<input type="hidden" name="campaignid" value="{{$campaignid}}">
<input type="hidden" name="ingroup" value="{{$ingroup}}">
<div class="form-group col-md-3">
<!-- <button type="submit" class="btn btn-danger btn-block" id="enqsubmitbtn">Submit</button> -->
<a class="btn btn-danger btn-block" id="enqsubmitbtn" onclick="submitform();">Submit</a>
<!-- <a href="#" class="form-control btn btn-danger btn-block">Close</a> -->
</div>

</div>
</form>
</section>
</div>
</div>





<div class="row">
<div class="col-lg-12">

<section class="panel">
<header class="panel-heading">
Enquiries List
</header>
<div class="panel-body">
<table class="table table-striped">
<thead>
<tr>
<th>#</th>
<th>Agent ID</th>
<th>Type</th>
<th>Date</th>
<th>Category</th>
<th>Sub Category</th>
<th>Description</th>
</tr>
</thead>
<tbody id="enqHTML">
  {!!$enqHTML!!}
</tbody>
</table>
</div>
</section>
</div>
</div>


      <!--footer start-->
      <footer class="footer-section">
          <div class="text-center">
              2019 &copy; Centrixplus
          </div>
      </footer>
      <!--footer end-->
  </section>
</section>

  <!-- Placed js at the end of the document so the pages load faster -->

                            <!-- Modal -->
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title">http://37.34.236.116:1180/alghanim/public/laravel_installation.txt</h4>
                                        </div>
                                        <div class="modal-body">

                                           <object data="" id="txtdocument" width="100%" height="900">

                                        </div>
                                        <div class="modal-footer">
                                            <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                                            <button class="btn btn-success" type="button">Save changes</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- modal -->

@include('layouts.script')
<script>
  //paste this code under head tag or in a seperate js file.
  // Wait for window load
  $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");
    var cusid = $("#firstcustomer").val();
    //alert(cusid);
    if(cusid != '0'){
    customerinfo(cusid);
    }

  });
</script>
  <script type="text/javascript">

  function submitform() {

    $('#userform').submit();
    //$('#enquiryform').submit();
  }

  function search() {

  var user = document.getElementById("userid").value;
  var listid = document.getElementById("listid").value;
  var campaignid = document.getElementById("campaignid").value;
  var ingroup = document.getElementById("ingroup").value;
  var phone = document.getElementById("phsearch").value;
  var checked = $('input[name="searchcon"]:checked').val();
        if(checked == 'mobile')   {
        if (phone.length == '8') {
            window.location = "{{url('/ford')}}/customer/"+phone+"/"+user+"/"+listid+"/"+campaignid+"/"+ingroup;
        }
        else{
            alert('Mobile Number Must Be 8 Digits');
        }
        }
        else{ 
        //alert(checked); 
        if (phone.length >= '1') {
        var regno = phone.replace("/", "__");    
        //alert(regno);     
            window.location = "{{url('/ford')}}/customer_regno/"+regno+"/"+user+"/"+listid+"/"+campaignid+"/"+ingroup;
        }
        else{
            alert('Register Number is Empty');
        }
        }
  }


  function customerinfo(cusid) {
  //alert(cusid);
  $('.se-pre-con').show();
  $(".acclist").removeClass("active");
  $("#acclist"+cusid).addClass("active");
  $("#fname").val("");
  $("#lname").val("");
  $("#mobile2").val("");
  $("#gender").val("");
  $("#civilid").val("");
  $("#address").val("");
  $("#id_account").val(0);
  $("#enq_account").val(0);
  $("#vehid_account").val(0);
  $("#enqHTML").html("");


  $("#vehicleinfo").val("");
  $("#vehmodel").val("");
  $("#vehyear").val("");
  $("#vehcolor").val("");
  $("#vehshowroom").val("");
  $("#plateno").val("");
  $("#lastservice").val("");
  $("#nextservice").val("");
  $("#vehicle_id").val(0);

  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/ford/customerinfo')}}",
    data: {cusid: cusid}, 
    dataType:'JSON', 
    success: function(data){

          $("#enqHTML").html(data.enqHTML);

          //var vehicles = data.vehicles;

          //var len =  vehicles.length; 

          $("#vehicle_list").html("");
          $('#vehicle_history_list').html("");
          $('#vehicle_contact_list').html("");

          $('#vehicle_list').html(data.divHtml);
          $('#vehicle_history_list').html(data.divHtml1);
          $('#vehicle_contact_list').html(data.divHtml2);
          $('#vehicle_csi_list').html(data.divHtml3);

          $("#fname").val(data.fname);
          $("#lname").val(data.lname);
          $("#mobile2").val(data.mobile2);
          $("#gender").val(data.gender);
          $("#civilid").val(data.civilid);
          $("#address").val(data.address);
          $("#id_account").val(cusid);
          $("#vehid_account").val(cusid);

          $("#enq_account").val(cusid);
          $("#fname1").val(data.fname);
          $("#amobile2").val(data.mobile2);
          $("#lname1").val(data.lname);

          //$("#enqsubmitbtn").removeAttr("disabled");
  $('.se-pre-con').hide();

        },error:function(){ 
            alert("error!!!!");
          $('.se-pre-con').hide();
        }
  });
  }


  function vehicleinfo(vehid) {
  //alert(vehid);
  $('.se-pre-con').show();
  $(".vcclist").removeClass("active");
  $("#vcclist"+vehid).addClass("active");

  $(".vcc1list").removeClass("active");
  $("#vcc1list"+vehid).addClass("active");

  $(".vcc2list").removeClass("active");
  $("#vcc2list"+vehid).addClass("active");

  $(".vcc3list").removeClass("active");
  $("#vcc3list"+vehid).addClass("active");

   var cusid = $("#id_account").val();

  //alert(cusid);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/ford/vehicleinfo')}}",
    data: {vehid: vehid,cusid: cusid}, 
    dataType:'JSON', 
    success: function(data){

          //alert(data.histyHTML);
          $("#historyHTML").html(data.histyHTML);

          $("#vehicleinfo").val(data.vehicleinfo);
          $("#vehmodel").val(data.vehmodel);
          $("#vehyear").val(data.vehyear);
          $("#vehcolor").val(data.vehcolor);
          $("#mileage").val(data.MILEAGE);
          $("#plateno").val(data.plateno);
          $("#lastservice").val(data.lastservice);
          $("#nextservice").val(data.nextservice);
          $("#vehicle_id").val(vehid);

          $("#model1").val(data.vehmodel);
          $("#motdate1").val(data.MOTDATE);
          $("#lastwork1").val(data.LASTWORK);
          $("#regno1").val(data.plateno);
          $("#lastserv1").val(data.lastservice);
          $("#nextserv1").val(data.nextservice);
          
          $("#showroom1").val(data.showroom);
          $("#salesman1").val(data.salesman);
          $("#model1").val(data.availmodel);
          $("#regno1").val(data.regno);
          $("#description1").val(data.description);
          $("#invno1").val(data.invoice);

          $('.se-pre-con').hide();
          getcsi();

        $('#nextbtn').attr("disabled", false);

        },error:function(){ 
            alert("error!!!!");
          $('.se-pre-con').hide();
        }
  });
  }

  function getcategory(id) {
    idvalue = id.value;
    //alert(idvalue);
    if(idvalue== '118' || idvalue== '119' || idvalue== '120'  || idvalue== '138' || idvalue== '139' ){
      $( "#csibtn" ).click();
      
        $('html, body').animate({
            scrollTop: $('#main-content').offset().top
        }, 'slow');
    }
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/ford/getcategory')}}",
    data: {idvalue: idvalue}, 
    dataType:'JSON', 
    success: function(data){
            //alert(data.categorytype);

        var categorytype = data.categorytype;


          $("#salesman").val("");
          $("#appointment").val("");
          $("#interest").val("");
          $("#appointmenttype").val("");
          $("#agentname").val("");
          $("#showroom").val("");
          $("#advisorname").val("");
          $("#appointmenttype").val("");
          $("#appointmenttype").val("");
          $("#subtype1").hide();
          $("#subtype2").hide();
          $("#agentDiv").hide("");
          $("#appointmentDiv").hide("");
        //alert(categorytype);
        if(categorytype == '1'){
          $("#subdiv2").hide();
          $("#subdiv3").hide();
          $("#subcategory1").html("");
          $("#subcategory2").html("");
          $("#subcategory3").html("");
          $("#subcategory2").val("");
          $("#apptabdiv").hide();
          $("#apptab").val("");
          $("#subcategory3").val("");
        if (data.divhtml != "") {

          $("#subdiv1").show();
          $("#subcategory1").html(data.divhtml);
          $("#subcatname1").html(data.categoryname);

        }
          $("#subcatname2").html("");
          $("#subcatname3").html("");
        }

        if(categorytype == '2'){
          $("#subdiv3").hide();
          $("#subcategory2").html("");
          $("#subcategory3").html("");
          $("#subcategory3").val("");
        if (data.divhtml != "") {

          $("#subdiv2").show();
          $("#subcategory2").html(data.divhtml);
          $("#subcatname2").html(data.categoryname);

        }
          $("#subcatname3").html("");
        }

        if(categorytype == '3'){
          $("#subcategory3").html("");
        if (data.divhtml != "") {

          $("#subdiv3").show();
          $("#subcategory3").html(data.divhtml);
          $("#subcatname3").html(data.categoryname);

        }
        }

        if(data.apptab == '1'){
          $("#apptabdiv").show();
        }
        else if(data.apptab == '0'){
          $("#apptabdiv").hide();
        }


        },error:function(){ 
            alert("error!!!!");
        }
  });
  }

function getmodel(idval){
    var model = idval.value;
    if(model == 'Chevrolet'){
          $("#Chevroletdiv").show();
          $("#Cadillacdiv").hide();

    }
    else if(model == 'Cadillac'){
          $("#Chevroletdiv").hide();
          $("#Cadillacdiv").show();
      
    }
    else{
      
          $("#Chevroletdiv").hide();
          $("#Cadillacdiv").hide();
    }

  }
function getapptab(idval){
  //alert("apptab");
    //alert(idval.value);
    var appvalue = idval.value;
    var categorytype = $("#category").val();


        if(appvalue == 'Yes'){
          $("#appointmentDiv").show();
          $("#agentDiv").show();
        if(categorytype == '1' || categorytype == '109'){
          $("#subtype1").show();
          $("#subtype2").hide();
        }
        else{
          $("#subtype1").hide();
          $("#subtype2").show();         
        }
        }
        else{
          $("#appointmentDiv").hide("");
          $("#agentDiv").hide("");
          $("#subtype1").hide();
          $("#subtype2").hide();  

        }
}

  function getnextquestion() {
  $('.se-pre-con').show();
  var questionid = $("#questionid").val();
  var answer = $("#answer").val();
  var question = $("#questionDIV").html();

  var description = $("#description").val();
  var mobile = $("#phone_number").val();
  var user = $("#listid").val();
  var ctime = $("#current_time").val();
  var id_account = $("#id_account").val();
  var vehid = $("#vehicle_id").val();


  var userinfo = $("#userid").val();
  var fullname = $("#fname").val()+' '+$("#lname").val();
  var vehbrand = $("#vehicleinfo").val();
  var vehmodel = $("#model1").val();
  var dealer = $("#salesman1").val();
  var vehyear = $("#vehyear").val();
  var showroom = $("#showroom1").val();

  //alert(questionid +"-"+answer+"-"+mobile+"-"+user+"-"+id_account+"-"+vehid+"-"+dealer+"-"+showroom);
  //$('#nextbtn').attr("disabled", true);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/ford/getquestion')}}",
    data: {questionid:questionid,question:question, answer:answer, description:description, mobile:mobile, user:user,ctime:ctime, id_account:id_account, vehid:vehid, vehbrand:vehbrand, vehmodel:vehmodel, dealer: dealer,vehyear:vehyear, showroom:showroom,userinfo:userinfo,fullname:fullname}, 
    dataType:'JSON', 
    success: function(response){
        //alert(response.previous);
        //alert(response.quesid);
        if(response.question != ''){
        $("#questionid").val(0);
        $("#questionid").val(response.quesid);
        $("#questionDIV").html("");
        $("#questionDIV").html(response.question);
        $("#questionDIV1").html("");
        $("#questionDIV1").html(response.question1);
        $("#answerDIV").html("");
        $("#answerDIV").html(response.answer);
        $("#desDIV").html("");
        $("#desDIV").html(response.description);
        $("#prev_answers").html("");
        $("#prev_answers").html(response.previous);
        $("#prev_answers1").html("");
        $("#prev_answers1").html(response.previous1);
        $('#nextbtn').attr("disabled", false);
        if(response.quesid == '19' || response.quesid == '34' || response.quesid == '50'){
        $('#nextbtn').val("Finish");
        }
        }
        else{
        $('#nextbtn').attr("disabled", true);
        $('#nextbtn').hide();
        $("#questionid").val(0);
        $("#questionbox").html("");
        $("#prev_answers").html("");
        $("#prev_answers").html(response.previous);
        $("#prev_answers1").html("");
        $("#prev_answers1").html(response.previous1);
        }
        $('.se-pre-con').hide();
      
    },error:function(){ 
            alert("error!!!!");
        $('.se-pre-con').hide();
        }
  });
  }

function placeanswer(idval){
  //alert(idval);
  $("#answer").val(idval);
  getnextquestion();
}
function otheranswer(idval){
  //alert(idval);
  $("#answer").val(idval);
}
function selectanswer(){
  //alert(answer.value);
  getnextquestion();
}

  function getcsi() {
  var mobile = $("#phone_number").val();
  var user = $("#listid").val();
  var ctime = $("#current_time").val();
  var id_account = $("#id_account").val();
  var vehid = $("#vehicle_id").val();

  var userinfo = $("#userid").val();
  var fullname = $("#fname").val()+' '+$("#lname").val();
  var vehbrand = $("#vehicleinfo").val();
  var vehmodel = $("#model1").val();
  var dealer = $("#salesman1").val();
  var vehyear = $("#vehyear").val();
  var showroom = $("#showroom1").val();

  //alert(questionid +"-"+answer+"-"+mobile+"-"+user+"-"+id_account+"-"+vehid+"-"+dealer+"-"+showroom);
  //$('#nextbtn').attr("disabled", true);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/ford/getcsi')}}",
    data: {mobile:mobile, user:user,ctime:ctime, id_account:id_account, vehid:vehid, vehbrand:vehbrand, vehmodel:vehmodel, dealer: dealer,vehyear:vehyear, showroom:showroom,fullname:fullname,userinfo:userinfo}, 
    dataType:'JSON', 
    success: function(response){
        $('#questionbox').show();

        //alert(response.previous);
        //alert(response.quesid);
        if(response.quesid != '0'){
        $("#questionid").val(0);
        $("#questionid").val(response.quesid);
        $("#questionDIV").html("");
        $("#questionDIV").html(response.question);
        $("#questionDIV1").html("");
        $("#questionDIV1").html(response.question1);
        $("#answerDIV").html("");
        $("#answerDIV").html(response.answer);
        $("#desDIV").html("");
        $("#desDIV").html(response.description);
        $("#prev_answers").html("");
        $("#prev_answers").html(response.previous);
        $("#prev_answers1").html("");
        $("#prev_answers1").html(response.previous1);
        $('#nextbtn').attr("disabled", false);
        if(response.quesid == '18'){
        $('#nextbtn').val("Finish");
        }
        }
        else{
        $('#nextbtn').hide();
        $("#questionid").val(0);
        $("#questionbox").html("");
        $("#prev_answers").html("");
        $("#prev_answers").html(response.previous);
        $("#prev_answers1").html("");
        $("#prev_answers1").html(response.previous1);
        }
        $('.se-pre-con').hide();
      
    },error:function(){ 
            //alert("error!!!!");
        $('.se-pre-con').hide();
        }
  });
  }


  function getsalesman(id) {
  var idval = id.value;
  //alert(idval);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/ford/getsalesman')}}",
    data: {idval:idval}, 
    dataType:'JSON', 
    success: function(response){
      
        //alert(response);
        if(response.divhtml != ''){
        $("#showroom").val(0);
        $("#showroom").val(response.showroom);
        $("#salesman").html("");
        $("#salesman").html(response.divhtml);
        }
      
    },error:function(){ 
            alert("error!!!!");
        }
  });
  }


  function getadvisor(id) {
  var idval = id.value;
  //alert(idval);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/ford/getadvisor')}}",
    data: {idval:idval}, 
    dataType:'JSON', 
    success: function(response){
      
        //alert(response);
        if(response.divhtml != ''){
        $("#servicecenter").val(0);
        $("#servicecenter").val(response.showroom);
        $("#advisorname").html("");
        $("#advisorname").html(response.divhtml);
        }
      
    },error:function(){ 
            alert("error!!!!");
        }
  });
  }

  function edit_csi(idval) {
  alert(idval);
  //alert(questionid +"-"+answer+"-"+mobile+"-"+user+"-"+id_account+"-"+vehid+"-"+dealer+"-"+showroom);
  //$('#nextbtn').attr("disabled", true);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/ford/edit_csi')}}",
    data: {idval:idval}, 
    dataType:'JSON', 
    success: function(response){
        $('#questionedit').show();
      
        alert(response);
        if(response.question != ''){
        $("#editquestionid").val(0);
        $("#editquestionid").val(response.quesid);
        $("#questionEDIT").html("");
        $("#questionEDIT").html(response.question);
        $("#answerEDIT").html("");
        $("#answerEDIT").html(response.answer);
        $("#desEDIT").html("");
        $("#desEDIT").html(response.description);
        }
        $('.se-pre-con').hide();
      
    },error:function(){ 
            alert("error!!!!");
        $('.se-pre-con').hide();
        }
  });
  }


  function editqueston() {
  var idval = $("#editquestionid").val();
  alert(idval);
  var answer = $("#answer").val();
  alert(idval +"-"+answer);
  //$('#nextbtn').attr("disabled", true);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/ford/editqueston')}}",
    data: {idval:idval,answer:answer}, 
    dataType:'JSON', 
    success: function(response){
        $('#questionedit').hide();
      
        //alert(response.previous);
        //alert(response.quesid);
        if(response.question != ''){
        $("#editquestionid").val(0);
        $("#prev_answers").html("");
        $("#prev_answers").html(response.previous);
        }
        $('.se-pre-con').hide();
      
    },error:function(){ 
            alert("error!!!!");
        $('.se-pre-con').hide();
        }
  });
  }



  </script>
<script type="text/javascript">


function getresponseurl() {
  var newURL = "http://37.34.236.116:1180/alghanim/public/laravel_installation.txt";
   // document.getElementById("txtdocument").setAttribute('data', newURL);
   //beginSaveProduct();
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/gettxtdocument')}}",
    data: {newURL:newURL}, 
    dataType:'JSON', 
    success: function(response){
     // alert(response.txtdoc);
    document.getElementById("txtdocument").setAttribute('data', response.txtdoc);
    $('#myModal').modal();
    },error:function(){ 
            alert("error!!!!");
        }
  });
}



var productServiceUrl = 'http://172.16.4.16:790/AlghanimAutoline/WCOM?wsdl=GetArchivedDocument'; // Preferably write this out from server side
 
function beginSaveProduct()
{
var soapMessage ='<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dcom="http://172.16.4.16:790/AlghanimAutoline/WCOM"><soapenv:Body><dcom:GetArchivedDocument><dcom:Identification><dcom:SessionId>10000005</dcom:SessionId></dcom:Identification><dcom:LookupCodes> <dcom:RooftopId>TABYAAS01</dcom:RooftopId> <dcom:DocRef>WI03274714</dcom:DocRef> <dcom:Terminal>1021</dcom:Terminal> </dcom:LookupCodes></dcom:GetArchivedDocument></soapenv:Body></soapenv:Envelope>';
 
$.ajax({
url: productServiceUrl,
type: "POST",
dataType: "xml",
data: soapMessage,
complete: endSaveProduct,
contentType: "text/xml; charset=\"utf-8\""
});
 
return false;
}
 
function endSaveProduct(xmlHttpRequest, status)
{
 $(xmlHttpRequest.responseXML)
    .find('SaveProductResult')
    .each(function()
 {
   var name = $(this).find('Name').text();
 });
}

</script>
  </body>

</html>