@extends('layouts.master')
@section('title', 'Customers')
@section('breadCrumbs')
        
@stop

@section('pageBody')
         <div class="row">
            <div class="col-sm-12">
                

                    <form action="{{url('/master')}}/tables/store" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <header class="panel-heading">
                          Customers
                        </header>
                        <div class="panel-body">
                                <div class="form-group col-md-3">
                                    <label for="in_arabic">phone</label>
                                    <input type="text" class="form-control" name="phone">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="in_arabic">cus target </label>
                                    <textarea type="text" class="form-control" name="cusid"></textarea>
                                </div>
                                <input type="hidden" name="exptype" value="1">
                                <div class="form-group col-md-3 pull-right">

                                <button type="submit" class="btn btn-success btn-block">export</button>
                                
                                </div>
                        </div>
                    </section>
                    </form>

            </div>
            </div>
         <div class="row">
            <div class="col-sm-12">
                

                    <form action="{{url('/master')}}/tables/store" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <header class="panel-heading">
                          Vehicles
                        </header>
                        <div class="panel-body">
                                <div class="form-group col-md-3">
                                    <label for="in_arabic">phone</label>
                                    <input type="text" class="form-control" name="phone">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="in_arabic">veh target </label>
                                    <textarea type="text" class="form-control" name="cusid"></textarea>
                                </div>
                                <input type="hidden" name="exptype" value="2">
                                <div class="form-group col-md-3 pull-right">

                                <button type="submit" class="btn btn-success btn-block">export</button>
                                
                                </div>
                        </div>
                    </section>
                    </form>

            </div>
            </div>

  
       
@stop
@section('ScriptPage')


@stop
