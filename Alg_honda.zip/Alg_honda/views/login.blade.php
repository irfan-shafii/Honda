<head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="ThemeBucket">
    <link rel="shortcut icon" href="{{asset('bucket')}}/images/favicon.html">

    <title>Login</title>

    <!--Core CSS -->
    <link href="{{asset('bucket')}}/bs3/css/bootstrap.min.css" rel="stylesheet">
    <link href="{{asset('bucket')}}/css/bootstrap-reset.css" rel="stylesheet">
    <link href="{{asset('bucket')}}/font-awesome/css/font-awesome.css" rel="stylesheet" />

    <!-- Custom styles for this template -->
    <link href="{{asset('bucket')}}/css/style.css" rel="stylesheet">
    <link href="{{asset('bucket')}}/css/style-responsive.css" rel="stylesheet" />

</head>

  <body class="login-body">

    <div class="container">

      <form method="post" class="form-signin" action="{{url('/')}}/login/store">
         {{csrf_field()}}
        <h2 class="form-signin-heading">Login
      </h2> 
        <div class="login-wrap">
          
         
            <div class="user-login-info">
                <input type="text" name="email" class="form-control" placeholder="User ID" autofocus>
                <input type="password" name="password" class="form-control" placeholder="Password" autofocus>
               
            </div>
            <label class="checkbox">
            </label>
            <button class="btn btn-lg btn-login btn-block" type="submit">Sign in</button>

           

        </div>

      </form>

    </div>



    <!-- Placed js at the end of the document so the pages load faster -->

    <!--Core js-->
    <script src="{{asset('bucket')}}/js/jquery.js"></script>
    <script src="{{asset('bucket')}}/bs3/js/bootstrap.min.js"></script>

  </body>

</html>
