@extends('layouts.master')
@section('title', 'List Status Report')
@section('breadCrumbs')
        
@stop

@section('pageBody')

        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/list')}}/status" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">
                                <div class="form-group col-md-3">
                                    <label for="exampleI">Campaigns</label>
                                    <select name="campaigns" id="campaigns" class="form-control" onchange="getlist(this);">
                                        <option value="">Select</option>
                                        @foreach($campaigns as $list)
                                        <option value="{{$list->campaign_id}}" @if($list->campaign_id == $campaign_id) selected="" @endif>{{$list->campaign_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            <div class="form-group col-md-3"><br>
                            <button type="submit" id="submitbtn" class="btn btn-primary btn-block"><i class="fa fa-search"></i> Search</button>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>List Report</strong><span class="pull-right">Total <strong>{{count($lists)}}</strong> Records</span>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                    <tr>
                    <th>List ID</th>
                    <th>List Name</th>
                    <th>Campaign ID</th>
                    <th>Description</th>
                    <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                  @if(count($lists) > 0)
                  @foreach($lists as $log)
                    <tr class="gradeX">
                    <td>{{$log->list_id}}</td>
                    <td>{{$log->list_name}}</td>
                    <td>{{$log->campaign_id}}</td>
                    <td>{{$log->list_description}}</td>
                    <td id="status{{$log->list_id}}">@if($log->active == 'Y') <a href="#" class="btn btn-space btn-xs btn-success" onclick="changestatus('{{$log->list_id}}');"> Active</a> @elseif($log->active == 'N') <a href="#" class="btn btn-space btn-xs btn-danger" onclick="changestatus('{{$log->list_id}}');"> In Active</a> @endif</td>
                    </tr>
                  @endforeach
                  @endif
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>    
        <!-- page end--> 
@stop
@section('ScriptPage')
<script type="text/javascript">


  function changestatus(idval) {

  var status = $("#status"+idval).val();

  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/changestatus')}}",
    data: {idval:idval}, 
    dataType:'JSON', 
    success: function(response){
        //alert(response.status);
        //alert(response.quesid);
        if(response.question != ''){
        $("#status"+idval).html("");
        $("#status"+idval).html(response.divhtml);
        }
      
    },error:function(){ 
            alert("error!!!!");
        }
  });
  }

</script>

@stop