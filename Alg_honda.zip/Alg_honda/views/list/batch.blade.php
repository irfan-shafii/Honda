@extends('layouts.master')
@section('title', 'Batch Status')
@section('breadCrumbs')
        
@stop

@section('pageBody')
        <!-- page start--> 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/list/batch" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">
                                <div class="form-group col-md-3">
                                    <label for="exampleI">Campaigns</label>
                                    <select name="campaigns" id="campaigns" class="form-control" onChange="getlist(this);">
                                        <option value="">Select</option>
                                        @foreach($campaigns as $list)
                                        <option value="{{$list->campaign_id}}" @if($list->campaign_id == $campaign_id) selected="" @endif>{{$list->campaign_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleI">List ID</label>
                                    <select name="lists" id="lists" class="form-control" onChange="getlistbatch(this);">
                                        <option value="">Select</option>
                                        @foreach($lists as $groups)
                                        <option value="{{$groups->list_id}}" @if($groups->list_id == $list_id) selected="" @endif>{{$groups->list_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleI">Batch No.</label>
                                    <select name="batchno" id="batchno" class="form-control">
                                        <option value="">Select</option>
                                        @foreach($batches as $batche)
                                        <option value="{{$batche->batchno}}" @if($batche->batchno == $batchno) selected="" @endif>{{$batche->batchno}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            <div class="form-group pull-right col-md-3"><br>
                            <button type="submit" id="submitbtn" class="btn btn-primary btn-block"><i class="fa fa-search"></i> Search</button>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Target Details </strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Campaign</th>
                        <th>List Id</th>
                        <th>Batch No</th>
                        <th>Total Target</th>
                        <th>Achieved Target</th>
                        <th>Remaining Target</th>
                        <th>Dialable</th>
                        <th>Deactivated</th>
                        <th>Created Date</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($target_lists as $list)
                    <tr class="gradeX">
                        <td>{{$list->id}}</td>
                        <td>{{$list->campaign_id}}</td>
                        <?php 
                        $listnames = App\VicidialLists::select('list_name')->where('list_id',$list->list_id)->get();
                        $listname =  '';
                        if(count($listnames) > 0){
                        $listname =  $listnames[0]->list_name;
                        }
                        ?>
                        <td>{{$listname}}</td>
                        <td>{{$list->batchno}}</td>
                        <td>{{$list->totaltarget}}</td>
                        <td>{{$list->achieved}}</td>
                        <td>{{$list->remaining}}</td>
                        <td>{{App\VicidialList::where('list_id',$list->list_id)->where('status','NEW')->where('batchno',$list->batchno)->count()}}</td>
                        <td>{{App\VicidialList::where('list_id',$list->list_id)->where('status','DA')->where('batchno',$list->batchno)->count()}}</td>
                        <td>{{date("d/m/y",strtotime($list->created_at))}}</td>
                        <td id="status{{$list->id}}">@if($list->active == 'Y') <a href="#" class="btn btn-space btn-xs btn-success" onclick="changestatus('{{$list->id}}');"> Active</a> @elseif($list->active == 'N') <a href="#" class="btn btn-space btn-xs btn-danger" onclick="changestatus('{{$list->id}}');"> In Active</a> @endif</td>
                    </tr>
                    @endforeach
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')
<script type="text/javascript">
    

function getlist(id) {
  var campaign = id.value;
  //alert(campaign);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getlistids')}}",
    data: {campaign:campaign}, 
    dataType:'JSON', 
    success: function(response){
        //alert(response.divhtml);
        $("#lists").html("");
        $("#lists").html(response.divhtml);
      
    },error:function(){ 
            //alert("error!!!!");
        }
  });
  }

function getlistbatch(id) {
  var list = id.value;
  //alert(campaign);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getlistbatch')}}",
    data: {list:list}, 
    dataType:'JSON', 
    success: function(response){
        //alert(response.divhtml);
        $("#batchno").html("");
        $("#batchno").html(response.divhtml);
      
    },error:function(){ 
            //alert("error!!!!");
        }
  });
  }

  function changestatus(idval) {

  var status = $("#status"+idval).val();

  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/changebatchstatus')}}",
    data: {idval:idval}, 
    dataType:'JSON', 
    success: function(response){
        //alert(response.status);
        //alert(response.quesid);
        if(response.question != ''){
        $("#status"+idval).html("");
        $("#status"+idval).html(response.divhtml);
        }
        window.location.reload();
      
    },error:function(){ 
            alert("error!!!!");
        }
  });
  }
</script>

@stop
