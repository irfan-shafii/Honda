<?php 
    $routeName = Request::route()->getName();
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from bucketadmin.themebucket.net/dynamic_table.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Nov 2019 10:11:01 GMT -->
<head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="ThemeBucket">
    <link rel="shortcut icon" href="/yogesh/public/customer/images/favicon.html">

    <title>@yield('title')</title>

    <!--Core CSS -->
    <link href="/yogesh/public/customer/bs3/css/bootstrap.min.css" rel="stylesheet">
    <link href="/yogesh/public/customer/css/bootstrap-reset.css" rel="stylesheet">
    <link href="/yogesh/public/customer/font-awesome/css/font-awesome.css" rel="stylesheet" />

    <!-- Custom styles for this template -->
    <link href="/yogesh/public/customer/css/style.css" rel="stylesheet">
    <link href="/yogesh/public/customer/css/style-responsive.css" rel="stylesheet" />

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]>
    <script src="/yogesh/public/customer/{{url('/assets')}}/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="/yogesh/public/customer/{{url('/assets')}}/https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="/yogesh/public/customer/{{url('/assets')}}/https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>

<body>

<section id="container" >
<!--header start-->
@include('layouts.header')
<!--header end-->
@include('layouts.leftside')
<!--sidebar end-->
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
        <!-- page start--> 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="/yogesh/public/index.php/leads/list" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">
                                <div class="form-group col-md-4">
                                    <label for="exampleInput">List ID</label>
                                    <select name="list_id" class="form-control">
                                        <option value="">SELECT</option>
                                        @foreach($list_ids as $list)
                                        <option @if($list->list_id == $list_id) selected="" @endif value="{{$list->list_id}}">{{$list->list_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleI">Status</label>
                                    <select name="status" class="form-control">
                                        <option value="">SELECT</option>
                                        <option @if($status == 'answer') selected="" @endif value="answer">Answer</option>
                                        <option @if($status == 'B') selected="" @endif value="B">Busy</option>
                                        <option @if($status == 'NA') selected="" @endif value="NA">No Answer</option>
                                    </select>
                                </div>
                                <input type="hidden" name="resetstatus" id="resetstatus" value="0">
                            <div class="form-group pull-right col-md-4">
                            <button type="submit" id="submitbtn" class="form-control btn btn-primary btn-block"><i class="fa fa-search"></i> Search</button>
                            <a href="#" class="form-control btn btn-danger btn-block" onclick="resetbtn();"><i class="fa fa-arrows-alt"></i> Reset</a>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>
        <style type="text/css">
            .dataTables_info{
                display: none ! important;
            }
            .dataTables_paginate{
                display: none ! important;
            }
            /*.dataTables_length{
                display: none ! important;
            }*/
        </style>
        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Dialer Leads Report</strong><span class="pull-right">Total <strong>{{$dial_lists_count}}</strong> Records</span>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table1">
                    <thead>
                    <tr>
                    <th data-orderable="false"><input type="checkbox" id="select_all"></th>
                    <th>Lead ID</th>
                    <th>Entry Date</th>
                    <th>Modify Date</th>
                    <th>Status</th>
                    <th>Phone Number</th>
                    <th>User</th>
                    <th>List ID</th>
                    <th>Caller Count</th>
                    </tr>
                    </thead>
                    <tbody>
                  @if(count($dial_lists) > 0)
                  @foreach($dial_lists as $log)
                    <tr class="gradeX">
                    <td><input type="checkbox" name="chkuser[]" value="{{$log->lead_id}}" class="checkall"></td>
                    <td>{{$log->lead_id}}</td>
                    <td>{{$log->entry_date}}</td>
                    <td>{{$log->modify_date}}</td>
                    <td>@if($log->status == 'B') Busy @elseif($log->status == 'NA') No Answer @else {{$log->status}} @endif</td>
                    <td>{{$log->phone_number}}</td>
                    <td>{{$log->user}}</td>
                    <td>{{$log->list_id}}</td>
                    <td>{{$log->called_count}}</td>
                    </tr>
                  @endforeach
                  @endif
                    </table>
                    </div>
                                        
                                    <ul class="pagination pagination-sm pull-right">
                                        {!! $dial_lists->render() !!}
                                    </ul>
                    </div>
                </section>
            </div>
        </div>    
        <!-- page end-->
        </section>
    </section>
    <!--main content end-->
<!--right sidebar start-->
@include('layouts.rightnav')
<!--right sidebar end-->

</section>

<!-- Placed js at the end of the document so the pages load faster -->

<!--Core js-->
<script src="/yogesh/public/customer/js/jquery.js"></script>
<script src="/yogesh/public/customer/bs3/js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="/yogesh/public/customer/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="/yogesh/public/customer/js/jquery.scrollTo.min.js"></script>
<script src="/yogesh/public/customer/js/jQuery-slimScroll-1.3.0/jquery.slimscroll.js"></script>
<script src="/yogesh/public/customer/js/jquery.nicescroll.js"></script>
<!--Easy Pie Chart-->
<script src="/yogesh/public/customer/js/easypiechart/jquery.easypiechart.js"></script>
<!--Sparkline Chart-->
<script src="/yogesh/public/customer/js/sparkline/jquery.sparkline.js"></script>
<!--jQuery Flot Chart-->
<script src="/yogesh/public/customer/js/flot-chart/jquery.flot.js"></script>
<script src="/yogesh/public/customer/js/flot-chart/jquery.flot.tooltip.min.js"></script>
<script src="/yogesh/public/customer/js/flot-chart/jquery.flot.resize.js"></script>
<script src="/yogesh/public/customer/js/flot-chart/jquery.flot.pie.resize.js"></script>


<!--common script init for all pages-->
<script src="/yogesh/public/customer/js/scripts.js"></script>
<script type="text/javascript">

  
$("#select_all").change(function(){
  //"select all" change
  var status = this.checked;
  // "select all" checked status
  $('.checkall').each(function(){
    //iterate all listed checkbox items
    this.checked = status; //change ".checkbox" checked status
  });
});
    function resetbtn(compid) {

    var arr= [];
    var chkuserids = document.getElementsByName("chkuser[]");

    var striginhseqs= "";
    var usercount = 0;
    for(var i = 0; i < chkuserids.length; i++)
    {
      if(chkuserids[i].checked == true)
      {
        usercount++;
        arr.push(chkuserids[i].value);       
      }   
    }  
    if(arr == ''){
    //alert('no record');
    document.getElementById('resetstatus').value = '1';
    document.getElementById('submitbtn').click();
	}
	else if(arr != ''){
    	//alert(arr);
  	window.location = "{{ url('/').'/leads/list/' }}"+arr;
	}

}
</script>

</body>

<!-- Mirrored from bucketadmin.themebucket.net/dynamic_table.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Nov 2019 10:11:04 GMT -->
</html>
