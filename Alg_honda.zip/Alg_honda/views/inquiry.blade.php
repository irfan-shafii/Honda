@extends('layouts.master')
@section('title', 'Enquiries List')
@section('breadCrumbs')
        
@stop

@section('pageBody')
<?php 

    $enq_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$inquiry->enquiry_category)->first();
    $enq_sub_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$inquiry->enquiry_subcategory)->first();
    $enq_category = '';
    $enq_subcategory = '';
    $enq_subcategory2 = '';
    $enq_subcategory3 = '';

     if(!empty($inquiry->enquiry_subcategory2) || $inquiry->enquiry_subcategory2 == '0'){

     $enq_sub_cat2 = DB::table('enquiry_categories')->where('id_enquiry_category',$inquiry->enquiry_subcategory2)->first();

    if(count($enq_sub_cat2) > 0){
      $enq_subcategory2 = " - ".$enq_sub_cat2->category_name;
    }

    }

    if(!empty($inquiry->enquiry_subcategory3) || $inquiry->enquiry_subcategory3 == '0'){

     $enq_sub_cat3 = DB::table('enquiry_categories')->where('id_enquiry_category',$inquiry->enquiry_subcategory3)->first();

    if(count($enq_sub_cat3) > 0){
      $enq_subcategory3 = " - ".$enq_sub_cat3->category_name;
    }
     }
    if(count($enq_cat) > 0){
      $enq_category = $enq_cat->category_name;
    }
    if(count($enq_sub_cat) > 0){
      $enq_subcategory = $enq_sub_cat->category_name;
    }
  $appdetail = DB::table('appointments')->where('opp_id',$inquiry->id_opp)->get();
?>

        <div class="row">
            <div class="col-sm-12">
            <section class="panel">
                <div class="prf-box">
                    <h3 class="prf-border-head">{{$inquiry->id_opp}} / {{$inquiry->first_name}} {{$inquiry->last_name}} / {{$inquiry->mobile_number}} / {{$enq_subcategory}} {!! $enq_subcategory2 !!} {!! $enq_subcategory3 !!}</h3>
                    @if(!empty($appdetail[0]->source_name))
                    <div class=" wk-progress pf-status">
                        <div class="col-md-4 col-xs-4">Source Of Business</div>
                        <div class="col-md-4 col-xs-4">
                            <strong>{{$appdetail[0]->source_name}}</strong>
                        </div>
                        <div class="col-md-4 col-xs-4"></div>
                    </div>
                    @endif
                    @if(!empty($appdetail[0]->appbooked))
                    <div class=" wk-progress pf-status">
                        <div class="col-md-4 col-xs-4">Appointment Booked ?</div>
                        <div class="col-md-4 col-xs-4">
                            <strong>{{$appdetail[0]->appbooked}}</strong>
                        </div>
                        <div class="col-md-4 col-xs-4"></div>
                    </div>
                    @endif
                    @if(!empty($appdetail[0]->agentname))
                    <div class=" wk-progress pf-status">
                        <div class="col-md-4 col-xs-4">Call Center Agent Name</div>
                        <div class="col-md-4 col-xs-4">
                            <strong>{{$appdetail[0]->agentname}}</strong>
                        </div>
                        <div class="col-md-4 col-xs-4"></div>
                    </div>
                    @endif
                    @if(!empty($appdetail[0]->showroom))
                    <div class=" wk-progress pf-status">
                        <div class="col-md-4 col-xs-4">Showroom Name</div>
                        <div class="col-md-4 col-xs-4">
                            <strong>{{$appdetail[0]->showroom}}</strong>
                        </div>
                        <div class="col-md-4 col-xs-4"></div>
                    </div>
                    @endif
                    @if(!empty($appdetail[0]->salesman))
                    <div class=" wk-progress pf-status">
                        <div class="col-md-4 col-xs-4">Booked to Salesman</div>
                        <div class="col-md-4 col-xs-4">
                            <strong>{{$appdetail[0]->salesman}}</strong>
                        </div>
                        <div class="col-md-4 col-xs-4"></div>
                    </div>
                    @endif
                    @if(!empty($appdetail[0]->servicecenter))
                    <div class=" wk-progress pf-status">
                        <div class="col-md-4 col-xs-4">Service Center</div>
                        <div class="col-md-4 col-xs-4">
                            <strong>{{$appdetail[0]->servicecenter}}</strong>
                        </div>
                        <div class="col-md-4 col-xs-4"></div>
                    </div>
                    @endif
                    @if(!empty($appdetail[0]->advisorname))
                    <div class=" wk-progress pf-status">
                        <div class="col-md-4 col-xs-4">Service Advisor Name</div>
                        <div class="col-md-4 col-xs-4">
                            <strong>{{$appdetail[0]->advisorname}}</strong>
                        </div>
                        <div class="col-md-4 col-xs-4"></div>
                    </div>
                    @endif
                    @if(!empty($appdetail[0]->interest))
                    <div class=" wk-progress pf-status">
                        <div class="col-md-4 col-xs-4">Brand - Model Of Interest</div>
                        <div class="col-md-4 col-xs-4">
                            <strong>{{$appdetail[0]->interest}}</strong>
                        </div>
                        <div class="col-md-4 col-xs-4"></div>
                    </div>
                    @endif
                    @if(!empty($appdetail[0]->appointmenttype))
                    <div class=" wk-progress pf-status">
                        <div class="col-md-4 col-xs-4">Type of Appoinment</div>
                        <div class="col-md-4 col-xs-4">
                            <strong>{{$appdetail[0]->appointmenttype}}</strong>
                        </div>
                        <div class="col-md-4 col-xs-4"></div>
                    </div>
                    @endif
                    @if(!empty($appdetail[0]->appointmentcode))
                    <div class=" wk-progress pf-status">
                        <div class="col-md-4 col-xs-4">Appointment Code</div>
                        <div class="col-md-4 col-xs-4">
                            <strong>{{$appdetail[0]->appointmentcode}}</strong>
                        </div>
                        <div class="col-md-4 col-xs-4"></div>
                    </div>
                    @endif
                    @if(!empty($appdetail[0]->appointment_datetime))
                    <div class=" wk-progress pf-status">
                        <div class="col-md-4 col-xs-4">Appointment Date & Time</div>
                        <div class="col-md-4 col-xs-4">
                            <strong>{{$appdetail[0]->appointment_datetime}}</strong>
                        </div>
                        <div class="col-md-4 col-xs-4"></div>
                    </div>
                    @endif
                </div>
            </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

<script type="text/javascript">
  function printpage() {


     var tableDiv = document.getElementById("dynamic-table").innerHTML;

        printContents = '';
        printContents += '<table style="border: 1px solid black;border-collapse: collapse;">';
        printContents += tableDiv;
        printContents += '</table>';
    //alert(printContents);
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
  }

  function exportexcel() {
    document.getElementById("exportstatus").value = '1';
    //alert("value");
    document.getElementById("submitbtn").click();
    document.getElementById("exportstatus").value = '0';
  }
</script>

@stop
