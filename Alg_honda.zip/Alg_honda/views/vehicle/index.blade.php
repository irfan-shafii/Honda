@extends('layouts.master')
@section('title', 'Vehicle List')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Vehicle Details</strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                    <tr>
                        <th>Mobile Number</th>
                        <th>Vehicle Type</th>
                        <th>Vehicle Brand</th>
                        <th>Vehicle Model</th>
                        <th>Vehicle Status</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($vehicles as $vehicle)
                    <tr class="gradeX">
                        <td>{{$vehicle->phone_number}}</td>
                        <td>{{$vehicle->vehicle_type}}</td>
                        <td>{{$vehicle->vehicle_brand}}</td>
                        <td>{{$vehicle->vehicle_model}}</td>
                        <td>{{$vehicle->vehicle_status}}</td>
                        <td><a href="{{url('/vehicle')}}/{{$vehicle->id}}" class="btn btn-info btn-xs">View</a> <a href="{{url('/vehicle')}}/{{$vehicle->id}}/edit" class="btn btn-success btn-xs">Edit</a></td>
                    </tr>
                    @endforeach
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

@stop
