@extends('layouts.master')
@section('title', 'Edit Vehicle')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-sm-12">
                
                    <form action="{{url('/')}}/vehicle/{{$vehicle[0]->id}}/update" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <header class="panel-heading">
                            Vehicle Details
                        </header>
                        <div class="panel-body">
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Mobile Number</label>
                                    <input size="16" type="text" value="{{$vehicle[0]->phone_number}}" name="mobile" class="form_date form-control">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Vehicle Type</label>
                                    <select class="form-control" name="type" style="width: 300px">
                                        <option value="">Select</option>
                                        <option @if($vehicle[0]->vehicle_type == 'SUV') selected="" @endif value="SUV">SUV</option>
                                        <option @if($vehicle[0]->vehicle_type == 'MPV') selected="" @endif value="MPV">MPV</option>
                                        <option @if($vehicle[0]->vehicle_type == 'Crossover') selected="" @endif value="Crossover">Crossover</option>
                                        <option @if($vehicle[0]->vehicle_type == 'Hatchback') selected="" @endif value="Hatchback">Hatchback</option>
                                        <option @if($vehicle[0]->vehicle_type == 'Sedan') selected="" @endif value="Sedan">Sedan</option>
                                        <option @if($vehicle[0]->vehicle_type == 'Coupe') selected="" @endif value="Coupe">Coupe</option>
                                        <option @if($vehicle[0]->vehicle_type == 'Convertible') selected="" @endif value="Convertible">Convertible</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Vehicle Brand</label>
                                    <select class="form-control" name="brand" id="brand" style="width: 300px" onChange="getmodel(this.value);">
                                        <option value="">Select</option>
                                        <option @if($vehicle[0]->vehicle_brand == 'Honda') selected="" @endif value="Honda">Honda</option>
                                        <option @if($vehicle[0]->vehicle_brand == 'Chevrolet') selected="" @endif value="Chevrolet">Chevrolet</option>
                                        <option @if($vehicle[0]->vehicle_brand == 'Cadillac') selected="" @endif value="Cadillac">Cadillac</option>
                                        <option @if($vehicle[0]->vehicle_brand == 'Ford') selected="" @endif value="Ford">Ford</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Vehicle Model</label>
                                    <div id="vehmodel">                                        
                                    <select class="form-control" name="model" id="model" style="width: 300px" onChange="getmodel(this.value);">
                                        <option value="{{$vehicle[0]->vehicle_model}}">{{$vehicle[0]->vehicle_model}}</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Plate No</label>
                                    <input type="text" class="form-control" name="plateno" value="{{$vehicle[0]->vehicle_plate_no}}" id="message">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Chasis No</label>
                                    <input type="text" class="form-control" name="chasisno" value="{{$vehicle[0]->vehicle_chasis_no}}" id="message">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Model Year</label>
                                    <input type="text" class="form-control" name="modelyear" value="{{$vehicle[0]->vehicle_model_year}}" id="message">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Dealer Name</label>
                                    <input size="16" type="text" value="{{$vehicle[0]->dealer}}" name="dealer" class="form-control">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Name Of Town</label>
                                    <input size="16" type="text" value="{{$vehicle[0]->town}}" name="town" class="form-control">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Date Of Sale</label>
                                    <input size="16" type="text" value="{{$vehicle[0]->vehicle_date_of_sale}}" name="dosale" class="form-control form-control-inline input-medium default-date-picker" autocomplete="on">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Warranty Years</label>
                                    <input size="16" type="text" value="{{$vehicle[0]->vehicle_warranty_years}}" name="warranty" class="form-control">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Vehicle Status</label>
                                    <select class="form-control" name="status" style="width: 300px">
                                        <option value="">Select</option>
                                        <option @if($vehicle[0]->vehicle_status == 'Ready To Delivery') selected="" @endif value="Ready To Delivery">Ready To Delivery</option>
                                        <option @if($vehicle[0]->vehicle_status == 'Waiting For Approval') selected="" @endif value="Waiting For Approval">Waiting For Approval</option>
                                        <option @if($vehicle[0]->vehicle_status == 'Parts Not Available') selected="" @endif value="Parts Not Available">Parts Not Available</option>
                                    </select>
                                </div>

                        </div>
                    </section>
            </div>
            <div class="col-md-12">
                
                    <section class="panel">
                        <header class="panel-heading">
                            Description
                        </header>
                        <div class="panel-body">
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">WIP Number</label>
                                    <input size="16" type="text" value="" name="wipnumber" class="form_date form-control">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Description</label>
                                    <textarea size="16" type="text" value="" name="description" class="form-control"></textarea>
                                </div>
                                <input type="hidden" name="vehicleid" value="{{$vehicle[0]->id}}">
                                <input type="hidden" name="mobile" value="{{$vehicle[0]->phone_number}}">
                                <div class="form-group col-md-4">
                                <button type="submit" class="form-control btn btn-success btn-block">Submit</button>
                                <a href="javascript: history.go(-1)" class="form-control btn btn-danger btn-block">Close</a>
                                </div>
                            </form>

                        </div>

                    <header class="panel-heading">
                        <strong>Vehicle Descriptions</strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="table1">
                    <thead>
                    <tr>
                        <th>Wip Number</th>
                        <th>Description</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($vehicle_descriptions as $descriptions)
                    <tr class="gradeX">
                        <td>{{$descriptions->vehicle_wip_no}}</td>
                        <td>{{$descriptions->vehicle_description}}</td>
                    </tr>
                    @endforeach
                    </table>
                    </div>
                    </div>
                    </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

<script type="text/javascript">
    function getmodel(id) {
        //alert(id);
        $("#vehmodel").html("");
        var brand = id;
        var Honda = ['accord','city'];
        var Chevrolet = ['tahoe','impala'];
        var Cadillac = ['cts','sts'];
        var Ford = ['taurus','edge'];
        var divHTML = "";
        divHTML += "<select class='form-control' name='model' id='model'>";
        if(brand == 'Honda'){            
            divHTML += "<option value='"+Honda[0]+"'>"+Honda[0]+"</option>";
            divHTML += "<option value='"+Honda[1]+"'>"+Honda[1]+"</option>";
        }
        else if(brand == 'Chevrolet'){            
            divHTML += "<option value='"+Chevrolet[0]+"'>"+Chevrolet[0]+"</option>";
            divHTML += "<option value='"+Chevrolet[1]+"'>"+Chevrolet[1]+"</option>";
        }
        else if(brand == 'Cadillac'){            
            divHTML += "<option value='"+Cadillac[0]+"'>"+Cadillac[0]+"</option>";
            divHTML += "<option value='"+Cadillac[1]+"'>"+Cadillac[1]+"</option>";
        }
        else if(brand == 'Ford'){            
            divHTML += "<option value='"+Ford[0]+"'>"+Ford[0]+"</option>";
            divHTML += "<option value='"+Ford[1]+"'>"+Ford[1]+"</option>";
        }
            divHTML += "</select>";
        //alert(divHTML);
            $("#vehmodel").html(divHTML);

    }

// window.onload = function() {  
//     var brand = $("#brand").val();
// //alert(brand);
//     getmodel(brand);
// }
</script>

@stop
