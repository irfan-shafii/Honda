@extends('layouts.master')
@section('title', 'New Vehicle')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-md-12">
                
                    <section class="panel">
                        <div class="panel-body">
                                            <h3 class="prf-border-head">Vehicle Details <a href="javascript: history.go(-1)" class="pull-right btn btn-info btn-xs">Go Back</a></h3>
                                            <div class=" wk-progress pf-status">
                                                <div class="col-md-8 col-xs-8">Mobile Number</div>
                                                <div class="col-md-4 col-xs-4">
                                                    <strong>{{$vehicle[0]->phone_number}}</strong>
                                                </div>
                                            </div>
                                            <div class=" wk-progress pf-status">
                                                <div class="col-md-8 col-xs-8">Vehicle Type</div>
                                                <div class="col-md-4 col-xs-4">
                                                    <strong>{{$vehicle[0]->vehicle_type}}</strong>
                                                </div>
                                            </div>
                                            <div class=" wk-progress pf-status">
                                                <div class="col-md-8 col-xs-8">Vehicle Brand</div>
                                                <div class="col-md-4 col-xs-4">
                                                    <strong>{{$vehicle[0]->vehicle_brand}}</strong>
                                                </div>
                                            </div>
                                            <div class=" wk-progress pf-status">
                                                <div class="col-md-8 col-xs-8">Vehicle Model</div>
                                                <div class="col-md-4 col-xs-4">
                                                    <strong>{{$vehicle[0]->vehicle_model}}</strong>
                                                </div>
                                            </div>
                                            <div class=" wk-progress pf-status">
                                                <div class="col-md-8 col-xs-8">Plate Number</div>
                                                <div class="col-md-4 col-xs-4">
                                                    <strong>{{$vehicle[0]->vehicle_plate_no}}</strong>
                                                </div>
                                            </div>
                                            <div class=" wk-progress pf-status">
                                                <div class="col-md-8 col-xs-8">Chasis Number</div>
                                                <div class="col-md-4 col-xs-4">
                                                    <strong>{{$vehicle[0]->vehicle_chasis_no}}</strong>
                                                </div>
                                            </div>
                                            <div class=" wk-progress pf-status">
                                                <div class="col-md-8 col-xs-8">Model Year</div>
                                                <div class="col-md-4 col-xs-4">
                                                    <strong>{{$vehicle[0]->vehicle_model_year}}</strong>
                                                </div>
                                            </div>
                                            <div class=" wk-progress pf-status">
                                                <div class="col-md-8 col-xs-8">Date Of Sale</div>
                                                <div class="col-md-4 col-xs-4">
                                                    <strong>{{$vehicle[0]->vehicle_date_of_sale}}</strong>
                                                </div>
                                            </div>
                                            <div class=" wk-progress pf-status">
                                                <div class="col-md-8 col-xs-8">Warrenty Years</div>
                                                <div class="col-md-4 col-xs-4">
                                                    <strong>{{$vehicle[0]->vehicle_warranty_years}}</strong>
                                                </div>
                                            </div>
                                            <div class=" wk-progress pf-status">
                                                <div class="col-md-8 col-xs-8">Status</div>
                                                <div class="col-md-4 col-xs-4">
                                                    <strong>{{$vehicle[0]->vehicle_status}}</strong>
                                                </div>
                                        </div>

                        </div>
                    </section>
            </div>
            <div class="col-md-12">
                

                    <header class="panel-heading">
                        <strong>Vehicle Descriptions</strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="table1">
                    <thead>
                    <tr>
                        <th>Wip Number</th>
                        <th>Description</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($vehicle_descriptions as $descriptions)
                    <tr class="gradeX">
                        <td>{{$descriptions->vehicle_wip_no}}</td>
                        <td>{{$descriptions->vehicle_description}}</td>
                    </tr>
                    @endforeach
                    </table>
                    </div>
                    </div>
                    </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

<script type="text/javascript">
    function getmodel(id) {
        //alert(id.value);
            $("#vehmodel").html("");
        var brand = id.value;
        var Honda = ['accord','city'];
        var Chevrolet = ['tahoe','impala'];
        var Cadillac = ['cts','sts'];
        var Ford = ['taurus','edge'];
        var divHTML = "";
        divHTML += "<select class='form-control' name='model'>";
        if(brand == 'Honda'){            
            divHTML += "<option value='"+Honda[0]+"'>"+Honda[0]+"</option>";
            divHTML += "<option value='"+Honda[1]+"'>"+Honda[1]+"</option>";
        }
        else if(brand == 'Chevrolet'){            
            divHTML += "<option value='"+Chevrolet[0]+"'>"+Chevrolet[0]+"</option>";
            divHTML += "<option value='"+Chevrolet[1]+"'>"+Chevrolet[1]+"</option>";
        }
        else if(brand == 'Cadillac'){            
            divHTML += "<option value='"+Cadillac[0]+"'>"+Cadillac[0]+"</option>";
            divHTML += "<option value='"+Cadillac[1]+"'>"+Cadillac[1]+"</option>";
        }
        else if(brand == 'Ford'){            
            divHTML += "<option value='"+Ford[0]+"'>"+Ford[0]+"</option>";
            divHTML += "<option value='"+Ford[1]+"'>"+Ford[1]+"</option>";
        }
            divHTML += "</select>";
        //alert(divHTML);
            $("#vehmodel").html(divHTML);

    }
</script>

@stop
