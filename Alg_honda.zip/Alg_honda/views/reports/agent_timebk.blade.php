@extends('layouts.master')
@section('title', 'Agents Performance Report')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-md-12">
                <section class="panel">
                    <div class="panel-body">
                        <form action="{{url('/')}}/report/agent_performance" class="form-horizontal ">
                        {{csrf_field()}}

                            <div class="form-group col-md-6">
                                <label class="control-label col-md-4">Select Date Range :</label>
                                <div class="col-md-8">
                                    <div class="input-group input-large" data-date="{{date('Y-m-d')}}" data-date-format="mm/dd/yyyy">
                                        <input type="text" class="form-control dpd1" name="fdate" value="{{$fromdate}}">
                                        <span class="input-group-addon">To</span>
                                        <input type="text" class="form-control dpd2" name="tdate" value="{{$todate}}">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group col-md-6">
                                <label class=" col-md-4 control-label">Campaign :</label>
                                <div class="col-md-8">
                                    <select id="e1" class="populate" name="campaign" style="width: 300px">
                                      @foreach($campaigns as $camp)
                                      <option value="{{$camp->campaign_id}}" @if($camp->campaign_id == $campaign) selected="" @endif>{{$camp->campaign_name}}</option>
                                      @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-12"></div>
                            <div class="form-group col-md-6">
                                <label class=" col-md-4 control-label">Inbound Groups :</label>
                                <div class="col-md-8">
                                    <select id="e2" class="populate" style="width: 300px" name="usergroup">
                          @foreach($usergroups as $group)
                          <option value="{{$group->user_group}}" @if($group->user_group == $usergroup) selected="" @endif>{{$group->group_name}}</option>
                          @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="form-group pull-right col-md-6">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Agents Performance Report <a href="#" class="pull-right btn btn-space btn-xs btn-warning" onclick="printpage();">Export / Print</a></strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                    <tr>
                    <th>Agent Name</th>
                    <th>User ID</th>
                    <th>User Group</th>
                    <th>Calls</th>
                    <th>Time</th>
                    <th>Talk</th>
                    <th>Talk Avg</th>
                    <th>Pause</th>
                    <th>Pause Avg</th>
                    <th>Wait</th>
                    <th>Wait Avg</th>
                    <th>Dispo</th>
                    <th>Dispo Avg</th>
                    <!-- <th>Dead</th>
                    <th>Dead Avg</th> -->
                    <th>Auto</th>
                    </tr>
                    </thead>
                    <tbody>
                  @if(count($closer_log) > 0)
                  @foreach($closer_log as $log)
                  <?php $all_secs = $all_sec->where('user',$log->user);
                  $auto = $all_secs->where('status','auto')->count();
                  $talk_sec = $all_secs->sum('talk_sec');
                  $talk_avg = App\Average::MathZDC($talk_sec,$auto);
                  $pause_sec = $all_secs->sum('pause_sec');
                  $pause_avg = App\Average::MathZDC($pause_sec,$auto);
                  $wait_sec = $all_secs->sum('wait_sec');
                  $wait_avg = App\Average::MathZDC($wait_sec,$auto);
                  $dispo_sec = $all_secs->sum('dispo_sec');
                  $dispo_avg = App\Average::MathZDC($dispo_sec,$auto);
                  $dead_sec = $all_secs->sum('dead_sec');
                  $dead_avg = App\Average::MathZDC($dead_sec,$auto);
                  $call_time = $talk_sec+$pause_sec+$wait_sec+$dispo_sec;
                  //print_r($log->calls."<br>");
                  ?>
                    <tr class="gradeX">
                    <td>{{$log->full_name}}</td>
                    <td>{{$log->user}}</td>
                    <td>{{$log->user_group}}</td>
                    <td>{{$auto}}</td>
                    <td>{{App\Average::toMinutes($call_time)}}</td>
                    <td>{{App\Average::toMinutes($talk_sec)}}</td>
                    <td>{{gmdate("H:i:s", $talk_avg)}}</td>
                    <td>{{App\Average::toMinutes($pause_sec)}}</td>
                    <td>{{gmdate("H:i:s", $pause_avg)}}</td>
                    <td>{{App\Average::toMinutes($wait_sec)}}</td>
                    <td>{{gmdate("H:i:s", $wait_avg)}}</td>
                    <td>{{App\Average::toMinutes($dispo_sec)}}</td>
                    <td>{{gmdate("H:i:s", $dispo_avg)}}</td>
                    <!-- <td>{{App\Average::toMinutes($dead_sec)}}</td>
                    <td>{{gmdate("H:i:s", $dead_avg)}}</td> -->
                    <td>{{$auto}}</td>
                    </tr>
                  @endforeach
                  @endif
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')
<script type="text/javascript">
  function printpage() {


     var tableDiv = document.getElementById("dynamic-table").innerHTML;

        printContents = '';
        printContents += '<table style="border: 1px solid black;border-collapse: collapse;">';
        printContents += tableDiv;
        printContents += '</table>';
    //alert(printContents);
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
  }
</script>

@stop
