@extends('layouts.master')
@section('title', 'Team Performance Details')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 

           <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/report')}}/team/performance" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">

                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">From Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($fromdate))}}" name="fromdate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>

                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">To Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($todate))}}" name="todate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>

                                <div class="form-group col-md-4">
			                    <label>Campaigns :</label>
			                      <select class="form-control" name="campaign">
			                          <option value="">Select All</option>
			                          @foreach($campaigns as $camp)
			                          <option value="{{$camp->campaign_id}}" @if($camp->campaign_id == $campaign) selected="" @endif>{{$camp->campaign_name}}</option>
			                          @endforeach
			                      </select>
                                </div>

                                <div class="form-group col-md-4">
			                    <label>Inbound Groups</label>
			                      <select class="select2 form-control" name="usergroup">
			                          <option value="">Select All</option>
			                          @foreach($usergroups as $group)
			                          <option value="{{$group->user_group}}" @if($group->user_group == $usergroup) selected="" @endif>{{$group->group_name}}</option>
			                          @endforeach
			                      </select>
                                </div>

                            <div class="form-group pull-right col-md-6">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                            </div>
                        </section>

                        </form>
                    </div>
            </div>

        @foreach($usergroups as $group)
        <?php 
            $team_agents = $closer_log->where('user_group',$group->user_group); 
        ?>

        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>{{$group->group_name}}</strong><span class="pull-right">Total <strong>{{count($team_agents)}}</strong> Records</span>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                  @if(count($team_agents) > 0)
                    <table class="table table-bordered table-striped table-condensed cf">
                    <thead>
                    <tr>
                        
                    <th>Agent Name</th>
                    <th>ID</th>
                    <th>Calls</th>
                    <th>Leads</th>
                    <th>Contacts</th>
                    <th>Contact Ratio</th>
                    <th>Non-Pause Time</th>
                    <th>System Time</th>
                    <th>Talk Time</th>
                    <th>Sales</th>
                    <th>Sales Per Working Hour</th>
                    <th>Sales To Leads Ratio</th>
                    <th>Sales Per Hour</th>
                    <th>Incomplete Sales</th>
                    <th>Cancelled Sales</th>
                    <th>Callbacks</th>
                    <th>First Call Resolution</th>
                    <th>Avg Sales Time</th>
                    <th>Avg Contact Time</th>
                    </tr>
                    </thead>
                    <tbody>
                  @if(count($closer_log) > 0)
                  @foreach($closer_log as $log)
                  <?php $all_secs = $all_sec->where('user',$log->user);
                  $leads = $all_secs->where('lead_id', '!=', NULL)->count();
                  $auto = $all_secs->where('status', '!=', NULL)->count();
                  $dnc_calls = $all_secs->where('status','DNC')->count();
                  $dnc_per = App\Average::MathPER($dnc_calls,$auto);
                  ?>
                  <tr class="">
                    <td>{{$log->full_name}}</td>
                    <td>{{$log->user}}</td>
                    <td>{{$auto}}</td>
                    <td>{{$leads}}</td>
                    <td>{{$dnc_per}}%</td>
                    <td>{{$auto}}</td>
                    <td>{{$log->full_name}}</td>
                    <td>{{$log->user}}</td>
                    <td>{{$auto}}</td>
                    <td>{{$leads}}</td>
                    <td>{{$dnc_per}}%</td>
                    <td>{{$auto}}</td>
                    <td>{{$log->full_name}}</td>
                    <td>{{$log->user}}</td>
                    <td>{{$auto}}</td>
                    <td>{{$leads}}</td>
                    <td>{{$dnc_per}}%</td>
                    <td>{{$auto}}</td>
                    <td>{{$auto}}</td>
                  </tr>
                  @endforeach
                  @endif
                    </table>
                  @endif
                    </div>
                    </div>
                </section>
            </div>
        </div>
                  @endforeach


@stop
@section('ScriptPage')

@stop
