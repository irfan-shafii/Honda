@extends('layouts.master')
@section('title', 'Agent Time Report')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 

           <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/report')}}/agent/status" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">

                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">From Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($fromdate))}}" name="fromdate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>

                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">To Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($todate))}}" name="todate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>

                                <div class="form-group col-md-4">
			                    <label>Campaigns :</label>
			                      <select class="form-control" name="campaign">
			                          <option value="">Select All</option>
			                          @foreach($campaigns as $camp)
			                          <option value="{{$camp->campaign_id}}" @if($camp->campaign_id == $campaign) selected="" @endif>{{$camp->campaign_name}}</option>
			                          @endforeach
			                      </select>
                                </div>

                                <div class="form-group col-md-4">
			                    <label>Inbound Groups</label>
			                      <select class="select2 form-control" name="usergroup">
			                          <option value="">Select All</option>
			                          @foreach($usergroups as $group)
			                          <option value="{{$group->user_group}}" @if($group->user_group == $usergroup) selected="" @endif>{{$group->group_name}}</option>
			                          @endforeach
			                      </select>
                                </div>
                                <input type="hidden" name="exportstatus" id="exportstatus" value="0">
                            <div class="form-group col-md-4">
                            <button type="submit" class="btn btn-primary" id="submitbtn" style="display: none;"><i class="fa fa-search"></i> Search</button>
                            <a href="#" class="btn btn-primary btn-block" onclick="searchbtn();"><i class="fa fa-search"></i> Search</a>
                            </div>
                            <div class="form-group col-md-4">
                            <a href="#" class="btn btn-warning btn-block" onclick="exportbtn();"><i class="fa fa-upload"></i> Export</a>
                            </div>
                        </section>

                        </form>
                    </div>
            </div>

        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Agent Status Details </strong><span class="pull-right">Total <strong>{{$tcount}}</strong> Records </span>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                    <tr>
                        
                    <th>Agent Name</th>
                    <th>User ID</th>
                    <th>Calls</th>
                    <th>CIcalls</th>
                    <th>DNC/CI%</th>
                    <th>Answer</th>
                    </tr>
                    </thead>
                    <tbody>
                      {!!$divhtml!!}
                    </tbody>
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>


@stop
@section('ScriptPage')
<script type="text/javascript">
    
    function exportbtn() {
            document.getElementById('exportstatus').value = '1';
            document.getElementById('submitbtn').click();          
    } 

    function searchbtn() {
    document.getElementById('exportstatus').value = '0';
    document.getElementById('submitbtn').click();
    }  
</script>

@stop
