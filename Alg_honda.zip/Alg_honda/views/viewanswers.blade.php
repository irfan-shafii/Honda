@extends('layouts.master')
@section('title', 'CSI Answers')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 <style type="text/css">
    .bg-terques {
    background: #345050 !important;
}
</style>
 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/useranswers" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">

                                <div class="form-group col-md-12">
                                	<a class="btn btn-primary"> {{$csi_master[0]->mobile}} / {{$csi_master[0]->agent_id}} / {{$csi_master[0]->date_time}} / {{$vehdetails}} / {{$listname}}</a>
                                </div>

                    </div>
                	</section>
                  </form>
            </div>
        </div>

           <div class="row">
                    <div class="col-md-12">
                        <!--collapse start-->
                        <div class="panel-group m-bot20" id="accordion">
                            <div class="panel">
                                <?php 
                                $qno = 1; ?>
                                    <div class="panel-body">
                                @if(count($questions) > 0)
                                        @foreach($questions as $ques)
                                            <!-- Comment -->
                                            <div class="msg-time-chat">
                                                <div class="message-body msg-in">
                                                    <span class="arrow"></span>
                                                    <div class="text">
                                                        <div class="second bg-terques ">
                                                            {{$qno}} . {!!$ques->question!!}
                                                        </div>
                                                        <div class="second bg-red">
                                                            {{$ques->answer}}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /comment -->
                                            <?php $qno++; ?>
                                @endforeach
                              @endif
                                    </div>
                                </div>
                    </div>
                </div>
            </div>

       
@stop
@section('ScriptPage')

@stop
