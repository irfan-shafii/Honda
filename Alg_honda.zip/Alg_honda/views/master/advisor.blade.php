@extends('layouts.master')
@section('title', 'Sales Advisor')
@section('breadCrumbs')
        
@stop

@section('pageBody')
         <div class="row">
            <div class="col-sm-12">
                

                    <form action="{{url('/master')}}/advisor/store" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <header class="panel-heading">
                           Add Sales Advisor
                        </header>
                        <div class="panel-body">
                                <div class="form-group col-md-3">
                                    <label for="in_arabic">Select Service Center</label>
                                    <select class="form-control" name="center_id" required="">
                                        <option value="">Select</option>
                                        @foreach($showrooms as $show)
                                        <option value="{{$show->id}}">{{$show->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="in_arabic">Name Of Sales Advisor</label>
                                    <input type="text" class="form-control" name="name">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="in_arabic">Description </label>
                                    <textarea type="text" class="form-control" name="description"></textarea>
                                </div>
                                <div class="form-group col-md-3 pull-right">

                                <button type="submit" class="btn btn-success btn-block">SAVE</button>
                                
                                </div>
                    </form>

                        </div>
                    </section>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                       Salesmans Table
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Service Center</th>
                        <th>Sales Advisor</th>
                        <th>Description</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($salesmans as $log)
                    <tr>
                        <td>{{$log->id}}</td>
                        <td>{{DB::table('service_centers')->find($log->center_id)->name}}</td>
                        <td>{{$log->name}}</td>
                        <td>{{$log->description}}</td>
                        <td><a href="{{url('/master/advisor')}}/{{$log->id}}/delete" class="btn btn-danger btn-xs">Delete</a></td>
                    </tr>
                    @endforeach
                    </tbody>
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')


@stop
