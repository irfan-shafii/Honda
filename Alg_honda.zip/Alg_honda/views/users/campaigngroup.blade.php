@extends('layouts.master')
@section('title', 'Campaigns Usergroup List')
@section('breadCrumbs')
        
@stop

@section('pageBody')
        <!-- page start--> 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/users/usergroupstore" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">
                                <div class="form-group col-md-4">
                                    <label for="exampleI">Campaigns</label>
                                    <select name="campaigns" id="campaigns" class="form-control" required="">
                                        <option value="">Select</option>
                                        @foreach($campaigns as $list)
                                        <option value="{{$list->campaign_id}}">{{$list->campaign_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleI">User Groups</label>
                                    <select name="groups" id="groups" class="form-control">
                                        <option value="---ALL---">Select All</option>
                                        @foreach($usergroups as $groups)
                                        <option value="{{$groups->user_group}}">{{$groups->user_group}} - {{$groups->group_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            <div class="form-group pull-right col-md-4">
                            <button type="submit" id="submitbtn" class="form-control btn btn-primary btn-block"><i class="fa fa-search"></i> Submit</button>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Campaigns Usergroup Details </strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Campaign</th>
                        <th>User Groups</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($campaigns as $user)
                    <tr class="gradeX">
                        <td>{{$user->campaign_id}}</td>
                        <td>{{$user->campaign_name}}</td>
                        <td>{{$user->user_group}}</td>
                        
                    </tr>
                    @endforeach
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

@stop
