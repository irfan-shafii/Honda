@extends('layouts.master')
@section('title', 'User Edit')
@section('breadCrumbs')
        
@stop

@section('pageBody')
        <!-- page start--> 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/users/{{$user->id_user}}/update" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">
                                <div class="form-group col-md-4">
                                    <label for="exampleI">Name</label>
                                    <input type="text" name="name" class="form-control" value="{{$user->name}}">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleI">User ID</label>
                                    <input type="text" name="email" class="form-control" value="{{$user->email}}">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleI">Password</label>
                                    <input type="password" name="password" class="form-control" placeholder="Enter Your Password">
                                </div>

                                <input type="hidden" name="cpassword" value="{{$user->password}}">
                                <div class="form-group col-md-4">
                                    <label for="exampleI">Campaigns</label>
                                    <select multiple name="campaigns[]" id="e9" style="width:300px" class="populate" required="">
                                        @foreach($campaigns as $list)
                                        <?php $cids = 'xx_xx,'.$user->campaignid; $cid = $list->campaign_id; ?>
                                        <option value="{{$list->campaign_id}}" @if(strpos($cids, $cid) == true) selected="" @endif>{{$list->campaign_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleI">User Groups</label>
                                    <select multiple name="groups[]" id="e1" style="width:300px" class="populate">
                                        @foreach($usergroups as $groups)
                                        <?php $uids = 'xx_xx,'.$user->usergroups; $uid = $groups->user_group; ?>
                                        <option value="{{$groups->user_group}}" @if(strpos($uids, $uid) == true) selected="" @endif>{{$groups->group_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            <div class="form-group pull-right col-md-4">
                            <button type="submit" id="submitbtn" class="form-control btn btn-primary btn-block"><i class="fa fa-search"></i> Submit</button>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

<script type="text/javascript">
  function printpage() {


     var tableDiv = document.getElementById("dynamic-table").innerHTML;

        printContents = '';
        printContents += '<table style="border: 1px solid black;border-collapse: collapse;">';
        printContents += tableDiv;
        printContents += '</table>';
    //alert(printContents);
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
  }

  function exportexcel() {
    document.getElementById("exportstatus").value = '1';
    //alert("value");
    document.getElementById("submitbtn").click();
    document.getElementById("exportstatus").value = '0';
  }
</script>

@stop
