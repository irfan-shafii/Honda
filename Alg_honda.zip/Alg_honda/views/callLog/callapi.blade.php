@extends('layouts.master')
@section('title', 'Call Api')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-md-12">
                
                    <section class="panel">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <div class="panel-body">

                                <div class="form-group col-md-3">
                                    <label for="exampleInputPassword1">Type</label>
                                    <input size="16" type="text" value="incoming" name="type" id="type" class="form-control">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleInputPassword1">leadID</label>
                                    <input size="16" type="text" value="1234" name="lead" id="lead" class="form-control">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleInputPassword1">event</label>
                                    <input size="16" type="text" value="start" name="event" id="event" class="form-control">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleInputPassword1">phoneNumber</label>
                                    <input size="16" type="text" value="67771404" name="phone" id="phone" class="form-control">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleInputPassword1">agent_email</label>
                                    <input size="16" type="text" value="irfan@centrixplus.com" name="email" id="email" class="form-control">
                                </div>
                            <div class="col-md-3"><br>
                            <a href="#" class="btn btn-danger" id="add-json"><i class="fa fa-upload"></i> POST</a>
                            </div>

                    </div>
                </section>
            </div>
        </div>
       
@stop
@section('ScriptPage')
<script type="text/javascript">

$(function (){
 $("#add-json").click(function(){

    var type=$('#type').val();
    var lead=$('#lead').val();
    var event=$('#event').val();
    var phone=$('#phone').val();
    var email=$('#email').val();

    var postData = 
                {
                    "Type" : type,
                    "leadID" : lead,
                    "event"   :event,
                    "phoneNumber": phone,
                    "agent_email": email
                }
    var dataString = JSON.stringify(postData);

    $.ajax({
            type: "POST",
            dataType: "json",
            url: "https://api.kustomerapp.com/v1/hooks/form/5f0885b734878c0012b7ccf8/32176f14c574b2d4c72be1db6a19c20f7889b92c938f2cf40470951328dc95a7",
            data: {myData:postData},
            contentType: "application/json; charset=utf-8",
            success: function(data){
                console.log(data);
                alert(JSON.stringify(data));
            },
            error: function(e){
                console.log(e.message);
            }
    });


});
});
</script>
@stop
