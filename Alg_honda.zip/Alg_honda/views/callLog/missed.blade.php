@extends('layouts.master')
@section('title', 'Missed Call Report')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/report/missed" method="post">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                    <section class="panel">
                       @if(!empty($alert))
                            <div class="alert alert-success fade in">
                                <strong>Success!</strong> {{ $alert }}.
                            </div>
                       @endif
                        <div class="panel-body">

                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">From Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($fromdate))}}" name="fromdate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">To Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($todate))}}" name="todate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Phone Number</label>
                                    <input size="16" type="text" value="{{$phone}}" name="phone" class="form-control">
                                </div>
                            <div class="form-group col-md-4">
                                <label for="exampleI">In Groups</label><br>
                                <select multiple name="groups[]" id="e1" style="width:310px" class="populate">
                                    @foreach($ingroups as $groups)
                                    <?php $uids = 'xx_xx,'.$ingroups1; $uid = $groups->group_id; ?>
                                    <option value="{{$groups->group_id}}" @if(strpos($uids, $uid) == true) selected="" @endif>{{$groups->group_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="exampleInputEmail1">List ID</label>

                                <select class="form-control" name="listid" id="listid">
                                    <option value="">Select</option>
                                    @foreach($lists as $list)
                                    <option value="{{$list->list_id}}" @if($list->list_id == $listid) selected="" @endif>{{$list->list_name}}</option>     
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                            <a class="btn btn-info btn-xs btn-block">Total Missedcalls <span class="badge"> {{$total_count}}</span></a>
                            <a class="btn btn-info btn-xs btn-block">Pending Missedcalls <span class="badge"> {{$missed_count}}</span></a>
                            </div>
                            <div class="col-md-12"></div>
                            <input type="hidden" name="exportstatus" id="exportstatus" value="0">
                            <input type="hidden" name="uploadstatus" id="uploadstatus" value="0">
                            <div class="form-group col-md-4">
                            <a href="#" class="btn btn-warning" onclick="exportexcel();"><i class="fa fa-arrows-alt"></i> Export</a>
                            </div>
                            <div class="form-group col-md-4">
                            <a href="#" class="btn btn-danger" onclick="uploadmissed();"><i class="fa fa-upload"></i> Upload</a>
                            </div>
                            <div class="form-group col-md-4">
                            <button type="submit" class="btn btn-success" id="submitbtn"><i class="fa fa-search"></i> Search</button>
                            </div>
                        </form>
                    </div>
                </section>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Missed Call Report </strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                    <tr>
                    <th>Lead ID</th>
                    <th>Phone</th>
                    <th>Ingroup</th>
                    <th>Call Date</th>
                    <th>Status</th>
                    <th>User</th>
                    <th>List ID</th>
                    <th>Length</th>
                    </tr>
                    </thead>
                    <tbody>
                  @if(count($dial_logs) > 0)
                  @foreach($dial_logs as $log)
                    <?php
                    $listnames = App\VicidialLists::select('list_name')->where('list_id',$log->list_id)->get();
                    $listname =  'ListName';
                    if(count($listnames) > 0){
                       $listname =  $listnames[0]->list_name;
                    } 
                    ?>
                    <tr class="gradeX">
                    <td>{{$log->lead_id}}</td>
                    <td>{{$log->phone_number}}</td>
                    <td>{{$log->campaign_id}}</td>
                    <td>{{$log->call_date}}</td>
                    <?php $fdate = date("Y-m-d", strtotime($log->call_date));
                        $tdate = date('Y-m-d', strtotime("+1 day", strtotime($fdate)));
                     $status_answer = App\VicidialCloserLog::where('phone_number',$log->phone_number)->where('call_date','>',$log->call_date)->where('closecallid','>',$log->closecallid)->where('status','!=','DROP')->where('length_in_sec','>','0')->get();
                     $status_log = App\VicidialLog::where('phone_number',$log->phone_number)->where('call_date','>',$log->call_date)->where('length_in_sec','>','0')->get();
                     if(count($status_answer) > 0){
                        echo '<td style="color:#4caf50;">Answer</td>';
                     }
                     elseif(count($status_log) > 0){
                        echo '<td style="color:#673ab7;">Call Back</td>';
                     }
                     else{                       
                        echo '<td style="color:#c52317;">'.$log->status.'</td>';
                     }
                     
                      ?>
                    <td>{{$log->user}}</td>
                    <td>{{$listname}}</td>
                    <td>{{App\Average::toMinutes($log->length_in_sec)}}</td>
                    </tr>
                  @endforeach
                  @endif
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

<script type="text/javascript">

  function exportexcel() {
    document.getElementById("exportstatus").value = '1';
    //alert("value");
    document.getElementById("submitbtn").click();
    document.getElementById("exportstatus").value = '0';
  }

function uploadmissed() {
  $("#uploadstatus").val(1);
  $("#submitbtn").click();
}
  
  function printpage() {


     var tableDiv = document.getElementById("dynamic-table").innerHTML;

        printContents = '';
        printContents += '<table style="border: 1px solid black;border-collapse: collapse;">';
        printContents += tableDiv;
        printContents += '</table>';
    //alert(printContents);
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
  }
</script>
@stop
