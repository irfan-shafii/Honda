<?php


echo "callapi";



            $curl = curl_init();
             $centre = 'SO_25';
             $vehmagic = '634637';
             $brand = 'Chevrolet';
            $date90 = date('Y-m-d', strtotime("-90 day"));
            //echo $date90;
            $sendDATA = "{\r\n\r\n    \"brand\":\"".$brand."\",\r\n    \"query\": \"SELECT  ".$centre."_Headr.BookedInOperator, ".$centre."_Headr.BookedOutOperator,".$centre."_Headr.WLInOut, ".$centre."_Headr.WLDateIn, ".$centre."_Headr.BookingStatus, ".$centre."_Headr.WIPNumber,".$centre."_Headr.Registration, ".$centre."_Headr.MagicMKVehicle, ".$centre."_Headr.Status FROM ".$centre."_Headr WHERE ( ".$centre."_Headr.WLDateOut Is Null) AND ( ".$centre."_Headr.WLInOut='IN') AND ( ".$centre."_Headr.MagicMKVehicle in (' ".$vehmagic." ')) AND (".$centre."_Headr.WLDateIn>{d '".$date90."'})\"\r\n}";
            curl_setopt_array($curl, array(
            CURLOPT_URL => "https://172.16.5.69/odbc/getdetailsfromodbc",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_POSTFIELDS =>$sendDATA,
            CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json"
            ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);
            echo $response;
            echo "<br>".$sendDATA;
            $data = json_decode($response, true);
            //print_r($data); exit();
            if (!empty($data['data'])) {
            if($data['code'] == '200'){
            $statuscode = $data['data'][0]['BookingStatus'];
            $WIPNumber = $data['data'][0]['WIPNumber'];
            $Registration = $data['data'][0]['Registration'];
            $BookedInOperator = $data['data'][0]['BookedInOperator'];
            $BookedOutOperator = $data['data'][0]['BookedOutOperator'];
            $WLInOut = $data['data'][0]['WLInOut'];
            $WLDateIn = $data['data'][0]['WLDateIn'];
            $InOperator = intval($BookedInOperator);
            $OutOperator = intval($BookedOutOperator);
            }
            }


            //print_r($data['code']);


            ?>