@extends('layouts.master')
@section('title', 'Call Log Search Report')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/report/call_log" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">

                            
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">From Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($fromdate))}}" name="fromdate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">To Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($todate))}}" name="todate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Phone Number</label>
                                    <input size="16" type="text" value="{{$phone}}" name="phone" class="form-control">
                                </div>

                            <div class="form-group pull-right col-md-6">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Outbound Report</strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table1">
                    <thead>
                    <tr>
                    <th>Lead ID</th>
                    <th>Phone</th>
                    <th>Campaign</th>
                    <th>Call Date</th>
                    <th>Status</th>
                    <th>User</th>
                    <th>List ID</th>
                    <th>Length</th>
                    <th>Dial</th>
                    </tr>
                    </thead>
                    <tbody>
                  @if(count($outbounds) > 0)
                  @foreach($outbounds as $out)
                    <tr class="gradeX">
                    <td>{{$out->lead_id}}</td>
                    <td>{{$out->phone_number}}</td>
                    <td>{{$out->campaign_id}}</td>
                    <td>{{$out->call_date}}</td>
                    <td>@if($out->status == 'B') Busy @elseif($out->status == 'NA') No Answer @else {{$out->status}} @endif</td>
                    <td>{{$out->user}}</td>
                    <td>{{$out->list_id}}</td>
                    <td>{{$out->length_in_sec}}</td>
                    <td>
                      <?php
                      if($out->alt_dial == "NONE"){
                        echo '<span style="color:#4caf50;">Auto Dial</span>';
                     }
                     else{ 
                        $check= $out->alt_dial;                     
                        echo '<span style="color:#c52317;"> '.$out->alt_dial.'</span>';
                     }
                     
                      ?>


                    </td>
                    </tr>
                  @endforeach
                  @endif
                    </table>
                    </div>
                    <ul class="pagination pagination-sm pull-right">
                        {!! $outbounds->render() !!}
                    </ul>

                    </div>
                </section>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Inbound Report</strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table1">
                    <thead>
                    <tr>
                    <th>Lead ID</th>
                    <th>Phone</th>
                    <th>Ingroup</th>
                    <th>Call Date</th>
                    <th>Status</th>
                    <th>User</th>
                    <th>List ID</th>
                    <th>Length</th>
                    <th>Queue Time</th>
                    </tr>
                    </thead>
                    <tbody>
                  @if(count($inbounds) > 0)
                  @foreach($inbounds as $inb)
                    <tr class="gradeX">
                    <td>{{$inb->lead_id}}</td>
                    <td>{{$inb->phone_number}}</td>
                    <td>{{$inb->campaign_id}}</td>
                    <td>{{$inb->call_date}}</td>
                    <td>@if($inb->status == 'B') Busy @elseif($inb->status == 'NA') No Answer @else {{$inb->status}} @endif</td>
                    <td>{{$inb->user}}</td>
                    <td>{{$inb->list_id}}</td>
                    <td>{{$inb->length_in_sec}}</td>
                    <td>{{$inb->queue_seconds}}</td>
                    </tr>
                  @endforeach
                  @endif
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Missed Call Report</strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table1">
                    <thead>
                    <tr>
                    <th>Lead ID</th>
                    <th>Phone</th>
                    <th>Ingroup</th>
                    <th>Call Date</th>
                    <th>Status</th>
                    <th>User</th>
                    <th>List ID</th>
                    <th>Queue Time</th>
                    </tr>
                    </thead>
                    <tbody>
                  @if(count($missed) > 0)
                  @foreach($missed as $mis)
                    <tr class="gradeX">
                    <td>{{$mis->lead_id}}</td>
                    <td>{{$mis->phone_number}}</td>
                    <td>{{$mis->campaign_id}}</td>
                    <td>{{$mis->call_date}}</td>
                    <td>@if($mis->status == 'B') Busy @elseif($mis->status == 'NA') No Answer @else {{$mis->status}} @endif</td>
                    <td>{{$mis->user}}</td>
                    <td>{{$mis->list_id}}</td>
                    <td>{{$mis->queue_seconds}}</td>
                    </tr>
                  @endforeach
                  @endif
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

@stop
