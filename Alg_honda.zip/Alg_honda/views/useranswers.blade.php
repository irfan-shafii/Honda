@extends('layouts.master')
@section('title', 'CSI Surway')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/useranswers" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">

                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">From Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($fromdate))}}" name="fromdate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">To Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($todate))}}" name="todate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>

                                <div class="form-group col-md-3">
                                    <label for="exampleInputEmail1">Campaign ID</label>
                                    <select class="form-control" name="campaignid" onChange="getlist(this);">
                                        <option value="">Select</option>
                                        @foreach($campaigns as $campaign)
                                        <option @if($campaign->campaign_id == $camp_id) selected="" @endif value="{{$campaign->campaign_id}}">{{$campaign->campaign_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInput">List ID</label>
                                    <select name="list_id" id="list_id" class="form-control">
                                        <option value="">SELECT</option><!-- 
                                        <option value="1004">SSS Script</option>
                                        <option value="1008">PDSS Script</option>
                                        <option value="1009">BTB Service Script</option>
                                        <option value="10091">BTB Lube Script</option> -->
                                        @foreach($list_ids as $list)
                                        <option @if($list->list_id == $list_id) selected="" @endif value="{{$list->list_id}}">{{$list->list_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Phone Number</label>
                                    <input size="16" type="text" value="{{$phone}}" name="phone" class="form-control">
                                </div>

                                <div class="form-group col-md-12"></div>
                                <input type="hidden" name="exportstatus" id="exportstatus" value="0">
                            <div class="form-group col-md-4">
                            <button type="submit" class="btn btn-primary" id="submitbtn" style="display: none;"><i class="fa fa-search"></i> Search</button>
                            <a href="#" class="btn btn-primary btn-block" onclick="searchbtn();"><i class="fa fa-search"></i> Search</a>
                            </div>
                            <div class="form-group col-md-4">
                            <a href="#" class="btn btn-warning btn-block" onclick="exportbtn();"><i class="fa fa-upload"></i> Export</a>
                            </div>

                    </div>
                	</section>
                  </form>
            </div>
        </div>

<!-- page start-->
            <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <!-- <header class="panel-heading">
                        General Table
                        <span class="tools pull-right">
                            <a href="javascript:;" class="fa fa-chevron-down"></a>
                            <a href="javascript:;" class="fa fa-cog"></a>
                            <a href="javascript:;" class="fa fa-times"></a>
                         </span>
                    </header> -->
                    <div class="panel-body">
                        <table class="table  table-hover general-table">
                            <thead>
                            <tr>
                                <th> Phone Number</th>
                                <th>Agent ID</th>
                                <th>Date & Time</th>
                                <th>Vehicle</th>
                                <th>ListID</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            @if(count($mobiles) > 0)
                              @foreach($mobiles as $mobile)
                                <?php 
                                    $vehicles = App\MKvehic::select('magic','regno','model','modelvar')->where('magic',$mobile->vehmagic)->get();
                                    $vehdetails = '';
                                    if(count($vehicles) > 0){
                                        $vehdetails = $vehicles[0]->model.' - '. $vehicles[0]->modelvar.' - '. $vehicles[0]->regno;
                                    }

						        $listnames = App\VicidialLists::select('list_name','list_id')->where('list_id',$mobile->list_id)->get();
						        $listname =  $mobile->list_id;
						        if(count($listnames) > 0){
						           $listname =  $listnames[0]->list_name;
						        }
                                ?>
                            <tr>
                                <td>{{$mobile->mobile}}</td>
                                <td>{{$mobile->agent_id}}</td>
                                <td>{{$mobile->date_time}}</td>
                                <td>{{$vehdetails}}</td>
                                <td>{{$listname}}</td>
                                <td><a href="{{url('/useranswers')}}/{{$mobile->id}}" class="label label-info label-mini">View Answers</a></td>
                            </tr>
                              @endforeach
                            @endif
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')
<script type="text/javascript">

function getlist(id) {
  var campaign = id.value;
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getlistids')}}",
    data: {campaign:campaign}, 
    dataType:'JSON', 
    success: function(response){
        //alert(response.divhtml);
        $("#list_id").html("");
        $("#list_id").html(response.divhtml);
      
    },error:function(){ 
            //alert("error!!!!");
        }
  });
  }
    
    function exportbtn() {
        //var list_id = $("#list_id").val();
            document.getElementById('exportstatus').value = '1';
            document.getElementById('submitbtn').click();    
    }    
    function searchbtn() {
    document.getElementById('exportstatus').value = '0';
    document.getElementById('submitbtn').click();
    }
</script>
@stop
