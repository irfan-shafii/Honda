<?php

$account = App\MKtargt::where('phone004','99954074')->first();
print_r($account);
echo "<br>++++++++++++++++ account +++++++++++<br>";
if($account){
$id_account = $account->magic;

$vehicles = App\MKvehic::where('magic','492225')->first();
print_r($vehicles);
echo "<br>++++++++++++++++ vehicles +++++++++++<br>";

if($vehicles){
$vehid = $vehicles->magic;
$newst = App\MKnewst::where('vehmagic',$vehid)->first();
print_r($newst);
echo "<br>++++++++++++++++ newst +++++++++++<br>";
}

$vehhisty = App\MKhisty::where('prime',$vehid)->where('tarmagic',$id_account)->orderBy('DATE','desc')->first();
print_r($vehhisty);
echo "<br>++++++++++++++++ vehhisty +++++++++++<br>";
}

?>