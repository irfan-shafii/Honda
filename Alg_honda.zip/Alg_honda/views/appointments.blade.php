@extends('layouts.master')
@section('title', 'Appointment List')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/appointments" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">

                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Select Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($fromdate))}}" name="fromdate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>

                            <div class="form-group pull-right col-md-6">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                            </div>
                        </section>

                        </form>
                    </div>
            </div>

        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Appointment Details</strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table1">
                    <thead>
                    <tr>
                        <th>Mobile Number</th>
                        <th>Name</th>
                        <th>Categories</th>
                        <th>Sub Category</th>
                        <th>Appointment Date</th>
                        <th>Appointment Time</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($appointments as $app)

                    <?php
                        $appdetail = DB::table('opportunity')->select('first_name','last_name','enquiry_category','enquiry_subcategory','enquiry_subcategory2','enquiry_subcategory3')->where('id_opp',$app->opp_id)->get();

                        $enq_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$appdetail[0]->enquiry_category)->first();
                        $enq_sub_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$appdetail[0]->enquiry_subcategory)->first();
                        $enq_category = '';
                        $enq_subcategory = '';
                        $enq_subcategory2 = '';
                        $enq_subcategory3 = '';

                         if(!empty($appdetail[0]->enquiry_subcategory2) || $appdetail[0]->enquiry_subcategory2 == '0'){

                         $enq_sub_cat2 = DB::table('enquiry_categories')->where('id_enquiry_category',$appdetail[0]->enquiry_subcategory2)->first();

                        if(count($enq_sub_cat2) > 0){
                          $enq_subcategory2 = "</br>".$enq_sub_cat2->category_name;
                        }

                        }

                        if(!empty($appdetail[0]->enquiry_subcategory3) || $appdetail[0]->enquiry_subcategory3 == '0'){

                         $enq_sub_cat3 = DB::table('enquiry_categories')->where('id_enquiry_category',$appdetail[0]->enquiry_subcategory3)->first();

                        if(count($enq_sub_cat3) > 0){
                          $enq_subcategory3 = "<br>".$enq_sub_cat3->category_name;
                        }
                         }
                        if(count($enq_cat) > 0){
                          $enq_category = $enq_cat->category_name;
                        }
                        if(count($enq_sub_cat) > 0){
                          $enq_subcategory = $enq_sub_cat->category_name;
                        }

                    ?>
                    <tr class="gradeX">
                        <td>{{$app->mobile_number}}</td>
                        <td>{{$appdetail[0]->first_name}} {{$appdetail[0]->last_name}}</td>
                        <td>{{$enq_category}}</td>
                        <td>{{$enq_subcategory}} {!! $enq_subcategory2 !!} {!! $enq_subcategory3 !!}</td>
                        <td>{{$app->appointment_date}}</td>
                        <td>{{$app->appointment_time}}</td>
                        <td>@if($app->appbooked =='Yes')
                        <a href="{{url('/inquiries')}}/view/{{$app->opp_id}}" class="btn btn-space btn-xs btn-danger" >View</a>
                        @endif</td>
                    </tr>
                    @endforeach
                    </table>
                    </div>
                    <ul class="pagination pagination-sm pull-right">
                        {!! $appointments->render() !!}
                    </ul>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

@stop
