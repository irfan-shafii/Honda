<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->            <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
            <li class="sub-menu">
                <a @if($routeName == 'dashboard' || $routeName == 'dashboard1' || $routeName == 'dashboard2') class="active" @endif href="javascript:;">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
                <ul class="sub">
                    <li @if($routeName == 'dashboard') class="active" @endif><a href="{{url('/dashboard')}}">Daily Dashboard</a></li>
                    <li @if($routeName == 'dashboard1') class="active" @endif><a href="{{url('/dashboard1')}}">Monthly Dashboard</a></li>
                    <li @if($routeName == 'dashboard2') class="active" @endif><a href="{{url('/dashboard2')}}">List Dashboard</a></li>
                </ul>
            </li>
            @if(Session::get('usertype') == 'admin' || Session::get('usertype') == 'agent')
            <li class="sub-menu">
                <a @if($routeName == 'target-list' || $routeName == 'target-batch' || $routeName == 'target-logs' || $routeName == 'target-campaign') class="active" @endif href="javascript:;">
                    <i class="fa fa-bar-chart-o"></i>
                    <span>Targets</span>
                </a>
                <ul class="sub">
                    <li @if($routeName == 'target-campaign') class="active" @endif><a href="{{url('/target')}}/campaign">Campaign Targets</a></li>
                    <li @if($routeName == 'target-list') class="active" @endif><a href="{{url('/target')}}/list">List Targets</a></li>
                    <li @if($routeName == 'target-batch') class="active" @endif><a href="{{url('/target')}}/batch">Batch Targets</a></li>
                    <li @if($routeName == 'target-logs') class="active" @endif><a href="{{url('/target')}}/logs">Targets Log</a></li>
                </ul>
            </li>
            @endif
            <!-- <li class="sub-menu">
                <a href="javascript:;" class="active">
                    <i class="fa fa-th"></i>
                    <span>Reports</span>
                </a>
                <ul class="sub">
                    <li class="active"><a href="{{url('/report')}}/agent_performance">Agent Performance Detail</a></li>
                    <li><a href="{{url('/report')}}/agent_time">Agent Time Detail</a></li>
                </ul>
            </li> 
            <li class="sub-menu">
                <a @if($routeName == 'vehicle-list' || $routeName == 'vehicle-new') class="active" @endif href="javascript:;">
                    <i class="fa fa-th"></i>
                    <span>Vehicle Details</span>
                </a>
                <ul class="sub">
                    <li @if($routeName == 'vehicle-list') class="active" @endif><a href="{{url('/vehicle')}}">Vehicle List</a></li>
                    <li @if($routeName == 'vehicle-new') class="active" @endif><a href="{{url('/vehicle')}}/create">Add New Vehicle</a></li>
                </ul>
            </li>   -->
            <li class="sub-menu">
                <a @if($routeName == 'users' || $routeName == 'users-campaign' || $routeName == 'users-group' || $routeName == 'group-campaign') class="active" @endif href="javascript:;">
                    <i class="fa fa-user"></i>
                    <span>Users</span>
                </a>
                <ul class="sub">
            @if(Session::get('usertype') == 'admin')
                    <li @if($routeName == 'users') class="active" @endif><a href="{{url('/users')}}">All Users</a></li>
                    <li @if($routeName == 'users-campaign') class="active" @endif><a href="{{url('/users')}}/campaigns">Campaigns</a></li>
            @endif
            @if(Session::get('usertype') == 'admin' || Session::get('usertype') == 'agent')
                    <li @if($routeName == 'users-group') class="active" @endif><a href="{{url('/users')}}/groups">Users & Usergroup</a></li>
                    <li @if($routeName == 'group-campaign') class="active" @endif><a href="{{url('/usergroups')}}/campaigns">Campaigns & Usergroup</a></li>
            @endif
                </ul>
            </li>
            <li>
                <a href="{{url('/customers')}}" @if($routeName == 'customers') class="active" @endif>
                    <i class="fa fa-users"></i>
                    <span>Customers</span>
                </a>
            </li>
            <li class="sub-menu">
                <a @if($routeName == 'upscale-list' || $routeName == 'upscale-new') class="active" @endif href="javascript:;">
                    <i class="fa fa-anchor"></i>
                    <span>Upscale Details</span>
                </a>
                <ul class="sub">
                    <li @if($routeName == 'upscale-list') class="active" @endif><a href="{{url('/upscale')}}">Upscale List</a></li>
                    <li @if($routeName == 'upscale-new') class="active" @endif><a href="{{url('/upscale')}}/create">Add New Upscale</a></li>
                </ul>
            </li>
            <li class="sub-menu">
                <a @if($routeName == 'call-log' || $routeName == 'outbound-report' || $routeName == 'inbound-report' || $routeName == 'missed-report') class="active" @endif href="javascript:;">
                    <i class="fa fa-list-alt"></i>
                    <span>Call Logs Report</span>
                </a>
                <ul class="sub">
                    <li @if($routeName == 'call-log') class="active" @endif><a href="{{url('/report')}}/call_log">All Call Logs</a></li>
                    <li @if($routeName == 'outbound-report') class="active" @endif><a href="{{url('/report')}}/outbound">Outbound Report</a></li>
                    <li @if($routeName == 'inbound-report') class="active" @endif><a href="{{url('/report')}}/inbound">Inbound Reports</a></li>
                    <li @if($routeName == 'missed-report') class="active" @endif><a href="{{url('/report')}}/missed">Missed Call Report</a></li>
                </ul>
            </li>
            <li class="sub-menu">
                <a @if($routeName == 'outbound-record' || $routeName == 'inbound-record') class="active" @endif href="javascript:;">
                    <i class="fa fa-dot-circle-o"></i>
                    <span>Call Recordings</span>
                </a>
                <ul class="sub">
                    <li @if($routeName == 'outbound-record') class="active" @endif><a href="{{url('/record')}}/outbound">Outbound Report</a></li>
                    <li @if($routeName == 'inbound-record') class="active" @endif><a href="{{url('/record')}}/inbound">Inbound Reports</a></li>
                </ul>
            </li>

            <li>
                <a @if($routeName == 'agent-time' || $routeName == 'agent-performance' || $routeName == 'agent-status' || $routeName == 'team-performance') class="active" @endif href="javascript:;">
                    <i class="fa fa-th"></i>
                    <span>Reports</span>
                </a>
                <ul class="sub">
                    <li @if($routeName == 'agent-time') class="active" @endif><a href="{{url('/report')}}/agent/time">Agent Time Details</a></li>
                </ul>
                <ul class="sub">
                    <li @if($routeName == 'agent-performance') class="active" @endif><a href="{{url('/report')}}/agent/performance">Agent Performance Details</a></li>
                </ul>
                <ul class="sub">
                    <li @if($routeName == 'agent-status') class="active" @endif><a href="{{url('/report')}}/agent/status">Agent Status Detail</a></li>
                </ul>
                <ul class="sub">
                    <li @if($routeName == 'team-performance') class="active" @endif><a href="{{url('/report')}}/team/performance">Team Performance Detail</a></li>
                </ul>
                <!-- <ul class="sub">
                    <li ><a href="{{url('/report')}}/agent/login">Agent Login/Logout Time</a></li>
                </ul> -->
            </li>


            <li class="sub-menu">
                <a @if($routeName == 'lead-list' || $routeName == 'lead-status' || $routeName == 'lead-batch') class="active" @endif href="javascript:;">
                    <i class="fa fa-barcode"></i>
                    <span>Dialer Leads</span>
                </a>
                <ul class="sub">
                    <li @if($routeName == 'lead-list') class="active" @endif><a href="{{url('/leads')}}/list">Leads Details</a></li>
                    <li @if($routeName == 'lead-status') class="active" @endif><a href="{{url('/list')}}/status">Lists Status</a></li>
                    <li @if($routeName == 'lead-batch') class="active" @endif><a href="{{url('/list')}}/batch">Batch Status</a></li>
                </ul>
            </li>


            <li class="sub-menu">
                <a @if($routeName == 'master-events' || $routeName == 'master-campaigns' || $routeName == 'master-brands' || $routeName == 'master-models'  || $routeName == 'master-showroom' || $routeName == 'master-salesman' || $routeName == 'master-center' || $routeName == 'master-advisor') class="active" @endif href="javascript:;">
                    <i class="fa fa-book"></i>
                    <span>Master Enquiry</span>
                </a>
                <ul class="sub">
                    <li @if($routeName == 'master-events') class="active" @endif><a href="{{url('/master')}}/events">Events</a></li>
                    <li @if($routeName == 'master-campaigns') class="active" @endif><a href="{{url('/master')}}/campaigns">Campaign</a></li>
                    <li @if($routeName == 'master-brands') class="active" @endif><a href="{{url('/master')}}/brands">Brands</a></li>
                    <li @if($routeName == 'master-models') class="active" @endif><a href="{{url('/master')}}/models">Model of interest</a></li>
                    <li @if($routeName == 'master-showroom') class="active" @endif><a href="{{url('/master')}}/showroom">Showroom</a></li>
                    <li @if($routeName == 'master-salesman') class="active" @endif><a href="{{url('/master')}}/salesman">Salesman</a></li>
                    <li @if($routeName == 'master-center') class="active" @endif><a href="{{url('/master')}}/center">Service Center</a></li>
                    <li @if($routeName == 'master-advisor') class="active" @endif><a href="{{url('/master')}}/advisor">Service Advisor</a></li>
                </ul>
            </li>
            <li>
                <a href="{{url('/inquiries')}}" @if($routeName == 'inquiries') class="active" @endif>
                    <i class="fa fa-bars"></i>
                    <span>Enquiries</span>
                </a>
            </li>
            <li>
                <a href="{{url('/appointments')}}" @if($routeName == 'appointments') class="active" @endif>
                    <i class="fa fa-calendar"></i>
                    <span>Appointments</span>
                </a>
            </li>
            <li>
                <a href="{{url('/useranswers')}}" @if($routeName == 'user-answer') class="active" @endif>
                    <i class="fa fa-comments"></i>
                    <span>CSI Surway</span>
                </a>
            </li>
            <li class="sub-menu">
                <a @if($routeName == 'auto-dial' || $routeName == 'auto-dial1') class="active" @endif href="javascript:;">
                    <i class="fa fa-upload"></i>
                    <span>Upload Auto Dial Numbers</span>
                </a>
                <ul class="sub">
                    <li @if($routeName == 'auto-dial') class="active" @endif><a href="{{url('/auto-dial')}}">By Excel</a></li>
                    <li @if($routeName == 'auto-dial1') class="active" @endif><a href="{{url('/auto-dial1')}}">By API</a></li>
                </ul>
            </li>
        </ul></div>        
<!-- sidebar menu end-->
    </div>
</aside>