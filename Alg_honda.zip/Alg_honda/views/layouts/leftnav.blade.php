<div class="am-left-sidebar">
      <div class="content">
        <div class="am-logo"></div>
        <ul class="sidebar-elements">
          <li class="child"><a href="{{url('/')}}"><i class="icon s7-monitor"></i><span>Dashboard</span></a></li>
          <li class="parent"><a href="#"><i class="icon s7-note2"></i><span>Reports</span></a>
            <ul class="sub-menu">
              <li><a href="{{url('/realtime')}}">Realtime Main Report</a>
              </li>
              <li><a href="{{url('/agents')}}">Agent Performance Detail </a>
              </li>
              <li><a href="{{url('/inbound')}}">Inbound Report</a>
              </li>
            </ul>
          </li>
        </ul>
        <!--Sidebar bottom content-->
      </div>
    </div>