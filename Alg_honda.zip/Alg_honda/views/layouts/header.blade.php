<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">

    <a href="{{url('/')}}" class="logo">
        <img src="http://subscriber.clgnote.in/assets/img/logo-full.png" alt="">
    </a>
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars"></div>
    </div>
</div>
<!--logo end-->

<div class="top-nav clearfix">
    <!--search & user info start-->
    <ul class="nav pull-right top-menu">
        <!-- <li>
            <input type="text" class="form-control search" placeholder=" Search">
        </li> -->
        <!-- user login dropdown start-->
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="/centrix/public/customer/#">
                <img alt="" src="{{asset('')}}/bucket/images/avatar1_small.jpg">
                @if(!empty(Session::get('username')))
                <span class="username">{{Session::get('username')}}</span>
                @else
                <span class="username">Administrator</span>
                @endif
                <b class="caret"></b>
            </a>
            <ul class="dropdown-menu extended logout">
                @if(!empty(Session::get('username')))
                <li><a href="{{url('/logout')}}"><i class="fa fa-key"></i> Log Out</a></li>
                @else
                <li><a href="{{url('/login')}}"><i class=" fa fa-suitcase"></i>Login</a></li>
                @endif
            </ul>
        </li>
        <!-- user login dropdown end -->
        <!-- <li>
            <div class="toggle-right-box">
                <div class="fa fa-bars"></div>
            </div>
        </li>
 -->    </ul>
    <!--search & user info end-->
</div>
</header>