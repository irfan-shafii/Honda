
<!--Core js-->
<script src="{{asset('')}}/bucket/js/jquery.js"></script>
<script src="{{asset('')}}/bucket/js/jquery-1.10.2.min.js"></script>
<script src="{{asset('')}}/bucket/bs3/js/bootstrap.min.js"></script>
<script src="{{asset('')}}/bucket/js/jquery-ui-1.9.2.custom.min.js"></script>
<script class="include" type="text/javascript" src="{{asset('')}}/bucket/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="{{asset('')}}/bucket/js/jquery.scrollTo.min.js"></script>
<script src="{{asset('')}}/bucket/js/easypiechart/jquery.easypiechart.js"></script>
<script src="{{asset('')}}/bucket/js/jQuery-slimScroll-1.3.0/jquery.slimscroll.js"></script>
<script src="{{asset('')}}/bucket/js/jquery.nicescroll.js"></script>
<script src="{{asset('')}}/bucket/js/jquery.nicescroll.js"></script>

<script src="{{asset('')}}/bucket/js/bootstrap-switch.js"></script>

<script type="text/javascript" src="{{asset('')}}/bucket/js/fuelux/js/spinner.min.js"></script>
<script type="text/javascript" src="{{asset('')}}/bucket/js/bootstrap-fileupload/bootstrap-fileupload.js"></script>
<script type="text/javascript" src="{{asset('')}}/bucket/js/bootstrap-wysihtml5/wysihtml5-0.3.0.js"></script>
<script type="text/javascript" src="{{asset('')}}/bucket/js/bootstrap-wysihtml5/bootstrap-wysihtml5.js"></script>

<script type="text/javascript" src="{{asset('')}}/bucket/js/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="{{asset('')}}/bucket/js/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
<script type="text/javascript" src="{{asset('')}}/bucket/js/bootstrap-daterangepicker/moment.min.js"></script>
<script type="text/javascript" src="{{asset('')}}/bucket/js/bootstrap-daterangepicker/daterangepicker.js"></script>
<script type="text/javascript" src="{{asset('')}}/bucket/js/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
<script type="text/javascript" src="{{asset('')}}/bucket/js/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>

<script type="text/javascript" src="{{asset('')}}/bucket/js/jquery-multi-select/js/jquery.multi-select.js"></script>
<script type="text/javascript" src="{{asset('')}}/bucket/js/jquery-multi-select/js/jquery.quicksearch.js"></script>

<script type="text/javascript" src="{{asset('')}}/bucket/js/bootstrap-inputmask/bootstrap-inputmask.min.js"></script>

<script src="{{asset('')}}/bucket/js/jquery-tags-input/jquery.tagsinput.js"></script>

<script src="{{asset('')}}/bucket/js/select2/select2.js"></script>
<script src="{{asset('')}}/bucket/js/select-init.js"></script>

<!--dynamic table-->
<script type="text/javascript" language="javascript" src="{{asset('')}}/bucket/js/advanced-datatable/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="{{asset('')}}/bucket/js/data-tables/DT_bootstrap.js"></script>

<!--dynamic table initialization -->
<script src="{{asset('')}}/bucket/js/dynamic_table_init.js"></script>


<!--common script init for all pages-->
<script src="{{asset('')}}/bucket/js/scripts.js"></script>

<script src="{{asset('')}}/bucket/js/toggle-init.js"></script>

<script src="{{asset('')}}/bucket/js/advanced-form.js"></script>
<!--Easy Pie Chart-->
<script src="{{asset('')}}/bucket/js/easypiechart/jquery.easypiechart.js"></script>
<!--Sparkline Chart-->
<script src="{{asset('')}}/bucket/js/sparkline/jquery.sparkline.js"></script>
<!--jQuery Flot Chart-->
<script src="{{asset('')}}/bucket/js/flot-chart/jquery.flot.js"></script>
<script src="{{asset('')}}/bucket/js/flot-chart/jquery.flot.tooltip.min.js"></script>
<script src="{{asset('')}}/bucket/js/flot-chart/jquery.flot.resize.js"></script>
<script src="{{asset('')}}/bucket/js/flot-chart/jquery.flot.pie.resize.js"></script>