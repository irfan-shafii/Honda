<?php 
    $routeName = Request::route()->getName();
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from bucketadmin.themebucket.net/dynamic_table.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Nov 2019 10:11:01 GMT -->
<head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="ThemeBucket">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="shortcut icon" href="{{asset('')}}/bucket/images/favicon.html">

    <title>@yield('title')</title>

@include('layouts.css')

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]>
    <script src="{{asset('')}}/bucket/{{url('/assets')}}/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="{{asset('')}}/bucket/{{url('/assets')}}/https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="{{asset('')}}/bucket/{{url('/assets')}}/https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>

<body>

<section id="container" >
<!--header start-->
@include('layouts.header')
<!--header end-->
@include('layouts.leftside')
<!--sidebar end-->
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
        <!-- page start-->
        @yield('pageBody')      
        <!-- page end-->
        </section>
    </section>
    <!--main content end-->
<!--right sidebar start-->
@include('layouts.rightnav')
<!--right sidebar end-->

</section>

<!-- Placed js at the end of the document so the pages load faster -->

@include('layouts.script')


        @yield('ScriptPage')  

</body>

<!-- Mirrored from bucketadmin.themebucket.net/dynamic_table.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Nov 2019 10:11:04 GMT -->
</html>
