
    <!--Core CSS -->
    <link href="{{asset('')}}/bucket/bs3/css/bootstrap.min.css" rel="stylesheet">
    <link href="{{asset('')}}/bucket/css/bootstrap-reset.css" rel="stylesheet">
    <link href="{{asset('')}}/bucket/font-awesome/css/font-awesome.css" rel="stylesheet" />

    <link rel="stylesheet" href="{{asset('')}}/bucket/css/bootstrap-switch.css" />
    <link rel="stylesheet" type="text/css" href="{{asset('')}}/bucket/js/bootstrap-fileupload/bootstrap-fileupload.css" />
    <link rel="stylesheet" type="text/css" href="{{asset('')}}/bucket/js/bootstrap-wysihtml5/bootstrap-wysihtml5.css" />

    <link rel="stylesheet" type="text/css" href="{{asset('')}}/bucket/js/bootstrap-datepicker/css/datepicker.css" />
    <link rel="stylesheet" type="text/css" href="{{asset('')}}/bucket/js/bootstrap-timepicker/css/timepicker.css" />
    <link rel="stylesheet" type="text/css" href="{{asset('')}}/bucket/js/bootstrap-colorpicker/css/colorpicker.css" />
    <link rel="stylesheet" type="text/css" href="{{asset('')}}/bucket/js/bootstrap-daterangepicker/daterangepicker-bs3.css" />
    <link rel="stylesheet" type="text/css" href="{{asset('')}}/bucket/js/bootstrap-datetimepicker/css/datetimepicker.css" />

    <link rel="stylesheet" type="text/css" href="{{asset('')}}/bucket/js/jquery-multi-select/css/multi-select.css" />
    <link rel="stylesheet" type="text/css" href="{{asset('')}}/bucket/js/jquery-tags-input/jquery.tagsinput.css" />

    <link rel="stylesheet" type="text/css" href="{{asset('')}}/bucket/js/select2/select2.css" />

    <!--dynamic table-->
    <link href="{{asset('')}}/bucket/js/advanced-datatable/css/demo_page.css" rel="stylesheet" />
    <link href="{{asset('')}}/bucket/js/advanced-datatable/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="{{asset('')}}/bucket/js/data-tables/DT_bootstrap.css" />

    <!-- Custom styles for this template -->
    <link href="{{asset('')}}/bucket/css/style.css" rel="stylesheet">
    <link href="{{asset('')}}/bucket/css/style-responsive.css" rel="stylesheet" />
    <style type="text/css">       
    .form-control {
        color: #353535 !important;
    }
    </style>