@extends('layouts.master')
@section('title', 'Upload Auto Dial')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-sm-12">
                
                    <form  action="{{url('/autoupload/upload')}}" method="post" enctype="multipart/form-data">
                        {{csrf_field()}}
                    <section class="panel">
                        <header class="panel-heading">
                            Upload Auto Dial
                        </header>
                        @if (session('alert'))
                            <div class="alert alert-success fade in">
                                <button data-dismiss="alert" class="close close-sm" type="button">
                                    <i class="fa fa-times"></i>
                                </button>
                                 {!! session('alert') !!}.
                            </div>
						            @endif
                        <div class="panel-body">
                                <div class="form-group col-md-3">
                                    <label for="exampleInputEmail1">Campaign ID</label>
                                    <select class="form-control" name="campaignid" onChange="getlist(this);">
                                        <option value="">Select</option>
                                        @foreach($campaigns as $campaign)
                                        <option value="{{$campaign->campaign_id}}">{{$campaign->campaign_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleInputEmail1">List ID</label>

                                    <select class="form-control" name="listid" id="listid" onChange="getlistid(this);">
                                        <option value="">Select</option>
                                        @foreach($lists as $list)
                                        <option value="{{$list->list_id}}">{{$list->list_name}}</option>     
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleInputEmail1">BatchNo.</label>
                                    <input type="text" name="batchno" class="form-control">
                                </div>
                                <!-- <input type="hidden" name="listid" id="listid" value="0"> -->
                                <input type="hidden" name="getdetails" id="getdetails" value="">
                                <input type="hidden" name="prevlistid" id="prevlistid" value="1">
                                <div class="form-group col-md-3">
                                    <label for="exampleInputEmail1">Leads Website</label>
                                    <select class="form-control" name="filetype">
                                        <option value="">Select</option>
                                        <option value="1">Post sales folow up</option>
                                        <option value="2">Post service folow up</option>
                                        <option value="3">Post service folow up Body shop </option>
                                        <option value="4">Service reminder follow up List </option>
                                        <option value="5">Test drive survey</option>
                                        <option value="6">Honda Leads</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleInputEmail1">Choose File</label>
                                    <input type="file" name="import_file" class="form-control">
                                </div>
                                <div class="form-group col-md-3"><br>
                                <button type="submit" class="btn btn-success btn-block" id="submitbtn">Upload</button>
                                </div>
                                <div class="form-group col-md-3"><br>
                                <a href="{{asset('/public')}}/test_number_format.csv" class="btn btn-danger btn-block" download="">Download CSV Format</a>
                                </div>
                            </form>

                        </div>
                    </section>
            </div>
  
       
@stop
@section('ScriptPage')

<script type="text/javascript">
    function getlistid(val) {
       var listid = val.value;
       //alert(listid);
       var apptab = 0;
       var urlcode = '';
       document.getElementById("getdetails").value = "";
       if(listid == '1001'){
            apptab = 1;
            urlcode = "SER";
       }
       if(listid == '1002'){
            apptab = 1;
            urlcode = "APP";
       }
       if(listid == '1008'){
            apptab = 1;
            urlcode = "AAP";
       }
       if(listid == '1004'){
            apptab = 1;
            urlcode = "GSP";
       }
       else{
            document.getElementById("getdetails").value = '';
            $('#submitbtn').attr("disabled", false);
       }
       if(apptab == '1'){
            //callAPI(urlcode);      
       }

    }

function callAPI(urlcode){
            $('#submitbtn').attr("disabled", true);
 //alert(urlcode);
 var apivar = "https://chevrolet-autoline-prod-api.alghanim-prod-ase.p.azurewebsites.net/contact/getdetails?script="+urlcode;
  $.ajax({
                 url:apivar,
                 type:'GET',
                           dataType: 'json',
                           contentType: "application/json; charset=utf-8",
                           mimeType: "multipart/form-data",
                 beforeSend : function() {
                  $('body').css('cursor', 'progress');
                      //alert(person2);
                 },
                 success : function(data) {
                       // alert(data);
                        var details = JSON.stringify(data);
                        //alert(details);
                        document.getElementById("getdetails").value = details;
                         $('#submitbtn').attr("disabled", false);

                       //$('#success-alert').modal('toggle');

                  $('body').css('cursor', 'default');
                 },
                 error:function(res){
                        //alert("Bad thing happend! " + res.statusText);
                    $('#submitbtn').attr("disabled", false);
                        
                  },
                 async : true
      });
}



function getlist(id) {
  var campaign = id.value;
  //alert(campaign);
       document.getElementById("getdetails").value = "";
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getlistids')}}",
    data: {campaign:campaign}, 
    dataType:'JSON', 
    success: function(response){
        //alert(response.divhtml);
        $("#listid").html("");
        $("#listid").html(response.divhtml);
      
    },error:function(){ 
            //alert("error!!!!");
        }
  });
  }
</script>


@stop
