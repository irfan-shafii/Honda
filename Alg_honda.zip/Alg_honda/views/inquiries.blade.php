@extends('layouts.master')
@section('title', 'Enquiries List')
@section('breadCrumbs')
        
@stop

@section('pageBody')


<?php 
        $listbounds = 'OUTBOUND,INBOUND';
        $enquiry_categories = DB::table('enquiry_categories')->whereIn('leadid',explode(",", $listbounds))->where('parent_id','0')->orderBy('id_enquiry_category','asc')->get();
        $showrooms = DB::table('showrooms')->where('delete_status','0')->orderBy('id','asc')->get();
        $centers = DB::table('service_centers')->where('delete_status','0')->orderBy('id','asc')->get();
        $sourcebusiness = DB::table('source_business')->get();
        $brands = DB::table('brands')->where('delete_status','0')->orderBy('id','asc')->get();
        $brand_models = DB::table('brand_models')->where('delete_status','0')->orderBy('id','asc')->get();
?>
<div class="row">
<form action="{{url('/')}}/inquiries" method="post"> 
                        {{csrf_field()}}
<div class="col-lg-12">
<section class="panel">
<div class="panel-body">

<div class="form-group col-md-3"> 
<label for="exampleInputPassword1">From Date</label>
<div data-date-viewmode="years" data-date-format="dd-mm-yyyy" data-date="{{date('d-m-Y',strtotime($fromdate))}}"  class="input-append date dpYears" style="width:200px">
<input type="text" value="{{date('d-m-Y',strtotime($fromdate))}}" class="form-control" name="fromdate">
<span class="input-group-btn add-on">
<button class="btn btn-primary" type="button"><i class="fa fa-calendar"></i></button>
</span>
</div>
</div>
<div class="form-group col-md-3"> 
<label for="exampleInputPassword1">To Date</label>
<div data-date-viewmode="years" data-date-format="dd-mm-yyyy" data-date="{{date('d-m-Y',strtotime($todate))}}"  class="input-append date dpYears" style="width:200px">
<input type="text" value="{{date('d-m-Y',strtotime($todate))}}" class="form-control" name="todate">
<span class="input-group-btn add-on">
<button class="btn btn-primary" type="button"><i class="fa fa-calendar"></i></button>
</span>
</div>
</div>
<div class="form-group col-md-3">
<label for="exampleInputEmail1">Call Type</label>
<select class="form-control" name="list_id" id="list_id" onChange="getcalltype(this);">
<option value="">Select</option>
@foreach($list_ids as $list)
<option value="{{$list->list_id}}" @if($list->list_id == $list_id) selected="" @endif>@if($list->list_id == '999') Incoming @else Outgoing - {{$list->list_name}}@endif</option>
@endforeach
</select>
</div>
<div class="form-group col-md-3">
<label for="exampleInputEmail1">Enquiry Category</label>
<select class="form-control" name="category" id="category" onChange="getcategory(this);">
<option value="">Select</option>
@foreach($enquiry_categories as $category)
<option value="{{$category->id_enquiry_category}}" @if($category->id_enquiry_category == $categoryy) selected="" @endif>{{$category->leadid}} {{$category->category_name}}</option>
@endforeach
</select>
</div>
<div class="col-md-12"></div>
<div class="form-group col-md-3" id="subdiv1" @if(empty($subcategory1)) style="display: none;"@endif>
<label for="exampleInputEmail1" id="subcatname1">@if(!empty($categoryyname)) {{$categoryyname}} @endif</label>
<select class="form-control" name="subcategory1" id="subcategory1" onChange="getcategory(this);">
<option value="">Select</option>
@if(!empty($subcategory1))
<?php 
$enquiry1 = DB::table('enquiry_categories')->where('parent_id',$categoryy)->where('category_type','2')->orderBy('category_name','asc')->get();
?>
@foreach($enquiry1 as $enqu1)
<option value="{{$enqu1->id_enquiry_category}}" @if($enqu1->id_enquiry_category == $subcategory1) selected="" @endif>{{$enqu1->category_name}}</option>
@endforeach
@endif
</select>
</div>
<div class="form-group col-md-3" id="subdiv2" @if(empty($subcategory2)) style="display: none;"@endif>
<label for="exampleInputEmail1" id="subcatname2">@if(!empty($categoryyname1)) {{$categoryyname1}} @endif</label>
<select class="form-control" name="subcategory2" id="subcategory2" onChange="getcategory(this);">
<option value="">Select</option>
@if(!empty($subcategory2))
<?php 
$enquiry2 = DB::table('enquiry_categories')->where('parent_id',$subcategory1)->where('category_type','3')->orderBy('category_name','asc')->get();
?>
@foreach($enquiry2 as $enqu2)
<option value="{{$enqu2->id_enquiry_category}}" @if($enqu2->id_enquiry_category == $subcategory2) selected="" @endif>{{$enqu2->category_name}}</option>
@endforeach
@endif
</select>
</div>
<div class="form-group col-md-3" id="subdiv3" style="display: none;">
<label for="exampleInputEmail1" id="subcatname3"></label>
<select class="form-control" name="subcategory3" id="subcategory3" onChange="getcategory(this);">
<option value="">Select</option>
</select>
</div>
<div id="apptabdiv"  @if(empty($apptab) && empty($source_name)) style="display: none;"@endif>
<div class="form-group col-md-3">
<label for="exampleInputEmail1">Source Of Business</label>
<select class="form-control" name="source_name" id="source_name">
<option value="">Select</option>
@foreach($sourcebusiness as $source)
<option value="{{$source->source_name}}" @if($source->source_name == $source_name) selected="" @endif>{{$source->source_name}}</option>
@endforeach
</select>
</div>
<div class="form-group col-md-3">
<label for="exampleInputEmail1">Appointment Booked ?</label>
<select class="form-control" name="apptab" id="apptab" onChange="getapptab(this);">
<option value="">Select</option>
<option value="Yes" @if($apptab == 'Yes') selected="" @endif>Yes</option>
<option value="No" @if($apptab == 'No') selected="" @endif>No</option>
<option value="No-Details/Intrested" @if($apptab == 'No-Details/Intrested') selected="" @endif>No-Details/Intrested</option>
</select>
</div>
</div>
<div id="subtype1_x" @if(!empty($brand) || !empty($interest)) @else style="display: none;"@endif>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Brand</label>
<select class="form-control" name="interest" id="interest" onchange="getmodel(this.value);">
<option value="">Select</option>
@foreach($brands as $brandd)
    <option @if($brandd->name == $brand) selected="" @endif value="{{$brandd->name}}">{{$brandd->name}}</option>
@endforeach
</select>
</div>

<div class="form-group col-md-3 modeldiv" id="modeldiv">
<label for="exampleInputEmail1">Model Of Interest</label>
<select class="form-control" name="brandmodel" id="brandmodel" onchange="getbrand(this.value);">
<option value="">Select</option>
@foreach($brand_models as $model)
    <option @if($model->name == $interest) selected="" @endif value="{{$model->name}}">{{$model->name}}</option>
@endforeach
</select>
</div>

</div>

<div id="agentDiv" style="display: none;"></div>
<input type="hidden" name="agent_name" id="agent_name"  value="">
<div id="subtype1" @if(!empty($showroom) || !empty($salesman) || !empty($appointmenttype)) @else style="display: none;"@endif>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Showroom Name</label>
<select class="form-control" name="showroomid" id="showroomid" onchange="getsalesman(this);">
    <option value="">Select</option>
@foreach($showrooms as $show)
    <option value="{{$show->id}}" @if($show->name == $showroom) selected="" @endif>{{$show->name}}</option>
@endforeach
</select>
<input type="hidden" name="showroom" id="showroom" value="{{$showroom}}">
</div>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Booked to Salesman</label>
<select class="form-control" name="salesman" id="salesman">
    <option value="">Select</option>
    @if(!empty($salesman))
    <option value="{{$salesman}}" selected="">{{$salesman}}</option>
    @endif
</select>
</div>


<div class="form-group col-md-3">
<label for="exampleInputPassword1">Type of Appoinment / Enquiry</label>
<select class="form-control" name="appointmenttype" id="appointmenttype" >
<option value="">Select</option>
<option value="ENO- Enquire Offers" @if($appointmenttype == 'ENO- Enquire Offers') selected="" @endif>ENO- Enquire Offers</option>
<option value="ENP- Enquire Price" @if($appointmenttype == 'ENP- Enquire Price') selected="" @endif>ENP- Enquire Price</option>
<option value="ENS- Enquire Specifications" @if($appointmenttype == 'ENS- Enquire Specifications') selected="" @endif>ENS- Enquire Specifications</option>
<option value="RQT- Request Quotation" @if($appointmenttype == 'RQT- Request Quotation') selected="" @endif>RQT- Request Quotation</option>
<option value="SRA- Showroom Appointment" @if($appointmenttype == 'SRA- Showroom Appointment') selected="" @endif>SRA- Showroom Appointment</option>
<option value="TDR- TestDrive Appointment" @if($appointmenttype == 'TDR- TestDrive Appointment') selected="" @endif>TDR- TestDrive Appointment</option>
<option value="VAV- Vehicle Availability" @if($appointmenttype == 'VAV- Vehicle Availability') selected="" @endif>VAV- Vehicle Availability</option>
</select>
</div>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Appointment Code</label>
<select class="form-control" name="appointmentcode1" id="appointmentcode1" >
<option value="">Select</option>
<option value="APP- Mobile App" @if($appointmentcode == 'APP- Mobile App') selected="" @endif>APP- Mobile App</option>
<option value="IPC- Incoming Phone Call" @if($appointmentcode == 'IPC- Incoming Phone Call') selected="" @endif>IPC- Incoming Phone Call</option>
<option value="SHZ- Showroomz App" @if($appointmentcode == 'SHZ- Showroomz App') selected="" @endif>SHZ- Showroomz App</option>
<option value="SOM- Social Media" @if($appointmentcode == 'SOM- Social Media') selected="" @endif>SOM- Social Media</option>
<option value="WAP- Whatsapp" @if($appointmentcode == 'WAP- Whatsapp') selected="" @endif>WAP- Whatsapp</option>
<option value="WLD- Dealer Website" @if($appointmentcode == 'WLD- Dealer Website') selected="" @endif>WLD- Dealer Website</option>
<option value="WLM- Arabia Website" @if($appointmentcode == 'WLM- Arabia Website') selected="" @endif>WLM- Arabia Website</option>
<option value="LIV- Livechat" @if($appointmentcode == 'LIV- Livechat') selected="" @endif>LIV- Livechat</option>
<option value="WAP- Whatsapp" @if($appointmentcode == 'WAP- Whatsapp') selected="" @endif>WAP- Whatsapp</option>
<option value="GMR- GM Recall" @if($appointmentcode == 'GMR- GM Recall') selected="" @endif>GMR- GM Recall</option>
<option value="SEY- Seyayeer" @if($appointmentcode == 'SEY- Seyayeer') selected="" @endif>SEY- Seyayeer</option>
<option value="O- Outgoing" @if($appointmentcode == 'O- Outgoing') selected="" @endif>O- Outgoing</option>
<option value="VLE- Loyalty/ Evergreen Campaign" @if($appointmentcode == 'VLE- Loyalty/ Evergreen Campaign') selected="" @endif>VLE- Loyalty/ Evergreen Campaign</option>
<option value="VME- Marketing Leads/Events " @if($appointmentcode == 'VME- Marketing Leads/Events') selected="" @endif>VME- Marketing Leads/Events</option>
<option value="VTL- Targeted Leads" @if($appointmentcode == 'VTL- Targeted Leads') selected="" @endif>VTL- Targeted Leads</option>
<option value="VRF- Referral" @if($appointmentcode == 'VRF- Referral') selected="" @endif>VRF- Referral</option>
<option value="VUP- Unsold Prospects" @if($appointmentcode == 'VUP- Unsold Prospects') selected="" @endif>VUP- Unsold Prospects</option>
</select>
</div>

</div>

<div id="subtype2" @if(!empty($servicecenter) || !empty($advisorname) || !empty($appointmentcode)) @else style="display: none;"@endif>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Service Center</label>
<select class="form-control" name="center_id" id="center_id" onchange="getadvisor(this);">
    <option value="">Select</option>
@foreach($centers as $center)
    <option value="{{$center->id}}" @if($center->name == $servicecenter) selected="" @endif>{{$center->name}}</option>
@endforeach
</select>
<input type="hidden" name="servicecenter" id="servicecenter" value="">
</div>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Service Advisor Name</label>
<select class="form-control" name="advisorname" id="advisorname">
    <option value="">Select</option>
    @if(!empty($advisorname))
    <option value="{{$advisorname}}" selected="">{{$advisorname}}</option>
    @endif
</select>
</div>
<div class="form-group col-md-3">
<label for="exampleInputPassword1">Appointment Code</label>
<select class="form-control" name="appointmentcode" id="appointmentcode" >
<option value="">Select</option>
<option value="APC- Appointment Confirmation" @if($appointmentcode == 'APC- Appointment Confirmation') selected="" @endif>APC- Appointment Confirmation</option>
<option value="APP- Mobile App" @if($appointmentcode == 'APP- Mobile App') selected="" @endif>APP- Mobile App</option>
<option value="IPC- Incoming Phone Call" @if($appointmentcode == 'IPC- Incoming Phone Call') selected="" @endif>IPC- Incoming Phone Call</option>
<option value="SER- Service Reminder" @if($appointmentcode == 'SER- Service Reminder') selected="" @endif>SER- Service Reminder</option>
<option value="SHZ- Showroomz App" @if($appointmentcode == 'SHZ- Showroomz App') selected="" @endif>SHZ- Showroomz App</option>
<option value="SOM- Social Media" @if($appointmentcode == 'SOM- Social Media') selected="" @endif>SOM- Social Media</option>
<option value="WLD- Dealer Website" @if($appointmentcode == 'WLD- Dealer Website') selected="" @endif>WLD- Dealer Website</option>
<option value="LIV- Livechat" @if($appointmentcode == 'LIV- Livechat') selected="" @endif>LIV- Livechat</option>
<option value="WAP- Whatsapp" @if($appointmentcode == 'WAP- Whatsapp') selected="" @endif>WAP- Whatsapp</option>
<option value="GMR- GM Recall" @if($appointmentcode == 'GMR- GM Recall') selected="" @endif>GMR- GM Recall</option>
<option value="SEY- Seyayeer" @if($appointmentcode == 'SEY- Seyayeer') selected="" @endif>SEY- Seyayeer</option>
<option value="O- Outgoing" @if($appointmentcode == 'O- Outgoing') selected="" @endif>O- Outgoing</option>
<option value="VLE- Loyalty/ Evergreen Campaign" @if($appointmentcode == 'VLE- Loyalty/ Evergreen Campaign') selected="" @endif>VLE- Loyalty/ Evergreen Campaign</option>
<option value="VME- Marketing Leads/Events" @if($appointmentcode == 'VME- Marketing Leads/Events') selected="" @endif>VME- Marketing Leads/Events</option>
<option value="VTL- Targeted Leads" @if($appointmentcode == 'VTL- Targeted Leads') selected="" @endif>VTL- Targeted Leads</option>
<option value="VRF- Referral" @if($appointmentcode == 'VRF- Referral') selected="" @endif>VRF- Referral</option>
<option value="VUP- Unsold Prospects" @if($appointmentcode == 'VVUP- Unsold ProspectsUP') selected="" @endif>VUP- Unsold Prospects</option>
</select>
</div>
</div>

<!-- <div class="form-group col-md-3"> 
<label for="exampleInputPassword1">Appointment Date & Time</label>
<div data-date-viewmode="years" data-date-format="dd-mm-yyyy"  class="input-append date dpYears" style="width:200px">
<input type="text" value="" class="form-control" name="appointment">
<span class="input-group-btn add-on">
<button class="btn btn-primary" type="button"><i class="fa fa-calendar"></i></button>
</span>
</div>
</div> -->

<input type="hidden" name="exportstatus" id="exportstatus" value="0">

<div class="form-group col-md-12"></div>
<div class="form-group col-md-3 pull-right">
<a href="#" class="btn btn-warning" onclick="exportexcel();"><i class="fa fa-arrows-alt"></i> Export</a>
<button type="submit" class="btn btn-primary" id="submitbtn"><i class="fa fa-search"></i> Search</button>
</div>

</div>
</section>
</div>
</form>
</div>
        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Enquiries Details </strong><span class="pull-right">Total <strong>{{count($inquiries)}}</strong> Records</span>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table2" style="background: #ffffff;width:100%">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Lead Id</th>
                        <th>Name</th>
                        <th>Mobile Number</th>
                        <th>Call Type</th>
                        <th>Id Agent</th>
                        <th>@if(!empty($categoryyname)) {{$categoryyname}} @else Categories @endif</th>
                        <th>@if(!empty($categoryyname1)) {{$categoryyname1}} @else Sub Category @endif</th>
                        <th>@if(!empty($categoryyname2)) {{$categoryyname2}} @else Sub Category2 @endif</th>
                        <th>@if(!empty($categoryyname3)) {{$categoryyname3}} @else Sub Category3 @endif</th>
                        <th>Description</th>
                        <th>Campaign</th>
                        <th>Date Added</th>
                        <th>Appointment Booked</th>
                        <th>Source of Business</th>
                        <th>Brand</th>
                        <th>Model</th>
                        <th>Showroom</th>
                        <th>Salesman</th>
                        <th>Service Center</th>
                        <th>Advisor Name</th>
                        <th>Appointment Date</th>
                        <th>Appointment Time</th>
                        <th>Appointment Type</th>
                        <th>Appointment Code</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($inquiries as $app)
                    <tr class="gradeX">
                                    <?php 
                                    $enq_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$app->enquiry_category)->first();
                                    $enq_sub_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$app->enquiry_subcategory)->first();
                                    $enq_category = '';
                                    $enq_subcategory = '';
                                    $enq_subcategory2 = '';
                                    $enq_subcategory3 = '';

                                     if(!empty($app->enquiry_subcategory2) || $app->enquiry_subcategory2 == '0'){

                                     $enq_sub_cat2 = DB::table('enquiry_categories')->where('id_enquiry_category',$app->enquiry_subcategory2)->first();

                                    if(count($enq_sub_cat2) > 0){
                                      $enq_subcategory2 = "</br>".$enq_sub_cat2->category_name;
                                    }

                                    }

                                    if(!empty($app->enquiry_subcategory3) || $app->enquiry_subcategory3 == '0'){

                                     $enq_sub_cat3 = DB::table('enquiry_categories')->where('id_enquiry_category',$app->enquiry_subcategory3)->first();

                                    if(count($enq_sub_cat3) > 0){
                                      $enq_subcategory3 = "<br>".$enq_sub_cat3->category_name;
                                    }
                                     }
                                    if(count($enq_cat) > 0){
                                      $enq_category = $enq_cat->category_name;
                                    }
                                    if(count($enq_sub_cat) > 0){
                                      $enq_subcategory = $enq_sub_cat->category_name;
                                    }

                               
                    $listnames = App\VicidialLists::select('list_name')->where('list_id',$app->id_list)->get();
                    $listname =  '';
                    $listid =  $app->id_list;
                    if(count($listnames) > 0){
                        
                        if($listid == '999'){
                            $listname =  ' Incoming';
                        }
                        else{
                            $listname =  ' Outgoing - '.$listnames[0]->list_name;
                        }
                    } 
                    ?>
                        <td>{{$app->id_opp}}</td>
                        <td>{{$app->id_process_lead}}</td>
                        <td>{{$app->first_name}} {{$app->last_name}}</td>
                        <td>{{$app->mobile_number}}</td>
                        <td>{{$listname}}</td>
                        <td>{{$app->id_agent}}</td>
                        <td>{{$enq_category}}</td>
                        <td>{{$enq_subcategory}}</td>
                        <td>{!! $enq_subcategory2 !!}</td>
                        <td>{!! $enq_subcategory3 !!}</td>
                        <td>{{$app->description}}</td>
                        <td>{{$app->campaign_id}}</td>
                        <td>{{$app->date_add}}</td>
                        @if($app->appointment_booked =='Yes' || $app->appointment_booked =='No-Details/Intrested')
                        <?php 
                          $appdetail = DB::table('appointments')->where('opp_id',$app->id_opp)->first();
                        ?>
                        <td>{{$app->appointment_booked}}</td>
                        @if($appdetail)
                        <td>{{$appdetail->source_name}}</td>
                        <td>{{$appdetail->brand}}</td>
                        <td>{{$appdetail->interest}}</td>
                        <td>{{$appdetail->showroom}}</td>
                        <td>{{$appdetail->salesman}}</td>
                        <td>{{$appdetail->servicecenter}}</td>
                        <td>{{$appdetail->advisorname}}</td>
                        <td>{{$appdetail->appointment_date}}</td>
                        <td>{{$appdetail->appointment_time}}</td>
                        <td>{{$appdetail->appointmenttype}}</td>
                        <td>{{$appdetail->appointmentcode}}</td>
                        @endif
                        @else
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        @endif
                        @if($app->appointment_booked =='Yes')<td>
                        <a href="{{url('/inquiries')}}/view/{{$app->id_opp}}" class="btn btn-space btn-xs btn-danger" >View</a></td>
                        @else
                        <td></td>
                        @endif
                        
                    </tr>
                    @endforeach

                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.7/js/dataTables.fixedHeader.min.js"></script>
<script>
    $(document).ready(function() {
 
    var table = $('#dynamic-table2').DataTable( {
        "iDisplayLength" : 500,
        "scrollY": 400,
        "scrollX": true,
        orderCellsTop: false,
        fixedHeader: false
    } );


} );

</script>
<script type="text/javascript">

  function getcategory(id) {
    idvalue = id.value;
    if(idvalue != ''){
    //alert(idvalue);
    if(idvalue== '118' || idvalue== '119' || idvalue== '120'  || idvalue== '138' || idvalue== '139' ){
      $( "#csibtn" ).click();
      
        $('html, body').animate({
            scrollTop: $('#main-content').offset().top
        }, 'slow');
    }
  	$.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getcategory')}}",
    data: {idvalue: idvalue}, 
    dataType:'JSON', 
    success: function(data){
            //alert(data.categorytype);

        var categorytype = data.categorytype;


          $("#salesman").val("");
          $("#appointment").val("");
          $("#interest").val("");
          $("#appointmenttype").val("");
          $("#agentname").val("");
          $("#showroom").val("");
          $("#advisorname").val("");
          $("#appointmenttype").val("");
          $("#appointmenttype").val("");
          $("#subtype1").hide();
          $("#subtype1_x").hide();
          $("#subtype2").hide();
          $("#agentDiv").hide("");
          $("#appointmentDiv").hide("");
        //alert(categorytype);
        if(categorytype == '1'){
          $("#subcategory1").html("");
          $("#subcategory2").html("");
          $("#subcategory3").html("");
          $("#subcategory2").val("");
          $("#apptabdiv").hide();
          $("#apptab").val("");
          $("#subcategory3").val("");  
        if (data.divhtml != "") {

          $("#subdiv1").show();        
          $("#subdiv2").hide();
          $("#subdiv3").hide();
          $("#subcategory1").html(data.divhtml);
          $("#subcatname1").html(data.categoryname);

        }
        else{
          $("#subcategory1").html("");
          $("#subcategory2").html("");
          $("#subcategory3").html("");
          $("#subdiv1").hide();          
          $("#subdiv2").hide();
          $("#subdiv3").hide();
        }
          $("#subcatname2").html("");
          $("#subcatname3").html("");
        }

        if(categorytype == '2'){
          $("#subdiv3").hide();
          $("#subcategory2").html("");
          $("#subcategory3").html("");
          $("#subcategory3").val("");
        if (data.divhtml != "") {

          $("#subdiv2").show();  
          $("#subdiv3").hide();
          $("#subcategory2").html(data.divhtml);
          $("#subcatname2").html(data.categoryname);

        }
        else{  
          $("#subcategory2").html("");
          $("#subcategory3").html("");        
          $("#subdiv2").hide();
          $("#subdiv3").hide();
        }
          $("#subcatname3").html("");
        }

        if(categorytype == '3'){
          $("#subcategory3").html("");
        if (data.divhtml != "") {

          $("#subdiv3").show();
          $("#subcategory3").html(data.divhtml);
          $("#subcatname3").html(data.categoryname);

        }
        else{
          $("#subcategory3").html("");
          $("#subdiv3").hide();
        }
        }

        if(data.apptab == '1'){
          $("#apptabdiv").show();
        }
        else if(data.apptab == '0'){
          $("#apptab").val("");
          $("#source_name").val("");
          $("#apptabdiv").hide();
        }


        },error:function(){ 
            alert("error!!!!");
        }
  });
  }
  }


function getcalltype(idval){
    var ttype = idval.value;
    var divhtml = '<option value="">Select</option>';
    <?php 
    $enquiry_categories1 = DB::table('enquiry_categories')->where('leadid','INBOUND')->where('parent_id','0')->orderBy('id_enquiry_category','asc')->get();
    $enquiry_categories2 = DB::table('enquiry_categories')->where('leadid','OUTBOUND')->where('parent_id','0')->orderBy('id_enquiry_category','asc')->get(); ?>
    if(ttype == "999"){
        <?php foreach($enquiry_categories1 as $category){ ?>
            divhtml += '<option value="<?php echo $category->id_enquiry_category; ?>" ><?php echo $category->category_name; ?></option>';
        <?php } ?>       
    }
    else{
        <?php foreach($enquiry_categories2 as $category){ ?>
            divhtml += '<option value="<?php echo $category->id_enquiry_category; ?>" ><?php echo $category->category_name; ?></option>';
        <?php } ?>       
    }
          $("#subdiv1").hide();          
          $("#subdiv2").hide();
          $("#subdiv3").hide();
          $("#category").html("");
          $("#category").html(divhtml);
}

function getmodel(brand) {
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getmodel')}}",
    data: {brand:brand}, 
    dataType:'JSON', 
    success: function(response){
      
        //alert(response);
        $("#brandmodel").html(response.divhtml);
        
      
    },error:function(){ 
            //alert("error!!!!");
        }
  });
}

function getbrand(brand) {
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getbrand')}}",
    data: {brand:brand}, 
    dataType:'JSON', 
    success: function(response){
      
        //alert(response);
        $("#interest").val(response.divhtml);
        
      
    },error:function(){ 
            //alert("error!!!!");
        }
  });
}
function getapptab(idval){
  //alert("apptab");
    //alert(idval.value);
    var appvalue = idval.value;
    var categorytype = $("#category").val();


        if(appvalue == 'Yes' || appvalue == 'No-Details/Intrested'){
          $("#appointmentDiv").show();
          $("#agentDiv").show();
        if(categorytype == '1' || categorytype == '109'){
          $("#subtype1").show();
          $("#subtype1_x").show();
          
          $("#subtype2").hide();
          $("#center_id").val("");
          $("#servicecenter").val("");
          $("#advisorname").val("");
          $("#appointmentcode").val("");
        }
        else{
          $("#subtype1").hide();
          $("#subtype1_x").hide();
          $("#showroomid").val("");
          $("#showroom").val("");
          $("#salesman").val("");
          $("#interest").val("");
          $("#appointmenttype").val("");
          $("#appointmentcode1").val("");
          $("#subtype2").show();         
        }
        }
        else{
          $("#appointmentDiv").hide("");
          $("#appointment").val("");

          $("#agentDiv").hide("");
          $("#subtype1").hide();
          $("#subtype1_x").hide();
          $("#showroomid").val("");
          $("#showroom").val("");
          $("#salesman").val("");
          $("#interest").val("");
          $("#appointmenttype").val("");
          $("#appointmentcode1").val("");

          $("#subtype2").hide();  
          $("#center_id").val("");
          $("#servicecenter").val("");
          $("#advisorname").val("");
          $("#appointmentcode").val("");

        }
}

  function getsalesman(id) {
  var idval = id.value;
  //alert(idval);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getsalesman')}}",
    data: {idval:idval}, 
    dataType:'JSON', 
    success: function(response){
      
        //alert(response);
        if(response.divhtml != ''){
        $("#showroom").val(0);
        $("#showroom").val(response.showroom);
        $("#salesman").html("");
        $("#salesman").html(response.divhtml);
        }
      
    },error:function(){ 
            alert("error!!!!");
        }
  });
  }

  function getadvisor(id) {
  var idval = id.value;
  //alert(idval);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getadvisor')}}",
    data: {idval:idval}, 
    dataType:'JSON', 
    success: function(response){
      
        //alert(response);
        if(response.divhtml != ''){
        $("#servicecenter").val(0);
        $("#servicecenter").val(response.showroom);
        $("#advisorname").html("");
        $("#advisorname").html(response.divhtml);
        }
      
    },error:function(){ 
            alert("error!!!!");
        }
  });
  }

  function exportexcel() {
    document.getElementById("exportstatus").value = '1';
    //alert("value");
    document.getElementById("submitbtn").click();
    document.getElementById("exportstatus").value = '0';
  }
</script>

@stop
