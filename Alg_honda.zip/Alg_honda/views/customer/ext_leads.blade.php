
<header class="panel-heading wht-bg">
   <h4 class="gen-case"> Lead Information
    <a href="#"  class="btn btn-info pull-right">
        {{$ingroup}} - {{$listname}}
    </a>
   </h4>
</header>
@if($listid == '1005')
<?php $leadinfo = App\VicidialList::where('list_id','1005')->where('phone_number',$mobile_number)->orderBy('lead_id','desc')->first(); ?>
<div class="row">
<div class="col-lg-12">
<section class="panel">
<div class="prf-box">
        <h3 class="prf-border-head">Leads Info</h3>
@if($leadinfo)
<div class="form-group col-md-4">
<label for="exampleInputEmail1">LEAD ID</label>
<input type="text" class="form-control" name="alt_lead_id" id="alt_lead_id" value="{{$leadinfo->alt_lead_id}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Source of Lead</label>
<input type="text" class="form-control" name="Sourceoflead" id="Sourceoflead" value="{{$leadinfo->Sourceoflead}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Enquiry Type</label>
<input type="text" class="form-control" name="Enquiry_type" id="Enquiry_type" value="{{$leadinfo->Enquiry_type}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Source of business</label>
<input type="text" class="form-control" name="Source_of_business" id="Source_of_business" value="{{$leadinfo->Source_of_business}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Siebel SOB</label>
<input type="text" class="form-control" name="Siebel" id="Siebel" value="{{$leadinfo->Siebel}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">CC AGENT</label>
<input type="text" class="form-control" name="cc_agent" id="cc_agent" value="{{$leadinfo->cc_agent}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Date</label>
<input type="text" class="form-control" name="Date" id="Date" value="{{$leadinfo->Date}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Month</label>
<input type="text" class="form-control" name="Month" id="Month" value="{{$leadinfo->Month}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Year</label>
<input type="text" class="form-control" name="Year" id="Year" value="{{$leadinfo->Year}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Allocation Date</label>
<input type="text" class="form-control" name="Allocation_date" id="Allocation_date" value="{{$leadinfo->Allocation_date}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Allocation Time</label>
<input type="text" class="form-control" name="Allocation_time" id="Allocation_time" value="{{$leadinfo->Allocation_time}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Model of Interest</label>
<input type="text" class="form-control" name="modelofinterest" id="modelofinterest" value="{{$leadinfo->modelofinterest}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Appointment</label>
<input type="text" class="form-control" name="appointmentss" id="appointmentss" value="{{$leadinfo->appointment}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Call Centre Feedback</label>
<input type="text" class="form-control" name="callcentre_feedback" id="callcentre_feedback" value="{{$leadinfo->callcentre_feedback}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Showroom</label>
<input type="text" class="form-control" name="showroomss" id="showroomss" value="{{$leadinfo->showroom}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Sales Consultant</label>
<input type="text" class="form-control" name="sale_consultant" id="sale_consultant" value="{{$leadinfo->sale_consultant}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Test Drive Appointment</label>
<input type="text" class="form-control" name="test_appointment" id="test_appointment" value="{{$leadinfo->test_appointment}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Month - Sent</label>
<input type="text" class="form-control" name="month_sent" id="month_sent" value="{{$leadinfo->month_sent}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Salesman Feedback</label>
<input type="text" class="form-control" name="salesman_feedback" id="salesman_feedback" value="{{$leadinfo->salesman_feedback}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Visited</label>
<input type="text" class="form-control" name="Visited" id="Visited" value="{{$leadinfo->Visited}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Salesman Showup - Enquiry</label>
<input type="text" class="form-control" name="showup_enquiry" id="showup_enquiry" value="{{$leadinfo->showup_enquiry}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Sold Date</label>
<input type="text" class="form-control" name="solddate" id="solddate" value="{{$leadinfo->sold}}">
</div>
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Car model Conversion </label>
<input type="text" class="form-control" name="carmodel_conversion" id="carmodel_conversion" value="{{$leadinfo->carmodel_conversion}}">
</div>
@endif
</div>
</section>
</div>
</div>
@endif
