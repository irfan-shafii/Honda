
<header class="panel-heading wht-bg">
   <h4 class="gen-case"> Call Log Report
	<a href="#"  class="btn btn-info pull-right">
        {{$campaignid}} - {{$ingroup}} - {{$listname}}
    </a>
   </h4>
</header>



<div class="row">
<div class="col-lg-12">

<section class="panel">
<header class="panel-heading">
Call Log Reports
</header>
<div class="panel-body">
<table class="table table-striped">
<thead>
<tr>
<th>LeadID</th>
<th>CampaignID</th>
<th>Call Date</th>
<th>Status</th>
<th>ListID</th>
</tr>
</thead>
<tbody>
@if(count($dial_logs) > 0)
@foreach($dial_logs as $log)
<tr>
<?php
$listnames = App\VicidialLists::select('list_name')->where('list_id',$log->list_id)->get();
$listname =  'ListName';
if(count($listnames) > 0){
$listname =  $listnames[0]->list_name;
} 
?>
<td>{{$log->closecallid}}</td>
<td>{{$log->campaign_id}}</td>
<td>{{$log->call_date}}</td>
<td>{{$log->status}}</td>
<td>{{$listname}}</td>
</tr>
@endforeach
@endif

</tbody>
</table>
</div>
</section>
</div>
</div>