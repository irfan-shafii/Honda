
<header class="panel-heading wht-bg">
   <h4 class="gen-case"> Other Information
    <a href="#"  class="btn btn-info pull-right">
        {{$ingroup}} - {{$listname}}
    </a>
   </h4>
</header>
<div class="row">
<div class="col-lg-12">
<section class="panel">
<div class="prf-box">
        <h3 class="prf-border-head">Leads Info</h3>
@if($filetype == '1')
<?php $fileinfo = DB::table('honda_post_sales_followup')->where('leadid',$leadid)->first(); ?>
@if($fileinfo)

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Location</label>
<input type="text" class="form-control" value="{{$fileinfo->location}}">
</div>


<div class="form-group col-md-4">
<label for="exampleInputEmail1">XCO</label>
<input type="text" class="form-control" value="{{$fileinfo->xco}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">VSP No</label>
<input type="text" class="form-control" value="{{$fileinfo->vsb_no}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Invoice No</label>
<input type="text" class="form-control" value="{{$fileinfo->invoice_no}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Chasis No</label>
<input type="text" class="form-control" value="{{$fileinfo->chasis_no}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Name</label>
<input type="text" class="form-control" value="{{$fileinfo->name}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Fran</label>
<input type="text" class="form-control" value="{{$fileinfo->fran}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Model</label>
<input type="text" class="form-control" value="{{$fileinfo->model}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Variant</label>
<input type="text" class="form-control" value="{{$fileinfo->variant}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Year</label>
<input type="text" class="form-control" value="{{$fileinfo->year}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Tot Inscost</label>
<input type="text" class="form-control" value="{{$fileinfo->tot_inscost}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Comp inscost</label>
<input type="text" class="form-control" value="{{$fileinfo->compinscost}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Free Service</label>
<input type="text" class="form-control" value="{{$fileinfo->free_service}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Stype</label>
<input type="text" class="form-control" value="{{$fileinfo->stype}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Quote Date</label>
<input type="text" class="form-control" value="{{$fileinfo->quote_date}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Estdel</label>
<input type="text" class="form-control" value="{{$fileinfo->estdel}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Deldate</label>
<input type="text" class="form-control" value="{{$fileinfo->deldate}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Invoice Date</label>
<input type="text" class="form-control" value="{{$fileinfo->invoice_date}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Sales Exec</label>
<input type="text" class="form-control" value="{{$fileinfo->sales_exec}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">cust A/C</label>
<input type="text" class="form-control" value="{{$fileinfo->cust_a_c}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Customer A/C Name</label>
<input type="text" class="form-control" value="{{$fileinfo->customer_a_c_name}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Arrival Date</label>
<input type="text" class="form-control" value="{{$fileinfo->arrival_date}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Tr in Val</label>
<input type="text" class="form-control" value="{{$fileinfo->tr_in_val}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">PR Disc</label>
<input type="text" class="form-control" value="{{$fileinfo->pr_disc}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Civil Id</label>
<input type="text" class="form-control" value="{{$fileinfo->civil_id}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Cust Tele 1</label>
<input type="text" class="form-control" value="{{$fileinfo->cust_tele_1}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Cust Tele 2</label>
<input type="text" class="form-control" value="{{$fileinfo->cust_tele_2}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Cust Tele 3</label>
<input type="text" class="form-control" value="{{$fileinfo->cust_tele_3}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Nationality</label>
<input type="text" class="form-control" value="{{$fileinfo->nationality}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Position</label>
<input type="text" class="form-control" value="{{$fileinfo->position}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">AC Status</label>
<input type="text" class="form-control" value="{{$fileinfo->ac_status}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Prog Status</label>
<input type="text" class="form-control" value="{{$fileinfo->prog_status}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Deposit</label>
<input type="text" class="form-control" value="{{$fileinfo->deposit}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Invoice Total</label>
<input type="text" class="form-control" value="{{$fileinfo->invoice_total}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Cust Amount</label>
<input type="text" class="form-control" value="{{$fileinfo->custamount}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Main Invoice</label>
<input type="text" class="form-control" value="{{$fileinfo->main_invoice}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Total</label>
<input type="text" class="form-control" value="{{$fileinfo->total}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">PF No</label>
<input type="text" class="form-control" value="{{$fileinfo->pfno}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Card Used</label>
<input type="text" class="form-control" value="{{$fileinfo->card_used}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Buyback Pol</label>
<input type="text" class="form-control" value="{{$fileinfo->buyback_pol}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Target</label>
<input type="text" class="form-control" value="{{$fileinfo->target}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">DOB</label>
<input type="text" class="form-control" value="{{$fileinfo->dob}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Accessory</label>
<input type="text" class="form-control" value="{{$fileinfo->accessory}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Description</label>
<input type="text" class="form-control" value="{{$fileinfo->description}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Gender</label>
<input type="text" class="form-control" value="{{$fileinfo->gender}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">AD1</label>
<input type="text" class="form-control" value="{{$fileinfo->ad1}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">AD2</label>
<input type="text" class="form-control" value="{{$fileinfo->ad2}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">AD3</label>
<input type="text" class="form-control" value="{{$fileinfo->ad3}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">AD4</label>
<input type="text" class="form-control" value="{{$fileinfo->ad4}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Delivery Date by Delivery Team</label>
<input type="text" class="form-control" value="{{$fileinfo->Deliverydate_by_delivery_team}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">PDI</label>
<input type="text" class="form-control" value="{{$fileinfo->pdi}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Email</label>
<input type="text" class="form-control" value="{{$fileinfo->email}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Language</label>
<input type="text" class="form-control" value="{{$fileinfo->language}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Last Service Date</label>
<input type="text" class="form-control" value="{{$fileinfo->lastservicedate}}">
</div>

@endif
@elseif($filetype == '2')
<?php $fileinfo = DB::table('honda_post_service_followup')->where('leadid',$leadid)->first(); ?>
@if($fileinfo)

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Account</label>
<input type="text" class="form-control" value="{{$fileinfo->account}}">
</div>


<div class="form-group col-md-4">
<label for="exampleInputEmail1">Invoice</label>
<input type="text" class="form-control" value="{{$fileinfo->invoice}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">WIP No</label>
<input type="text" class="form-control" value="{{$fileinfo->wip_no}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Date</label>
<input type="text" class="form-control" value="{{$fileinfo->date}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Registration Number</label>
<input type="text" class="form-control" value="{{$fileinfo->registration_number}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Title /Initls /Surname</label>
<input type="text" class="form-control" value="{{$fileinfo->title_initls_surname}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Mobile</label>
<input type="text" class="form-control" value="{{$fileinfo->mobile}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Gen</label>
<input type="text" class="form-control" value="{{$fileinfo->gen}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Nationality</label>
<input type="text" class="form-control" value="{{$fileinfo->nationality}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Date of Birth</label>
<input type="text" class="form-control" value="{{$fileinfo->date_of_birth}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Model Code</label>
<input type="text" class="form-control" value="{{$fileinfo->model_code}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Year</label>
<input type="text" class="form-control" value="{{$fileinfo->year}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Oper Code</label>
<input type="text" class="form-control" value="{{$fileinfo->oper_code}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Operatror Name</label>
<input type="text" class="form-control" value="{{$fileinfo->operatror_name}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Target</label>
<input type="text" class="form-control" value="{{$fileinfo->target}}">
</div>


@endif
@elseif($filetype == '3')
<?php $fileinfo = DB::table('honda_post_service_body_shop')->where('leadid',$leadid)->first(); ?>
@if($fileinfo)

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Account</label>
<input type="text" class="form-control" value="{{$fileinfo->account}}">
</div>


<div class="form-group col-md-4">
<label for="exampleInputEmail1">Invoice</label>
<input type="text" class="form-control" value="{{$fileinfo->invoice}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">WIP No</label>
<input type="text" class="form-control" value="{{$fileinfo->wip_no}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Date</label>
<input type="text" class="form-control" value="{{$fileinfo->date}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Registration Number</label>
<input type="text" class="form-control" value="{{$fileinfo->registration_number}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Title /Initls /Surname</label>
<input type="text" class="form-control" value="{{$fileinfo->title_initls_surname}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Mobile</label>
<input type="text" class="form-control" value="{{$fileinfo->mobile}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Gen</label>
<input type="text" class="form-control" value="{{$fileinfo->gen}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Nationality</label>
<input type="text" class="form-control" value="{{$fileinfo->nationality}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Date of Birth</label>
<input type="text" class="form-control" value="{{$fileinfo->date_of_birth}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Model Code</label>
<input type="text" class="form-control" value="{{$fileinfo->model_code}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Year</label>
<input type="text" class="form-control" value="{{$fileinfo->year}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Oper Code</label>
<input type="text" class="form-control" value="{{$fileinfo->oper_code}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Operatror Name</label>
<input type="text" class="form-control" value="{{$fileinfo->operatror_name}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Target</label>
<input type="text" class="form-control" value="{{$fileinfo->target}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Relation</label>
<input type="text" class="form-control" value="{{$fileinfo->relation}}">
</div>


@endif
@elseif($filetype == '4')
<?php $fileinfo = DB::table('honda_service_reminder')->where('leadid',$leadid)->first(); ?>
@if($fileinfo)

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Cont Date</label>
<input type="text" class="form-control" value="{{$fileinfo->contdate}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Agent</label>
<input type="text" class="form-control" value="{{$fileinfo->agent}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Follow up Exec</label>
<input type="text" class="form-control" value="{{$fileinfo->followup_exec}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Fup Date</label>
<input type="text" class="form-control" value="{{$fileinfo->fup_date}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Origin</label>
<input type="text" class="form-control" value="{{$fileinfo->origin}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Notes</label>
<input type="text" class="form-control" value="{{$fileinfo->notes}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Target</label>
<input type="text" class="form-control" value="{{$fileinfo->target}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Cust Name</label>
<input type="text" class="form-control" value="{{$fileinfo->custname}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Phone</label>
<input type="text" class="form-control" value="{{$fileinfo->phone}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Status</label>
<input type="text" class="form-control" value="{{$fileinfo->status}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">No of Flup</label>
<input type="text" class="form-control" value="{{$fileinfo->no_of_flup}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">First Flup</label>
<input type="text" class="form-control" value="{{$fileinfo->first_flup}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Last Flup</label>
<input type="text" class="form-control" value="{{$fileinfo->last_flup}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Flup Notes</label>
<input type="text" class="form-control" value="{{$fileinfo->flup_notes}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Email</label>
<input type="text" class="form-control" value="{{$fileinfo->email}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Mileage</label>
<input type="text" class="form-control" value="{{$fileinfo->mileage}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Reg No</label>
<input type="text" class="form-control" value="{{$fileinfo->regno}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Chassis No</label>
<input type="text" class="form-control" value="{{$fileinfo->email}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Model</label>
<input type="text" class="form-control" value="{{$fileinfo->model}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Model Year</label>
<input type="text" class="form-control" value="{{$fileinfo->modelyear}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Last Comment</label>
<input type="text" class="form-control" value="{{$fileinfo->last_comment}}">
</div>


@endif
@elseif($filetype == '5')
<?php $fileinfo = DB::table('honda_test_drive_survey')->where('leadid',$leadid)->first(); ?>
@if($fileinfo)

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Date Out</label>
<input type="text" class="form-control" value="{{$fileinfo->date_out}}">
</div>


<div class="form-group col-md-4">
<label for="exampleInputEmail1">Time Out</label>
<input type="text" class="form-control" value="{{$fileinfo->time_out}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Model</label>
<input type="text" class="form-control" value="{{$fileinfo->model}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Variant</label>
<input type="text" class="form-control" value="{{$fileinfo->variant}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Status</label>
<input type="text" class="form-control" value="{{$fileinfo->status}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Sold</label>
<input type="text" class="form-control" value="{{$fileinfo->sold}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">C</label>
<input type="text" class="form-control" value="{{$fileinfo->c}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">QC</label>
<input type="text" class="form-control" value="{{$fileinfo->qc}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">E</label>
<input type="text" class="form-control" value="{{$fileinfo->e}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Q</label>
<input type="text" class="form-control" value="{{$fileinfo->q}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">O</label>
<input type="text" class="form-control" value="{{$fileinfo->o}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">C2</label>
<input type="text" class="form-control" value="{{$fileinfo->c2}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">A</label>
<input type="text" class="form-control" value="{{$fileinfo->a}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">i</label>
<input type="text" class="form-control" value="{{$fileinfo->i}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">L</label>
<input type="text" class="form-control" value="{{$fileinfo->l}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">X</label>
<input type="text" class="form-control" value="{{$fileinfo->x}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">QQ</label>
<input type="text" class="form-control" value="{{$fileinfo->qq}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Sales Exec</label>
<input type="text" class="form-control" value="{{$fileinfo->salesexec}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Target No</label>
<input type="text" class="form-control" value="{{$fileinfo->targetno}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Customer Nam</label>
<input type="text" class="form-control" value="{{$fileinfo->customer_nam}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Contact</label>
<input type="text" class="form-control" value="{{$fileinfo->contact}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Target Creator</label>
<input type="text" class="form-control" value="{{$fileinfo->target_creator}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Approved By</label>
<input type="text" class="form-control" value="{{$fileinfo->approved_by}}">
</div>
@endif
@elseif($filetype == '6')
<?php $fileinfo = DB::table('honda_leads')->where('leadid',$leadid)->first(); ?>
@if($fileinfo)
<div class="form-group col-md-4">
<label for="exampleInputEmail1">Vehicle</label>
<input type="text" class="form-control" value="{{$fileinfo->vehicle}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Created Time</label>
<input type="text" class="form-control" value="{{$fileinfo->created_time}}">
</div>


<div class="form-group col-md-4">
<label for="exampleInputEmail1">Platform</label>
<input type="text" class="form-control" value="{{$fileinfo->platform}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Current Car</label>
<input type="text" class="form-control" value="{{$fileinfo->current_car}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">First Name</label>
<input type="text" class="form-control" value="{{$fileinfo->first_name}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Last Name</label>
<input type="text" class="form-control" value="{{$fileinfo->last_name}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Phone Number</label>
<input type="text" class="form-control" value="{{$fileinfo->phone_number}}">
</div>

<div class="form-group col-md-4">
<label for="exampleInputEmail1">Email</label>
<input type="text" class="form-control" value="{{$fileinfo->email}}">
</div>
@endif
</div>
</section>
</div>
</div>
@endif
