
<header class="panel-heading wht-bg">
   <h4 class="gen-case"> Vehicle History
	<a href="#"  class="btn btn-info pull-right">
        <!-- {{$campaignid}} -  -->{{$ingroup}} - {{$listname}}
    </a>
   </h4>
</header>


<div class="row">

<div class="col-lg-9">
<section class="panel">

<div class="prf-box">
<h3 class="prf-border-head">
Vehicles
</h3>
</header>
<ul class="nav nav-pills" id="vehicle_history_list">
</ul>
<br>
<div class="form-group col-md-4">
    <!-- <label for="exampleInput">List ID</label> -->
    <select name="status_brand" id="status_brand" class="form-control" onChange="checkservicecentre(this.value);">
        <option value="">Select</option>
        <option value="Chevrolet">Chevrolet</option>
        <option value="Cadillac">Cadillac</option>
    </select>
</div>
<div class="form-group col-md-4">
    <!-- <label for="exampleInput">List ID</label> -->
    <select name="status_centre" id="status_centre" class="form-control" disabled="">
        <option value="">Select</option>
        <option value="SO_13">SERVICE CENTER - SHUWAIKH</option>
        <option value="SO_25">SAFAT ALGHANIM SERVICE CENTER - FAHAHEEL</option>
    </select>
</div>
<div class="form-group col-md-4">
<a class="btn btn-danger btn-block" id="showvehstatus" onclick="showvehstatus();">Show Status</a>
</div>
<div class="form-group col-md-12" style="display: none;" id="statusdetailsdiv">
            <div class="alert alert-success alert-block fade in col-md-12" style="font-size: 18px;">
                
            <p id="statusdetails">Waiting....
            </p>
                
            </div>
</div>
</div>

</section>
</div>

<div class="col-lg-3">
<section class="panel">
<div class="panel-body">


	    <div class="pull-right mail-src-position">
        <div class="input-append">
            <input type="text" class="form-control " placeholder="Search...">
        </div>
    </div>

</div>
</section>
</div>

</div>


<div class="row">
<div class="col-lg-12">

<section class="panel">
<header class="panel-heading">
Vehicle Service History
</header>
<div class="panel-body">
<table class="table table-striped">
<thead>
<tr>
<th>Code</th>
<th>Date</th>
<th>Mileage</th>
<th>Details</th>
<th>WIP</th>
<th>Account</th>
<th>Value</th>
<th>Invoice</th>
<th>Branch</th>
</tr>
</thead>
<tbody id="historyHTML">

</tbody>
</table>
</div>
</section>
</div>
</div>


<div class="row">
<div class="col-lg-8">

<section class="panel">
<div class="prf-box">
        <h3 class="prf-border-head">All Vehicle Purchase History</h3>                 
<div method="post">
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Showroom</label>
<input type="text" class="form-control" name="showroom1" id="showroom1" value="" placeholder="Enter Vehicle Showroom">
</div>

<div class="form-group col-md-6">
<label for="exampleInputEmail1">Salesman</label>
<input type="text" class="form-control" name="salesman1" id="salesman1" value="" placeholder="Enter Vehicle Salesman">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Vehicle Registration Number</label>
<input type="text" class="form-control" name="regno1" id="regno1" value="" placeholder="Enter Vehicle Registration">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Description of Car</label>
<input type="text" class="form-control" name="description1" id="description1" value="" placeholder="Enter Vehicle Description">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Available Vehicle : Brand Model</label>
<input type="text" class="form-control" name="model1" id="model1" value="" placeholder="Enter Vehicle Brand">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Date of Vehicle Invoiced</label>
<input type="text" class="form-control" name="invno1" id="invno1" value="" placeholder="Enter Vehicle Invoiced">
</div>

</div>
</div>
</section>
</div>

<div class="col-lg-4">


@if(count($upscales) > 0)
<!--carousel start-->
<section class="panel">

<div class="prf-box">
        <h3 class="prf-border-head">VEHICLE RELATED OFFER</h3> 
<div id="c-slide" class="carousel slide panel-body" data-ride="carousel">
<ol class="carousel-indicators out">
<?php for($i=0; $i<count($upscales); $i++ ) {
if($i == '0'){
$rowclass = 'active';
}
else{
$rowclass = '';
} ?>
<li class="{{$rowclass}}" data-slide-to="{{$i}}" data-target="#c-slide"></li>
<?php } $rowcount=0; ?>
</ol>
<div class="carousel-inner">
@foreach($upscales as $upscale)
<?php
if($rowcount == '0'){
$rowclass1 = 'active';
}
else{
$rowclass1 = '';
} ?>
<div class="item text-center {{$rowclass1}}">
<h3 style="color: #fa8564;">{{$upscale->topic}}</h3>
<p style="color: #95b75d;">{{$upscale->description}}</p>
</div>
<?php $rowcount++; ?>
@endforeach
</div>
<a data-slide="prev" href="{{asset('/bucket')}}/#c-slide" class="left carousel-control">
<i class="fa fa-angle-left"></i>
</a>
<a data-slide="next" href="{{asset('/bucket')}}/#c-slide" class="right carousel-control">
<i class="fa fa-angle-right"></i>
</a>
</div>
</div>
</section>
<!--carousel end-->
@endif
</div>
</div>

<div class="row">
<div class="col-lg-8">
	
<section class="panel">
<div class="prf-box">
        <h3 class="prf-border-head">Service Reminder</h3>                 
<div method="post">
{{csrf_field()}}
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Last Service</label>
<input type="text" class="form-control" name="lastserv1" id="lastserv1" value="" placeholder="Enter Last Service">
</div>

<div class="form-group col-md-6">
<label for="exampleInputEmail1">Next Service Date</label>
<input type="text" class="form-control" name="nextserv1" id="nextserv1" value="" placeholder="Enter Vehicle Next Service">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Date Last Work</label>
<input type="text" class="form-control" name="lastwork1" id="lastwork1" value="" placeholder="Enter Vehicle Last Work">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Service Contract #</label>
<input type="text" class="form-control" name="contract1" id="contract1" value="" placeholder="Enter Service Contract">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Timing Belt Mileage</label>
<input type="text" class="form-control" name="timebelt1" id="timebelt1" value="" placeholder="Enter Timing Belt Mileage">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Last MOT Date</label>
<input type="text" class="form-control" name="motdate1" id="motdate1" value="" placeholder="Enter Vehicle Last MOT Date">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">MOT Due</label>
<input type="text" class="form-control" name="motdue1" id="motdue1" value="" placeholder="Enter MOT Due">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Return Parts</label>
<input type="text" class="form-control" name="returnparts1" id="returnparts1" value="" placeholder="Enter Vehicle Plate Number">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Next Emission Check</label>
<input type="text" class="form-control" name="nextemission1" id="nextemission1" value="" placeholder="Enter Vehicle Return Parts">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Emissions</label>
<input type="text" class="form-control" name="emission1" id="emission1" value="" placeholder="Enter Emissions">
</div>

</div>
</div>
</section>
</div>

<div class="col-lg-4">

<section class="panel">
<div class="prf-box">
        <h3 class="prf-border-head">Warranty and Service Package</h3>                 
<div method="post">
<div class="form-group col-md-12">
<label for="exampleInputEmail1">Warranty Start</label>
<input type="text" class="form-control" name="mntstart" id="mntstart" value="" placeholder="Enter Warranty Start">
</div>
<div class="form-group col-md-12">
<label for="exampleInputEmail1">Warranty End</label>
<input type="text" class="form-control" name="mntend" id="mntend" value="" placeholder="Enter Warranty End">
</div>
<div class="form-group col-md-12">
<label for="exampleInputEmail1">Warranty Amount</label>
<input type="text" class="form-control" name="mntref" id="mntref" value="" placeholder="Enter Warranty Ref">
</div>
<div class="form-group col-md-12">
<label for="exampleInputEmail1">Warranty Mile</label>
<input type="text" class="form-control" name="mntmile" id="mntmile" value="" placeholder="Enter Warranty Mile">
</div>

</div>
</div>
</section>
</div>



</div>