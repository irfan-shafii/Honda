<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="ThemeBucket">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="shortcut icon" href="{{asset('/bucket')}}/images/favicon.html">

    <title>Customer Info page</title>


@include('layouts.css')

<style type="text/css">
  .form-control{
    color: #4c4a4a !important;
  }

a.ex2:hover, a.ex2:active {font-size: 150%;}


/* Paste this css to your style sheet file or under head tag */
/* This only works with JavaScript, 
if it's not present, don't show loader */
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url(http://i.stack.imgur.com/FhHRx.gif) center no-repeat #fff;
}
</style>

</head>

  <body class="full-width">

  <!-- Paste this code after body tag -->
  <div class="se-pre-con"></div>
  <!-- Ends -->
  <section id="container" class="hr-menu">
      <!--header start-->
      <header class="header fixed-top">
          <div class="navbar-header">
              <button type="button" class="navbar-toggle hr-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span class="fa fa-bars"></span>
              </button>

              <!--logo start-->
              <!--logo start-->
              <div class="brand ">
                  <a href="#" class="logo">
                      <img src="http://subscriber.clgnote.in/assets/img/logo-full.png" alt="">
                  </a>
              </div>
              <!--logo end-->
              <!--logo end-->
              <div class="horizontal-menu navbar-collapse collapse ">

              </div>
              <div class="top-nav hr-top-nav">
              </div>

          </div>

      </header>
      <!--header end-->
      <!--sidebar start-->

      <!--sidebar end-->
<!--main content start-->
<section id="main-content">
<section class="wrapper">

            <!--tab nav start-->
            <section class="panel">
                <header class="panel-heading tab-bg-dark-navy-blue">
                    <ul class="nav nav-tabs">
                        <li class="active">
                            <a data-toggle="tab" href="#customer-info">
                                <i class="fa fa-home"></i>
                                Customer &amp; Vehicle Informations
                            </a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#vehicle-info">
                                <i class="fa fa-gears"></i>
                                Vehicle Details
                            </a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#contact-info">
                                <i class="fa fa-envelope-o"></i>
                                Contact Informations - Email &amp; SMS
                            </a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#csi-info" id="csibtn">
                                <i class="fa fa-comments-o"></i>
                                CSI Questions
                            </a>
                        </li>
                      @if($listid == '999')
                        <li>
                            <a data-toggle="tab" href="#log-calls" id="logbtn">
                                <i class="fa fa-building-o"></i>
                                Call Log Report
                            </a>
                        </li>
                      @endif
                      @if($listid == '1005')
                        <li>
                            <a data-toggle="tab" href="#lead-info" id="leadbtn">
                                <i class="fa fa-building-o"></i>
                                Lead Details
                            </a>
                        </li>
                      @endif
                      @if(!empty($filetype))
                        <li>
                            <a data-toggle="tab" href="#other-info" id="otherbtn">
                                <i class="fa fa-keyboard-o"></i>
                                Other Details
                            </a>
                        </li>
                      @endif
                    </ul>
                </header>
                <div class="panel-body">
	                    <div class="tab-content">
	                    <div id="customer-info" class="tab-pane active">
      						@include('customer.ext_customer')
                        </div>
                        <div id="vehicle-info" class="tab-pane ">
                        @include('customer.ext_vehicle')
                    	</div>
                        <div id="contact-info" class="tab-pane ">
                        @include('customer.ext_contact')
                    	</div>
                        <div id="csi-info" class="tab-pane ">
                        @include('customer.ext_csi')
                      </div>
                        <div id="log-calls" class="tab-pane ">
                        @include('customer.ext_calls')
                      </div>
                        <div id="lead-info" class="tab-pane ">
                        @include('customer.ext_leads')
                      </div>
                        <div id="other-info" class="tab-pane ">
                      @if(!empty($filetype))
                        @include('customer.ext_others')
                      @endif
                      </div>
                    </div>
                </div>
            </section>
            <!--tab nav end-->

<div class="row">
<div class="col-lg-12">
<section class="panel">
<header class="panel-heading">
Enquiry Details
</header>
<div class="panel-body">
<div class="form-group col-md-3">
<label for="exampleInputEmail1">Enquiry Category</label>
<select class="form-control" name="category" id="category" onChange="getcategory(this.value);" required="">
<option value="">Select</option>
@foreach($enquiry_categories as $category)
<option value="{{$category->id_enquiry_category}}">{{$category->category_name}}</option>
@endforeach
</select>
</div>
<div class="form-group col-md-3" id="subdiv1" style="display: none;">
<label for="exampleInputEmail1" id="subcatname1"></label>
<select class="form-control" name="subcategory1" id="subcategory1" onChange="getcategory(this.value);" required="">
<option value="">Select</option>
</select>
<!-- <div id="subcatdiv1"></div>  --> 
</div>
<div class="form-group col-md-3" id="subdiv2" style="display: none;">
<label for="exampleInputEmail1" id="subcatname2"></label>
<select class="form-control" name="subcategory2" id="subcategory2" onChange="getcategory(this.value);" required="">
<option value="">Select</option>
</select>
<!-- <div id="subcatdiv2"></div> -->
</div>
<div class="form-group col-md-3" id="subdiv3" style="display: none;">
<label for="exampleInputEmail1" id="subcatname3"></label>
<select class="form-control" name="subcategory3" id="subcategory3" onChange="getcategory(this.value);" required="">
<option value="">Select</option>
</select>
<!-- <div id="subcatdiv3"></div> -->
</div>
<div class="col-md-12"></div>
<div id="apptabdiv" style="display: none;">
<div class="form-group col-md-3">
<label for="exampleInputEmail1">Source Of Business</label>
<select class="form-control" name="source_name" id="source_name">
<option value="">Select</option>
@foreach($sourcebusiness as $source)
<option value="{{$source->source_name}}">{{$source->source_name}}</option>
@endforeach
</select>
</div>
<div class="form-group col-md-3">
<label for="exampleInputEmail1">Appointment Booked ?</label>
<select class="form-control" name="apptab" id="apptab" onChange="getapptab(this);">
<option value="">Select</option>
<option value="Yes">Yes</option>
<option value="No">No</option>
<option value="No-Details/Intrested">No-Details/Intrested</option>
</select>
</div>
</div>
<div id="subtype1_x" style="display: none;">


<div class="form-group col-md-3">
<label for="exampleInputPassword1">Brand</label>
<select class="form-control" name="interest" id="interest" onchange="getmodel(this.value);">
<option value="">Select</option>
@foreach($brands as $brand)
    <option value="{{$brand->name}}">{{$brand->name}}</option>
@endforeach
</select>
</div>

<div class="form-group col-md-3 modeldiv" id="modeldiv">
<label for="exampleInputEmail1">Model Of Interest</label>
<select class="form-control" name="brandmodel" id="brandmodel" onchange="getbrand(this.value);">
<option value="">Select</option>
@foreach($brand_models as $model)
    <option value="{{$model->name}}">{{$model->name}}</option>
@endforeach
</select>
</div>

</div>

<div class="col-md-12"></div>
<div id="agentDiv" style="display: none;">
<div class="form-group col-md-3">
<label for="exampleInputPassword1">Call Center Agent Name</label>
<input type="text" class="form-control" value="{{$user_info}}" placeholder="{{$user_info}}" readonly="">
</div>
</div>
<input type="hidden" name="agent_name" id="agent_name"  value="{{$user_info}}">

<div id="subtype1" style="display: none;">

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Showroom Name</label>
<select class="form-control" name="showroomid" id="showroomid" onchange="getsalesman(this);">
    <option value="">Select</option>
@foreach($showrooms as $showroom)
    <option value="{{$showroom->id}}">{{$showroom->name}}</option>
@endforeach
</select>
<input type="hidden" name="showroom" id="showroom" value="">
</div>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Booked to Salesman</label>
<select class="form-control" name="salesman" id="salesman">
    <option value="">Select</option>
</select>
</div>

<div class="col-md-12"></div>
<div class="form-group col-md-3">
<label for="exampleInputPassword1">Type of Appoinment / Enquiry</label>
<select class="form-control" name="appointmenttype" id="appointmenttype" >
<option value="">Select</option>
<option value="ENO- Enquire Offers">ENO- Enquire Offers</option>
<option value="ENP- Enquire Price">ENP- Enquire Price</option>
<option value="ENS- Enquire Specifications">ENS- Enquire Specifications</option>
<option value="RQT- Request Quotation">RQT- Request Quotation</option>
<option value="SRA- Showroom Appointment">SRA- Showroom Appointment</option>
<option value="TDR- TestDrive Appointment">TDR- TestDrive Appointment</option>
<option value="VAV- Vehicle Availability">VAV- Vehicle Availability</option>
</select>
</div>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Appointment Code</label>
<select class="form-control" name="appointmentcode1" id="appointmentcode1" >
<option value="">Select</option><option value="APP- Mobile App">APP- Mobile App</option>
<option value="IPC- Incoming Phone Call">IPC- Incoming Phone Call</option>
<option value="ONL -Online">ONL -Online </option>
<option value="SOM- Social Media">SOM- Social Media</option>
<option value="WAP- Whatsapp">WAP- Whatsapp</option>
</select>
</div>

</div>

<div id="subtype2" style="display: none;">

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Service Center</label>
<select class="form-control" name="center_id" id="center_id" onchange="getadvisor(this);">
    <option value="">Select</option>
@foreach($centers as $center)
    <option value="{{$center->id}}">{{$center->name}}</option>
@endforeach
</select>
<input type="hidden" name="servicecenter" id="servicecenter" value="">
</div>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Service Advisor Name</label>
<select class="form-control" name="advisorname" id="advisorname">
    <option value="">Select</option>
</select>
</div>
<div class="form-group col-md-3">
<label for="exampleInputPassword1">Appointment Code</label>
<select class="form-control" name="appointmentcode" id="appointmentcode" >
<option value="">Select</option>
<option value="APC- Appointment Confirmation">APC- Appointment Confirmation</option>
<option value="APP- Mobile App">APP- Mobile App</option>
<option value="IPC- Incoming Phone Call">IPC- Incoming Phone Call</option>
<option value="SER- Service Reminder">SER- Service Reminder</option>
<option value="SOM- Social Media">SOM- Social Media</option>
<option value="WAP- Whatsapp">WAP- Whatsapp</option>
<option value="REC -Recalls">REC -Recalls </option>
<option value="CAM-Campaign">CAM-Campaign</option>
</select>
</div>
</div>

<div class="form-group col-md-3" id="appointmentDiv" style="display: none;">
<label for="exampleInputPassword1">Appointment Date & Time</label>
<input size="16" type="text" value="" name="appointment" id="appointment" class="form_datetime form-control" autocomplete="off">
</div>

      
<div class="col-md-12"> </div>
<div class="form-group col-md-6">
<label for="exampleInputPassword1">Enquiry Description</label>
<textarea type="text" class="form-control" name="description" id="message"></textarea>
</div>

<div class="form-group col-md-3" id="recreasons" style="display: none;">
<label for="exampleInputEmail1">Recycled reasons :</label>
<select class="form-control" name="recreason" id="recreason">
<option value="">Select</option>
<option value="Towed by crane  سحب بواسطة رافعة ">Towed by crane  سحب بواسطة رافعة </option>
<option value="Brought or serviced by different person  أحضر أو ​​تم عمل الخدمة من قبل شخص مختلف  ">Brought or serviced by different person  أحضر أو ​​تم عمل الخدمة من قبل شخص مختلف  </option>
<option value="Wrong Vehicle  سيارة اخرى  ">Wrong Vehicle  سيارة اخرى  </option>
<option value="Docent want to cooperate  رفض التعاون  ">Docent want to cooperate  رفض التعاون  </option>
<option value="Repeated customer  عميل مكرر  ">Repeated customer  عميل مكرر  </option>
</select>
</div>

<input type="hidden" name="enq_account" id="enq_account" value="{{$id_account}}">
<input type="hidden" name="fname1" id="fname1" value="">
<input type="hidden" name="lname1" id="lname1" value="">
<input type="hidden" name="mobile2" id="amobile2" value="">
<input type="hidden" name="phone_number" id="phone_number" value="{{$mobile_number}}">
<input type="hidden" name="user_info" id="userid" value="{{$user_info}}">
<input type="hidden" name="listid" id="listid" value="{{$listid}}">
<input type="hidden" name="campaignid" id="campaignid" value="{{$campaignid}}">
<input type="hidden" name="ingroup" id="ingroup" value="{{$ingroup}}">
<input type="hidden" name="chasisid" id="chasisid" value="{{$chasis}}">
<input type="hidden" name="leadid" id="leadid" value="{{$leadid}}">
<input type="hidden" id="csimasterid" value="0">
<input type="hidden" id="serviceadvisor" value="">
<input type="hidden" id="deliveryadvisor" value="">
<input type="hidden" name="recycif" id="recycif" value="0">
<div class="form-group col-md-3">
  <h6 style='color:#F44336;display: none;' id="submittitle"></h6>
<input type="button" class="btn btn-danger btn-block" id="enqsubmitbtn" value="Submit" onclick="submitform();">
<!-- <a href="#" class="form-control btn btn-danger btn-block">Close</a> -->
</div>

</div>
</form>
</section>
</div>
</div>





<div class="row">
<div class="col-lg-12">

<section class="panel">
<header class="panel-heading">
Enquiries List
</header>
<div class="panel-body">
<table class="table table-striped">
<thead>
<tr>
<th>#</th>
<th>Agent ID</th>
<th>Type</th>
<th>Date</th>
<th>Category</th>
<th>Sub Category</th>
<th>Description</th>
</tr>
</thead>
<tbody id="enqHTML">
  {!!$enqHTML!!}
</tbody>
</table>
</div>
</section>
</div>
</div>


      <!--footer start-->
      <footer class="footer-section">
          <div class="text-center">
              2019 &copy; Centrixplus
          </div>
      </footer>
      <!--footer end-->
  </section>
</section>

  <!-- Placed js at the end of the document so the pages load faster -->

                            <!-- Modal -->
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title">http://37.34.236.116:1180/alghanim/public/laravel_installation.txt</h4>
                                        </div>
                                        <div class="modal-body">

                                           <object data="" id="txtdocument" width="100%" height="900">

                                        </div>
                                        <div class="modal-footer">
                                            <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                                            <button class="btn btn-success" type="button">Save changes</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- modal -->

@include('layouts.script')
<script>
  //paste this code under head tag or in a seperate js file.
  // Wait for window load
  $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");
  $('.se-pre-con').hide();
    var cusid = $("#firstcustomer").val();
    var listid = $("#listid").val();

    slectcategory(listid);
    //alert(cusid);

        if(cusid != '0'){
          //alert(cusid);
        customerinfo(cusid);
        }

  });

</script>
  <script type="text/javascript">

  function slectcategory(listid) {

      if(listid == '1002'){
            urlcode = "APP";
       }
       else if(listid == '1008' || listid == '5008' || listid == '5009' || listid == '2007' || listid == '2008'){
            urlcode = "AAP";
       }
       else if(listid == '1004' || listid == '2003' || listid == '2004'){
            urlcode = "GSP";
       }
       else if(listid >= '3001' && listid <= '3017'){
            urlcode = "GSP";
       }
       else if(listid >= '4000' && listid <= '4008'){
            urlcode = "GSP";
       }
       else if(listid >= '5000' && listid <= '5007'){
            urlcode = "BTB";
       }
       else if(listid >= '8001' && listid <= '8009'){
            urlcode = "BTB";
       }
       else if(listid >= '9001' && listid <= '9006'){
            urlcode = "BTB";
       }
       else{
            urlcode = "";        
       }

      if(urlcode == 'GSP'){
        $('#category').val(110);
        getcategory(110);
      }
      else if(urlcode == 'AAP'){
        $('#category').val(109);
        getcategory(109);
      }
      else if(urlcode == 'BTB'){
        $('#category').val(111);
        getcategory(111);
      }
  }

  function submitform() {

    var retsubmit = 0;
        $('#category').prop("disabled", false);
        $('#subcategory1').prop("disabled", false);
        $('#subcategory2').prop("disabled", false);

  var recycif = $("#recycif").val();
  //alert(recycif);
  if(recycif == '1'){
    var recreason = $("#recreason").val();
    if(recreason == ''){
        $("#submittitle").html("Please select recycle reason, this field cannot be empty...");
        $("#submittitle").show();
        retsubmit = 1;
    }
  }

  if(retsubmit == '0'){
    $("#submittitle").hide();
    $('#userform').submit();
  }
    //$('#enquiryform').submit();
  }

var input = document.getElementById("phsearch");
input.addEventListener("keyup", function(event) {
  if (event.keyCode === 13) {
   event.preventDefault();
   document.getElementById("searchbtn").click();
   //searchph()
  }
});
  function search() {

  var user = document.getElementById("userid").value;
  var listid = document.getElementById("listid").value;
  var campaignid = document.getElementById("campaignid").value;
  var ingroup = document.getElementById("ingroup").value;
  var chasisid = document.getElementById("chasisid").value;
  var leadid = document.getElementById("leadid").value;
  var phone = document.getElementById("phsearch").value;
  var checked = $('input[name="searchcon"]:checked').val();
        if(checked == 'mobile')   {
        if (phone.length == '8') {
            window.location = "{{url('/')}}/customer/"+phone+"/"+user+"/"+listid+"/"+campaignid+"/"+ingroup+"/0/"+leadid;
        }
        else{
            alert('Mobile Number Must Be 8 Digits');
        }
        }
        if(checked == 'chassis')   {
        if (phone.length == '6') {
            window.location = "{{url('/')}}/customer_chasis/"+phone+"/"+user+"/"+listid+"/"+campaignid+"/"+ingroup+"/0/"+leadid;
        }
        else{
            alert('Chassis Number Required Last 6 Digits');
        }
        }
        if(checked == 'regno')   {
        //alert(checked); 
        if (phone.length >= '1') {
        var regno = phone.replace("/", "__");    
        //alert(regno);     
            window.location = "{{url('/')}}/customer_regno/"+regno+"/"+user+"/"+listid+"/"+campaignid+"/"+ingroup+"/0/"+leadid;
        }
        else{
            alert('Register Number is Empty');
        }
        }
        if(checked == 'civil')   {
        if (phone.length == '12') {
        //alert(regno);     
            window.location = "{{url('/')}}/customer_civil/"+phone+"/"+user+"/"+listid+"/"+campaignid+"/"+ingroup+"/0/"+leadid;
        }
        else{
            alert('Civil ID Must Be 12 Digits');
        }
        }
  }


  function customerinfo(cusid) {
  //alert(cusid);
  var chasisid = $("#chasisid").val();
  var mobile = $("#mobile").val();
  $('.se-pre-con').show();
  $(".acclist").removeClass("active");
  $("#acclist"+cusid).addClass("active");
  $("#fname").val("");
  $("#lname").val("");
  $("#mobile2").val("");
  //$("#gender").val("");
  $("#civilid").val("");
  $("#address").val("");
  $("#id_account").val(0);
  $("#enq_account").val(0);
  $("#vehid_account").val(0);
  $("#enqHTML").html("");


  $("#vehicleinfo").val("");
  $("#vehmodel").val("");
  $("#vehyear").val("");
  $("#vehcolor").val("");
  $("#vehshowroom").val("");
  $("#plateno").val("");
  $("#chasisno").val("");
  $("#lastservice").val("");
  $("#nextservice").val("");
  $("#vehicle_id").val(0);

  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/customerinfo')}}",
    data: {cusid: cusid,chasisid: chasisid}, 
    dataType:'JSON', 
    success: function(data){

          $("#enqHTML").html(data.enqHTML);

          //var vehicles = data.vehicles;

          //var len =  vehicles.length; 
          //alert(data.fname+'  '+data.lname);
          $("#vehicle_list").html("");
          $('#vehicle_history_list').html("");
          $('#vehicle_contact_list').html("");

          $('#vehicle_list').html(data.divHtml);
          $('#vehicle_history_list').html(data.divHtml1);
          $('#vehicle_contact_list').html(data.divHtml2);
          $('#vehicle_csi_list').html(data.divHtml3);

          $("#fname").val(data.fname);
          $("#lname").val(data.lname);
          $("#mobile2").val(data.mobile2);
          //$("#gender").val(data.gender);
          $("#civilid").val(data.civilid);
          $("#address").val(data.address);
          $("#id_account").val(cusid);
          $("#vehid_account").val(cusid);

          $("#enq_account").val(cusid);
          $("#fname1").val(data.fname);
          $("#amobile2").val(data.mobile2);
          $("#lname1").val(data.lname);
          if(chasisid != '0'){
            vehicleinfo(data.chasisid);
          }


          $(".cusname").html(data.fname+" "+data.lname);
          $(".custarget").html(cusid);
          $(".cusphone").html(mobile);

          //$("#enqsubmitbtn").removeAttr("disabled");
  $('.se-pre-con').hide();

        },error:function(){ 
            //alert("error!!!!");
          $('.se-pre-con').hide();
        }
  });
  }


  function vehicleinfo(vehid) {
  //alert(vehid);
  $(".vehtarget").html(vehid);
  $('.se-pre-con').show();
  $(".vcclist").removeClass("active");
  $("#vcclist"+vehid).addClass("active");

  $(".vcc1list").removeClass("active");
  $("#vcc1list"+vehid).addClass("active");

  $(".vcc2list").removeClass("active");
  $("#vcc2list"+vehid).addClass("active");

  $(".vcc3list").removeClass("active");
  $("#vcc3list"+vehid).addClass("active");

   var cusid = $("#id_account").val();

  //alert(cusid);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/vehicleinfo')}}",
    data: {vehid: vehid,cusid: cusid}, 
    dataType:'JSON', 
    success: function(data){

          //alert(data.histyHTML);
          $("#historyHTML").html(data.histyHTML);

          $("#vehicleinfo").val(data.vehicleinfo);
          $("#vehmodel").val(data.vehmodel);
          $("#vehyear").val(data.vehyear);
          $("#vehcolor").val(data.vehcolor);
          $("#mileage").val(data.MILEAGE);
          $("#plateno").val(data.plateno);
          $("#regdate").val(data.regdate);
          $("#chasisno").val(data.chasisno);
          $("#lastservice").val(data.lastservice);
          $("#nextservice").val(data.nextservice);
          $("#vehicle_id").val(vehid);

          $("#model1").val(data.vehmodel);
          $("#motdate1").val(data.MOTDATE);
          $("#lastwork1").val(data.LASTWORK);
          $("#regno1").val(data.regno);
          $("#lastserv1").val(data.lastservice);
          $("#nextserv1").val(data.nextservice);
          

          $("#mntstart").val(data.mntstart);
          $("#mntend").val(data.mntend);
          $("#mntref").val(data.mntref);
          $("#mntmile").val(data.mntmile);

          $("#showroom1").val(data.showroom);
          $("#salesman1").val(data.salesman);
          //$("#model1").val(data.availmodel);
          $("#description1").val(data.description);
          $("#invno1").val(data.invoice);

          $('.se-pre-con').hide();
          getadvisorname(vehid);
          getcsi();

        $('#nextbtn').attr("disabled", false);

        },error:function(){ 
            //alert("error!!!!");
          $('.se-pre-con').hide();
        }
  });
  }

  function getcategory(idvalue) {
    //idvalue = id.value;
    //alert(idvalue);
    if(idvalue != ''){
    if(idvalue== '118' || idvalue== '119' || idvalue== '120'  || idvalue== '138' || idvalue== '139' ){
      $( "#csibtn" ).click();
      
        $('html, body').animate({
            scrollTop: $('#main-content').offset().top
        }, 'slow');
    }
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getcategory')}}",
    data: {idvalue: idvalue}, 
    dataType:'JSON', 
    success: function(data){
            //alert(data.categorytype);

        var categorytype = data.categorytype;


          $("#salesman").val("");
          $("#appointment").val("");
          $("#interest").val("");
          $("#appointmenttype").val("");
          $("#agentname").val("");
          $("#showroom").val("");
          $("#advisorname").val("");
          $("#appointmenttype").val("");
          $("#appointmenttype").val("");
          $("#subtype1").hide();
          $("#subtype1_x").hide();
          $("#subtype2").hide();
          $("#agentDiv").hide("");
          $("#appointmentDiv").hide("");
        //alert(categorytype);
        if(categorytype == '1'){
          $("#subcategory1").html("");
          $("#subcategory2").html("");
          $("#subcategory3").html("");
          $("#subcategory2").val("");
          $("#apptabdiv").hide();
          $("#apptab").val("");
          $("#subcategory3").val("");  
        if (data.divhtml != "") {

          $("#subdiv1").show();        
          $("#subdiv2").hide();
          $("#subdiv3").hide();
          $("#subcategory1").html(data.divhtml);
          $("#subcatname1").html(data.categoryname);

        }
        else{
          $("#subcategory1").html("");
          $("#subcategory2").html("");
          $("#subcategory3").html("");
          $("#subdiv1").hide();          
          $("#subdiv2").hide();
          $("#subdiv3").hide();
        }
          $("#subcatname2").html("");
          $("#subcatname3").html("");
        }

        if(categorytype == '2'){
          $("#subdiv3").hide();
          $("#subcategory2").html("");
          $("#subcategory3").html("");
          $("#subcategory3").val("");
        if (data.divhtml != "") {

          $("#subdiv2").show();  
          $("#subdiv3").hide();
          $("#subcategory2").html(data.divhtml);
          $("#subcatname2").html(data.categoryname);

        }
        else{  
          $("#subcategory2").html("");
          $("#subcategory3").html("");        
          $("#subdiv2").hide();
          $("#subdiv3").hide();
        }
          $("#subcatname3").html("");
        }

        if(categorytype == '3'){
          $("#subcategory3").html("");
        if (data.divhtml != "") {

          $("#subdiv3").show();
          $("#subcategory3").html(data.divhtml);
          $("#subcatname3").html(data.categoryname);

        }
        else{
          $("#subcategory3").html("");
          $("#subdiv3").hide();
        }
        }

        if(data.apptab == '1'){
          $("#apptabdiv").show();
        }
        else if(data.apptab == '0'){
          $("#apptab").val("");
          $("#source_name").val("");
          $("#apptabdiv").hide();
        }


    if(idvalue== '109' || idvalue== '110' || idvalue== '111'){

    var listid = $("#listid").val();


      if(listid == '1002'){
            urlcode = "APP";
       }
       else if(listid == '1008' || listid == '5008' || listid == '5009' || listid == '2007' || listid == '2008'){
            urlcode = "AAP";
       }
       else if(listid == '1004' || listid == '2003' || listid == '2004'){
            urlcode = "GSP";
       }
       else if(listid >= '3001' && listid <= '3017'){
            urlcode = "GSP";
       }
       else if(listid >= '4000' && listid <= '4008'){
            urlcode = "GSP";
       }
       else if(listid >= '5000' && listid <= '5007'){
            urlcode = "BTB";
       }
       else if(listid >= '8001' && listid <= '8009'){
            urlcode = "BTB";
       }
       else if(listid >= '9001' && listid <= '9006'){
            urlcode = "BTB";
       }
       else{
            urlcode = "";
       }

    //alert(listid + "    "+idvalue + "    "+urlcode);

      if(idvalue == '109'){

      if(urlcode == 'AAP'){
        $('#subcategory1').val(120);
        getcategory(120);
        $( "#csibtn" ).click();
      
        $('html, body').animate({
            scrollTop: $('#main-content').offset().top
        }, 'slow');

        $('#category').prop("disabled", 'disabled');
        $('#subcategory1').prop("disabled", 'disabled');
        $('#subcategory2').prop("disabled", 'disabled');
        $('#enqsubmitbtn').prop("disabled", 'disabled');
      }
      }
      else if(idvalue == '110'){
      if(urlcode == 'GSP'){
        $('#subcategory1').val(138);
        getcategory(138);
        $( "#csibtn" ).click();
      
        $('html, body').animate({
            scrollTop: $('#main-content').offset().top
        }, 'slow');

        $('#category').prop("disabled", 'disabled');
        $('#subcategory1').prop("disabled", 'disabled');
        $('#subcategory2').prop("disabled", 'disabled');
        $('#enqsubmitbtn').prop("disabled", 'disabled');
      }
      }
      else if(idvalue == '111'){
      if(urlcode == 'BTB'){
        $('#subcategory1').val(139);
        getcategory(139);
        $( "#csibtn" ).click();
      
        $('html, body').animate({
            scrollTop: $('#main-content').offset().top
        }, 'slow');

        $('#category').prop("disabled", 'disabled');
        $('#subcategory1').prop("disabled", 'disabled');
        $('#subcategory2').prop("disabled", 'disabled');
        $('#enqsubmitbtn').prop("disabled", 'disabled');
      }
      }

    }


        },error:function(){ 
            //alert("error!!!!");
        }
  });
  }
  }


function getmodel(brand) {
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getmodel')}}",
    data: {brand:brand}, 
    dataType:'JSON', 
    success: function(response){
      
        //alert(response);
        $("#brandmodel").html(response.divhtml);
        
      
    },error:function(){ 
            //alert("error!!!!");
        }
  });
}

function getbrand(brand) {
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getbrand')}}",
    data: {brand:brand}, 
    dataType:'JSON', 
    success: function(response){
      
        //alert(response);
        $("#interest").val(response.divhtml);
        
      
    },error:function(){ 
            //alert("error!!!!");
        }
  });
}

function getapptab(idval){
  //alert("apptab");
    //alert(idval.value);
    var appvalue = idval.value;
    //alert(appvalue);
    var categorytype = $("#category").val();


        if(appvalue == 'Yes' || appvalue == 'No-Details/Intrested'){
        if(appvalue == 'Yes'){
          $("#appointmentDiv").show();
        }
        if(appvalue == 'No-Details/Intrested'){
          $("#appointmentDiv").hide("");
        }
          $("#agentDiv").show();
        if(categorytype == '1' || categorytype == '109'){
          $("#subtype1").show();
          $("#subtype1_x").show();

          $("#subtype2").hide();
          $("#center_id").val("");
          $("#servicecenter").val("");
          $("#advisorname").val("");
          $("#appointmentcode").val("");
        }
        else{
          $("#subtype1").hide();
          $("#subtype1_x").hide();
          $("#showroomid").val("");
          $("#showroom").val("");
          $("#salesman").val("");
          $("#interest").val("");
          $("#appointmenttype").val("");
          $("#appointmentcode1").val("");
          $("#subtype2").show();         
        }
        }
        else{
          $("#appointmentDiv").hide("");
          $("#appointment").val("");

          $("#agentDiv").hide("");
          $("#subtype1").hide();
          $("#subtype1_x").hide();
          $("#showroomid").val("");
          $("#showroom").val("");
          $("#salesman").val("");
          $("#interest").val("");
          $("#appointmenttype").val("");
          $("#appointmentcode1").val("");

          $("#subtype2").hide();  
          $("#center_id").val("");
          $("#servicecenter").val("");
          $("#advisorname").val("");
          $("#appointmentcode").val("");

        }
}

  function checknextquestion() {
  var answer = $("#answer").val();
  var descif = $("#descif").val();
  var description = $("#description").val();
  //alert(answer);
      if(answer != '') {
      if(descif == '1') {
      if(description == '') {
        $("#answertitle").html("Please enter description, this field cannot be empty...");
        $("#answertitle").show();
      }else{
        getnextquestion();
      }
      }else{
        getnextquestion();
      }
      }
      else{
        $("#answertitle").html("Please enter answer, this field cannot be empty...");
        $("#answertitle").show();
      }
  }

  function recyclequestion() {
  var recycif = $("#recycif").val();
  //alert(recycif);
  if(recycif == '0'){
    $('#enqsubmitbtn').prop("disabled", false);
    $("#recycif").val(1);
    $(".refreshbtn").html("Cancel Recycle");       
    $("#recreasons").show(); 
  }
  else{
    $('#enqsubmitbtn').prop("disabled", 'disabled');
    $("#recycif").val(0);
    $(".refreshbtn").html("Recycle"); 
    $("#recreasons").hide();    
  }
  }

  function getnextquestion() {
  $('.se-pre-con').show();
  var questionid = $("#questionid").val();
  var answer = $("#answer").val();
  var question = $("#questionDIV").html();
  var question1 = $("#questionDIV1").html();
  //alert(answer);
  var description = $("#description").val();
  var mobile = $("#phone_number").val();
  var masterid = $("#csimasterid").val();
  var list_id = $("#list_id").val();
  if(list_id == '0'){   
  var user = $("#listid").val();
  }
  else{
  var user = list_id;
  }
  var ctime = $("#current_time").val();
  var id_account = $("#id_account").val();
  var vehid = $("#vehicle_id").val();
  var userinfo = $("#userid").val();
  var fullname = $("#fname").val()+' '+$("#lname").val();
  var vehbrand = $("#vehicleinfo").val();
  var vehmodel = $("#vehmodel").val();
  var dealer = $("#salesman1").val();
  var mileage = $("#mileage").val();
  var vehyear = $("#vehyear").val();
  var regdate = $("#lastservice").val();
  var showroom = $("#showroom1").val();
  var advisor1 = $("#serviceadvisor").val();
  var advisor2 = $("#deliveryadvisor").val();
  var salesman = $("#salesman1").val();

  $("#answertitle").html("");
  $("#answertitle").hide();

  //alert(questionid +"-"+answer+"-"+mobile+"-"+user+"-"+id_account+"-"+vehid+"-"+dealer+"-"+showroom);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getquestion')}}",
    data: {questionid:questionid,question:question,question1:question1, answer:answer, description:description, mobile:mobile, user:user,ctime:ctime, id_account:id_account, vehid:vehid, vehbrand:vehbrand, vehmodel:vehmodel, dealer: dealer,vehyear:vehyear,regdate:regdate, showroom:showroom,userinfo:userinfo,fullname:fullname,mileage:mileage,masterid:masterid,advisor1:advisor1,advisor2:advisor2,salesman:salesman}, 
    dataType:'JSON', 
    success: function(response){

      $('html, body').animate({
            scrollTop: $('#csibox').offset().top
        }, 'slow');
      
        $('#answerbox').show();
        if(response.quesid != '0'){
        $("#questionid").val(0);
        $("#questionid").val(response.quesid);
        $("#questionDIV").html("");
        $("#questionDIV").html(response.question);
        $("#questionDIV1").html("");
        $("#questionDIV1").html(response.question1);
        $("#answerDIV").html("");
        $("#answerDIV").html(response.answer);
        $("#desDIV").html("");
        $("#desDIV").html(response.description);
        $("#prev_answers").html("");
        $("#prev_answers").html(response.previous);
        $("#csimasterid").val(response.masterid);
        $("#descif").val(response.descif);
        $('#nextbtn').show();
        $('#nextbtn').attr("disabled", false);
        $('#prevbtn').show();
        $('#prevbtn').attr("disabled", false);
        }
        else{
        if(response.question != ''){
        $("#questionDIV").html("");
        $("#questionDIV").html(response.question);
        $("#questionDIV1").html("");
        $("#questionDIV1").html(response.question1);
        $("#answerDIV").html("");
        $("#answerDIV").html(response.answer);
        $("#desDIV").html("");
        }
        $('#nextbtn').hide();
        $('#nextbtn').attr("disabled", true);
        $('#prevbtn').hide();
        $('#prevbtn').attr("disabled", true);
        $("#questionid").val(0);
        $("#prev_answers").html("");
        $("#prev_answers").html(response.previous);
        $('#enqsubmitbtn').prop("disabled", false);
        }
        $('.se-pre-con').hide();

        var prevans = response.prevans;
        var anstype = response.anstype;
        if (prevans != "") {

        $("#answer").val(prevans);

        if(anstype == '1' || anstype == '3' || anstype == '15' || anstype == '16' || anstype == '18'){
        $('input.ans_checkbox[value="'+prevans+'"]').prop('checked', true);          
        }
        
        else if(anstype == '4'){
          $(".sclist").removeClass("active");
          $("#sclist_"+prevans).addClass("active");         
        }
        
        else if(anstype == '5' || anstype == '6' || anstype == '9' || anstype == '10' || anstype == '11' || anstype == '12'){
          var prevan=prevans.split(',');     
          var preva='';     
          for (var i = 0; i < prevan.length; i++) {
            //alert(prevan[i]);
            preva = prevan[i];
            $('input.checkans[value="'+preva+'"]').attr('checked', "checked");  
          }    
        }

        }
      
    },error:function(){ 
            //alert("error!!!!");
        $('.se-pre-con').hide();
        }
  });
  }

  function getprevquestion() {
  $('.se-pre-con').show();
  $("#answertitle").html("");
  $("#answertitle").hide();
  var questionid = $("#questionid").val();
  var masterid = $("#csimasterid").val();
  //alert(questionid + "___"+masterid);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getprevquestion')}}",
    data: {questionid:questionid,masterid:masterid}, 
    dataType:'JSON', 
    success: function(response){
      $('html, body').animate({
            scrollTop: $('#csibox').offset().top
        }, 'slow');
      
        if(response.quesid != '0'){
        $('#answerbox').show();
        $('#nextbtn').show();
        $('#nextbtn').attr("disabled", false);
        $('#prevbtn').show();
        $('#prevbtn').attr("disabled", false);
        $("#questionid").val(0);
        $("#questionid").val(response.quesid);
        $("#questionDIV").html("");
        $("#questionDIV").html(response.question);
        $("#questionDIV1").html("");
        $("#questionDIV1").html(response.question1);
        $("#answerDIV").html("");
        $("#answerDIV").html(response.answer);
        $("#desDIV").html("");
        $("#desDIV").html(response.description);
        $("#descif").val(response.descif);
        var prevans = response.prevans;
        var anstype = response.anstype;
        $("#answer").val(prevans);

        if(anstype == '1' || anstype == '3' || anstype == '15' || anstype == '16' || anstype == '18'){
          $('input.ans_checkbox[value="'+prevans+'"]').prop('checked', true);          
        }

        else if(anstype == '4'){
          $(".sclist").removeClass("active");
          $("#sclist_"+prevans).addClass("active");         
        }

        else if(anstype == '5' || anstype == '6' || anstype == '9' || anstype == '10' || anstype == '11' || anstype == '12'){
          var prevan=prevans.split(',');     
          var preva='';     
          for (var i = 0; i < prevan.length; i++) {
            //alert(prevan[i]);
            preva = prevan[i];
            $('input.checkans[value="'+preva+'"]').attr('checked', "checked");  
          }    
        }
        $('#enqsubmitbtn').prop("disabled", 'disabled');

        }
        $('.se-pre-con').hide();
      
    },error:function(){ 
            //alert("error!!!!");
        $('.se-pre-con').hide();
        }
  });
  }


function placeanswer(idval){
  //alert(idval);
  $("#answer").val(idval);
  checknextquestion();
}

function scaleanswer(idval){
  //alert(idval);
  $("#answer").val(idval);

  $(".sclist").removeClass("active");
  $("#sclist_"+idval).addClass("active");
}

function otheranswer(idval){
  $("#answer").val(idval);
  var descr = $("#description").val(); 
  if(descr == '')   {
        $("#answertitle").html("Please enter description, this field cannot be empty...");
        $("#answertitle").show();
  }
  else{
  checknextquestion();
  }
}

function clearbox(){
        $("#questionbox").html("");
}
function selectanswer(){
  //alert(answer.value);
  checknextquestion();
}

function checkanswer(idval){
  var values = [];
  var answers = document.getElementsByName("checkans[]");

  for (var i=0, iLen=answers.length; i<iLen; i++) {
    if (answers[i].checked) {
      values.push(answers[i].value);
    }
  }
  // Do something with values
  //alert("Answers: " + values.join(', '));
  values = values.join(', ');
  var answers2 = values.toString();
  //alert(answers2);
  $("#answer").val(answers2);
  if(answers2 == 'Other  (Please specify)'){
    $("#descif").val("1"); 
  }
  else{
    $("#descif").val("0"); 
  }
}

  function getcsi() {
  var mobile = $("#phone_number").val();
  var list_id = $("#list_id").val();
  if(list_id == '0'){   
  var user = $("#listid").val();
  }
  else{
  var user = list_id;
  }
  var ctime = $("#current_time").val();
  var id_account = $("#id_account").val();
  var vehid = $("#vehicle_id").val();

  var userinfo = $("#userid").val();
  var fullname = $("#fname").val()+' '+$("#lname").val();
  var vehbrand = $("#vehicleinfo").val();
  var vehmodel = $("#vehmodel").val();
  var dealer = $("#salesman1").val();
  var mileage = $("#mileage").val();
  var vehyear = $("#vehyear").val();
  var regdate = $("#lastservice").val();
  var showroom = $("#showroom1").val();
  var advisor1 = $("#serviceadvisor").val();
  var advisor2 = $("#deliveryadvisor").val();
  var salesman = $("#salesman1").val();

  //alert(vehmodel);
  //$('#nextbtn').attr("disabled", true);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getcsi')}}",
    data: {mobile:mobile, user:user,ctime:ctime, id_account:id_account, vehid:vehid, vehbrand:vehbrand, vehmodel:vehmodel, dealer: dealer,vehyear:vehyear,regdate:regdate, showroom:showroom,fullname:fullname,userinfo:userinfo,mileage:mileage,advisor1:advisor1,advisor2:advisor2,salesman:salesman}, 
    dataType:'JSON', 
    success: function(response){
        if(response.question != ''){
        $('#questionbox').show();
        }

        //alert(response.previous);
        //alert(response.quesid);
        if(response.quesid != '0'){
        $("#questionid").val(0);
        $("#questionid").val(response.quesid);
        $("#questionDIV").html("");
        $("#questionDIV").html(response.question);
        $("#questionDIV1").html("");
        $("#questionDIV1").html(response.question1);
        $("#answerDIV").html("");
        $("#answerDIV").html(response.answer);
        $("#desDIV").html("");
        $("#desDIV").html(response.description);
        $("#prev_answers").html("");
        $("#prev_answers").html(response.previous);
        //$("#prev_answers1").html("");
        //$("#prev_answers1").html(response.previous1);
        $('#nextbtn').attr("disabled", false);
        }
        else{
        if(response.question != ''){
        $("#questionDIV").html("");
        $("#questionDIV").html(response.question);
        $("#questionDIV1").html("");
        $("#questionDIV1").html(response.question1);
        $("#answerDIV").html("");
        $("#answerDIV").html(response.answer);
        $("#desDIV").html("");
        }
        $('#nextbtn').hide();
        $('#prevbtn').hide();
        $("#questionid").val(0);
        //$("#questionbox").html("");
        $("#prev_answers").html("");
        $("#prev_answers").html(response.previous);
        //$("#prev_answers1").html("");
        //$("#prev_answers1").html(response.previous1);
        }
        $('.se-pre-con').hide();
      
    },error:function(){ 
            //alert("error!!!!");
        $('.se-pre-con').hide();
        }
  });
  }


  function getsalesman(id) {
  var idval = id.value;
  //alert(idval);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getsalesman')}}",
    data: {idval:idval}, 
    dataType:'JSON', 
    success: function(response){
      
        //alert(response);
        if(response.divhtml != ''){
        $("#showroom").val(0);
        $("#showroom").val(response.showroom);
        $("#salesman").html("");
        $("#salesman").html(response.divhtml);
        }
      
    },error:function(){ 
            //alert("error!!!!");
        }
  });
  }


  function getadvisorname(vehid) {
  var list_id = $("#listid").val();
  var vehmodel = $("#vehmodel").val();
  //alert(list_id+"____"+vehmodel);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getadvisorname')}}",
    data: {vehid:vehid,list_id:list_id,vehmodel:vehmodel}, 
    dataType:'JSON', 
    success: function(response){
      
        //alert(response);
        if(response.OperatorName != ''){
        $("#serviceadvisor").val(response.OperatorName);
        }
        if(response.OperatorName1 != ''){
        $("#deliveryadvisor").val(response.OperatorName1);
        }
          $(".deadvisor").html(response.OperatorName1);
      
    },error:function(){ 
            //alert("error!!!!");
        }
  });
  }

  function getadvisor(id) {
  var idval = id.value;
  //alert(idval);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getadvisor')}}",
    data: {idval:idval}, 
    dataType:'JSON', 
    success: function(response){
      
        //alert(response);
        if(response.divhtml != ''){
        $("#servicecenter").val(0);
        $("#servicecenter").val(response.showroom);
        $("#advisorname").html("");
        $("#advisorname").html(response.divhtml);
        }
      
    },error:function(){ 
            //alert("error!!!!");
        }
  });
  }

  function checkservicecentre(id) { 
    if (id == 'Chevrolet') {
      $('#status_centre').val("");
      $('#status_centre').attr("disabled", false);
    }
    if (id == 'Cadillac') {
      $('#status_centre').val("SO_13");
      $('#status_centre').attr("disabled", true);
    }

  }

  function showvehstatus() {  
  $('#statusdetailsdiv').show();
        $('#statusdetails').html('Waiting...');
  var vehid = $("#vehicle_id").val();
  var brand = $("#status_brand").val();
  var centre = $("#status_centre").val();
  //alert(vehid);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/showvehstatus')}}",
    data: {vehid:vehid,brand:brand,centre:centre}, 
    dataType:'JSON', 
    success: function(response){
        $('#statusdetails').html(response.divhtml);
      
        //alert(response);
        $('.se-pre-con').hide();
      
    },error:function(){ 
            //alert("error!!!!");
        $('.se-pre-con').hide();
        }
  });
  }

  function edit_csi(idval) {
  alert(idval);
  //alert(questionid +"-"+answer+"-"+mobile+"-"+user+"-"+id_account+"-"+vehid+"-"+dealer+"-"+showroom);
  //$('#nextbtn').attr("disabled", true);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/edit_csi')}}",
    data: {idval:idval}, 
    dataType:'JSON', 
    success: function(response){
        $('#questionedit').show();
      
        alert(response);
        if(response.quesid != '0'){
        $("#editquestionid").val(0);
        $("#editquestionid").val(response.quesid);
        $("#questionEDIT").html("");
        $("#questionEDIT").html(response.question);
        $("#answerEDIT").html("");
        $("#answerEDIT").html(response.answer);
        $("#desEDIT").html("");
        $("#desEDIT").html(response.description);
        }
        $('.se-pre-con').hide();
      
    },error:function(){ 
            //alert("error!!!!");
        $('.se-pre-con').hide();
        }
  });
  }


  function editqueston() {
  var idval = $("#editquestionid").val();
  alert(idval);
  var answer = $("#answer").val();
  alert(idval +"-"+answer);
  //$('#nextbtn').attr("disabled", true);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/editqueston')}}",
    data: {idval:idval,answer:answer}, 
    dataType:'JSON', 
    success: function(response){
        $('#questionedit').hide();
      
        //alert(response.previous);
        //alert(response.quesid);
        if(response.question != ''){
        $("#editquestionid").val(0);
        $("#prev_answers").html("");
        $("#prev_answers").html(response.previous);
        }
        $('.se-pre-con').hide();
      
    },error:function(){ 
            //alert("error!!!!");
        $('.se-pre-con').hide();
        }
  });
  }



  </script>
<script type="text/javascript">


function getresponseurl() {
  var newURL = "http://37.34.236.116:1180/alghanim/public/laravel_installation.txt";
   // document.getElementById("txtdocument").setAttribute('data', newURL);
   //beginSaveProduct();
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/gettxtdocument')}}",
    data: {newURL:newURL}, 
    dataType:'JSON', 
    success: function(response){
     // alert(response.txtdoc);
    document.getElementById("txtdocument").setAttribute('data', response.txtdoc);
    $('#myModal').modal();
    },error:function(){ 
            //alert("error!!!!");
        }
  });
}



var productServiceUrl = 'http://172.16.4.16:790/AlghanimAutoline/WCOM?wsdl=GetArchivedDocument'; // Preferably write this out from server side
 
function beginSaveProduct()
{
var soapMessage ='<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dcom="http://172.16.4.16:790/AlghanimAutoline/WCOM"><soapenv:Body><dcom:GetArchivedDocument><dcom:Identification><dcom:SessionId>10000005</dcom:SessionId></dcom:Identification><dcom:LookupCodes> <dcom:RooftopId>TABYAAS01</dcom:RooftopId> <dcom:DocRef>WI03274714</dcom:DocRef> <dcom:Terminal>1021</dcom:Terminal> </dcom:LookupCodes></dcom:GetArchivedDocument></soapenv:Body></soapenv:Envelope>';
 
$.ajax({
url: productServiceUrl,
type: "POST",
dataType: "xml",
data: soapMessage,
complete: endSaveProduct,
contentType: "text/xml; charset=\"utf-8\""
});
 
return false;
}
 
function endSaveProduct(xmlHttpRequest, status)
{
 $(xmlHttpRequest.responseXML)
    .find('SaveProductResult')
    .each(function()
 {
   var name = $(this).find('Name').text();
 });
}

</script>
  </body>

</html>