<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
use App\VicidialLog;
use App\VicidialCloserLog;
use App\VicidialDialLog;
use App\VicidialList;
use App\VicidialLists;
use App\VicidialCampaign;
use App\VicidialAgentLog; 
use Illuminate\Support\Facades\Input; //header
use Excel;
use App\Average;
use App\MKtargt;
use App\MKhisty;
use App\MKvlink;
use App\MKvehic;
use App\MKnewst;
use App\VicidialAutoCalls;
use App\VicidialLiveAgent;
use Carbon\Carbon;

class OthersController extends Controller
{


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function inquiries(Request $request)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
            $fromdate = date("Y-m-d");
            $todate = date("Y-m-d");
            $appbooked = '';
            $categoryy = '';
            $list_id = '';
            $categoryyname = '';
            $categoryyname1 = '';
            $categoryyname2 = '';
            $categoryyname3 = '';
            $subcategory1 = '';
            $subcategory2 = '';
            $subcategory3 = '';
            $apptab = '';
            $source_name = '';
            $showroom = '';
            $salesman = '';
            $brand = '';
            $interest = '';
            $appointmenttype = '';
            $servicecenter = '';
            $advisorname = '';
            $appointmentcode = '';
        $campaignids = Session::get('campaignid');

        //print_r($request->all()); echo "<br><br>";
        if(!empty($request->fromdate)){
            $fromdate = date('Y-m-d', strtotime($request->fromdate));
        }
        if(!empty($request->todate)){
            $todate = date('Y-m-d', strtotime($request->todate));
        }
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));
            
        $list_ids = VicidialLists::select('list_id','list_name','campaign_id')->get();

        if($request->apptab == 'Yes' || $request->apptab == 'No-Details/Intrested'){
        $inquiries = DB::table('opportunity')->join('appointments', 'opportunity.id_opp', '=', 'appointments.opp_id')->select('opportunity.*','appointments.brand','appointments.interest','appointments.source_name','appointments.showroom','appointments.appointmenttype','appointments.servicecenter','appointments.advisorname','appointments.appointmentcode')->whereBetween('opportunity.date_add',[$fromdate, $todate1]);
        }
        else{
        $inquiries = DB::table('opportunity')->whereBetween('date_add',[$fromdate, $todate1]);            
        }
        //print_r($inquiries); exit();

        if(!empty($campaignids)){
            $inquiries = $inquiries->whereIn('opportunity.campaign_id',explode(",", $campaignids));
        }
        if(!empty($request->list_id)){
            $list_id = $request->list_id;
            $inquiries = $inquiries->where('id_list',$list_id);
        }
        if(!empty($request->appbooked)){
            $appbooked = $request->appbooked;
            $inquiries = $inquiries->where('appointment_booked',$appbooked);
        }
        if(!empty($request->category)){
            $categoryy = $request->category;
            $category_yname = DB::table('enquiry_categories')->select('category_name')->where('id_enquiry_category',$categoryy)->first();
            $categoryyname=$category_yname->category_name;
            $inquiries = $inquiries->where('enquiry_category',$categoryy);
        }
        if(!empty($request->subcategory1)){
            $subcategory1 = $request->subcategory1;
            $category_yname1 = DB::table('enquiry_categories')->select('category_name')->where('id_enquiry_category',$subcategory1)->first();
            $categoryyname1=$category_yname1->category_name;
            $inquiries = $inquiries->where('enquiry_subcategory',$subcategory1);
        }
        if(!empty($request->subcategory2)){
            $subcategory2 = $request->subcategory2;
            $category_yname2 = DB::table('enquiry_categories')->select('category_name')->where('id_enquiry_category',$subcategory2)->first();
            $categoryyname2=$category_yname2->category_name;
            $inquiries = $inquiries->where('enquiry_subcategory2',$subcategory2);
        }
        if(!empty($request->subcategory3)){
            $subcategory3 = $request->subcategory3;
            $category_yname3 = DB::table('enquiry_categories')->select('category_name')->where('id_enquiry_category',$subcategory3)->first();
            $categoryyname3=$category_yname3->category_name;
            $inquiries = $inquiries->where('enquiry_subcategory3',$subcategory3);
        }

        if($request->apptab == 'Yes' || $request->apptab == 'No-Details/Intrested'){
            $apptab = $request->apptab;
            if($request->category == '1' || $request->category == '109'){
            $appointmentcode = $request->appointmentcode1;                
            }
            else{
            $appointmentcode = $request->appointmentcode;                
            }
        if(!empty($request->source_name)){
            $source_name = $request->source_name;
            $inquiries = $inquiries->where('source_name',$source_name);
        }
        if(!empty($request->showroom)){
            $showroom = $request->showroom;
            $inquiries = $inquiries->where('showroom',$showroom);
        }
        if(!empty($request->salesman)){
            $salesman = $request->salesman;
            $inquiries = $inquiries->where('salesman',$salesman);
        }
        if(!empty($request->interest)){
            $brand = $request->interest;  
            $inquiries = $inquiries->where('brand',$brand);
        }
        if(!empty($request->brandmodel)){
                $interest = $request->brandmodel;    
            $inquiries = $inquiries->where('interest',$interest);
        }
        if(!empty($request->appointmenttype)){
            $appointmenttype = $request->appointmenttype;
            $inquiries = $inquiries->where('appointmenttype',$appointmenttype);
        }
        if(!empty($request->servicecenter)){
            $servicecenter = $request->servicecenter;
            $inquiries = $inquiries->where('servicecenter',$servicecenter);
        }
        if(!empty($request->advisorname)){
            $advisorname = $request->advisorname;
            $inquiries = $inquiries->where('advisorname',$advisorname);
        }
        if(!empty($appointmentcode)){
            $inquiries = $inquiries->where('appointmentcode',$appointmentcode);
        }

        }
        $inquiries = $inquiries->orderBy('id_opp','desc')->get();
        //print_r($inquiries); exit();



        if($request->exportstatus == '1'){
        $exports = array();
            foreach ($inquiries as $app) {
                    $enq_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$app->enquiry_category)->first();
                    $enq_sub_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$app->enquiry_subcategory)->first();
                    $enq_category = '';
                    $enq_subcategory = '';
                    $enq_subcategory2 = '';
                    $enq_subcategory3 = '';

                     if(!empty($app->enquiry_subcategory2) || $app->enquiry_subcategory2 == '0'){

                     $enq_sub_cat2 = DB::table('enquiry_categories')->where('id_enquiry_category',$app->enquiry_subcategory2)->first();

                    if(count($enq_sub_cat2) > 0){
                      $enq_subcategory2 = ", ".$enq_sub_cat2->category_name;
                    }

                    }

                    if(!empty($app->enquiry_subcategory3) || $app->enquiry_subcategory3 == '0'){

                     $enq_sub_cat3 = DB::table('enquiry_categories')->where('id_enquiry_category',$app->enquiry_subcategory3)->first();

                    if(count($enq_sub_cat3) > 0){
                      $enq_subcategory3 = ", ".$enq_sub_cat3->category_name;
                    }
                     }
                    if(count($enq_cat) > 0){
                      $enq_category = $enq_cat->category_name;
                    }
                    if(count($enq_sub_cat) > 0){
                      $enq_subcategory = $enq_sub_cat->category_name;
                    }

                               
                    $listnames = VicidialLists::select('list_name')->where('list_id',$app->id_list)->get();
                    $listname =  '';
                    $listid =  $app->id_list;
                    if(count($listnames) > 0){
                        
                        if($listid == '999'){
                            $listname =  ' Incoming';
                        }
                        else{
                            $listname =  ' Outgoing - '.$listnames[0]->list_name;
                        }
                    } 

                            $brand = '';
                            $interest = '';
                            $showroom = '';
                            $salesman = '';
                            $servicecenter = '';
                            $advisorname = '';
                            $source = '';
                            $appdate = '';
                            $apptime = '';
                            $apptype = '';
                            $appcode = '';
                        if($app->appointment_booked =='Yes' || $app->appointment_booked == 'No-Details/Intrested'){
                          $appdetail = DB::table('appointments')->where('opp_id',$app->id_opp)->first();
                        if($appdetail){
                            $brand = $appdetail->brand;
                            $interest = $appdetail->interest;
                            $showroom = $appdetail->showroom;
                            $salesman = $appdetail->salesman;
                            $servicecenter = $appdetail->servicecenter;
                            $advisorname = $appdetail->advisorname;
                            $source = $appdetail->source_name;
                            $appdate = $appdetail->appointment_date;
                            $apptime = $appdetail->appointment_time;
                            $apptype = $appdetail->appointmenttype;
                            $appcode = $appdetail->appointmentcode;
                        }
                        }

            $exports[] = array('#' => $app->id_opp,'Name' => $app->first_name." ".$app->last_name,'Mobile Number' => $app->mobile_number,'Call Type' => $listname,'Id Agent' => $app->id_agent,'Categories' => $enq_category,'Sub Category' => $enq_subcategory." ".$enq_subcategory2." ".$enq_subcategory3,'Description' => $app->description,'Campaign' => $app->campaign_id,'Date Added' => $app->date_add,'Appointment Booked' => $app->appointment_booked,'Source of Business' => $source,'Brand' => $brand,'Model' => $interest,'Showroom' => $showroom,'Salesman' => $salesman,'Service Center' => $servicecenter,'Advisor Name' => $advisorname,'Appointment Date' => $appdate,'Appointment Time' => $apptime,'Appointment Type' => $apptype,'Appointment Code' => $appcode );
            }

        //print_r($exports); exit();
            $type = 'xlsx';

            $data = array();
            foreach ($exports as $result) {
            $data[] = (array)$result; 
            }
                Excel::create('Inquiries Details', function($excel) use($data) {

                $excel->sheet('Sheetname', function($sheet) use($data) {

                $sheet->fromArray($data);

                  });

                })->export('xlsx');

        }


        return view('inquiries',compact('inquiries','fromdate','todate','list_ids','appbooked','categoryyname','categoryyname1','categoryyname2','categoryyname3','list_id','categoryy','subcategory1','subcategory2','subcategory3','apptab','source_name','showroom','salesman','brand','interest','appointmenttype','servicecenter','advisorname','appointmentcode'));
    }


    public function viewinquiry($id)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $inquiry = DB::table('opportunity')->where('id_opp',$id)->first();
        //print_r($inquiries); exit();

        return view('inquiry',compact('inquiry','fromdate'));
    }

    public function appointments(Request $request)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
       // echo $mobile;

            $fromdate = date("Y-m-d");
        $campaignids = Session::get('campaignid');

        //print_r($mobiles); exit();
        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));

        $appointments = DB::table('appointments')->whereBetween('appointment_date',[$fromdate, $todate1]);
        }
        else{
           $appointments = DB::table('appointments'); 
        }

        if(!empty($campaignids)){
            $appointments = $appointments->whereIn('campaign_id',explode(",", $campaignids));
        }
        $appointments = $appointments->orderBy('id','desc')->paginate(100);
    

        return view('appointments',compact('appointments','fromdate'));
    }


    public function vuseranswers($id)
    {
       // echo $mobile;


        $csi_master = DB::table('csi_master')->where('id',$id)->get();

        $questions = DB::table('csi_answers')->where('master_id',$id)->orderBy('id','asc')->get(); 

            $vehicles = MKvehic::select('magic','regno','model','modelvar')->where('magic',$csi_master[0]->vehmagic)->get();
            $vehdetails = '';
            if(count($vehicles) > 0){
                $vehdetails = $vehicles[0]->model.' - '. $vehicles[0]->modelvar.' - '. $vehicles[0]->regno;
            }


        $listnames = VicidialLists::select('list_name')->where('list_id',$csi_master[0]->list_id)->get();
        $listname =  'ListName';
        if(count($listnames) > 0){
           $listname =  $listnames[0]->list_name;
        }

        return view('viewanswers',compact('questions','vehdetails','csi_master','listname'));
    }

    public function useranswers(Request $request)
    {
            $phone = '';
            $list_id = '';
            $excname = '';
            $ingroupids = '';
            $camp_id = '';
            $checklist = '';


            $fromdate = date("Y-m-d");
            $todate = date("Y-m-d");

        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts1 = explode('-',$todate);
            $todate = $parts1[2] . '-' . $parts1[0] . '-' . $parts1[1];
        }
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));

        $campaignids = Session::get('campaignid');

        $campaigns = VicidialCampaign::select('campaign_id','campaign_name');
        if(!empty($campaignids)){
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
        }
        $campaigns = $campaigns->orderBy('campaign_name','asc')->get();


        $list_ids = VicidialLists::select('list_id','list_name','campaign_id')->orderBy('list_name','asc')->get(); 
        $mobiles = DB::table('csi_master')->whereBetween('date_time',[$fromdate, $todate1]);

        if(!empty($request->phone)){
            $phone = $request->phone;
            $mobiles = $mobiles->where('mobile',$phone);
        }

        if(!empty($request->campaignid)){

            $camp_id = $request->campaignid;

            $list_ids = VicidialLists::select('list_id','list_name','campaign_id')->where('campaign_id',$camp_id)->get();
            if(count($list_ids) > 0) {
            $checklist = $list_ids[0]->list_id;
                foreach ($list_ids as $ing) {
                    $ingrps[] = $ing->list_id;
                }
            $ingroupids = implode(",", $ingrps);
            }

            if(!empty($request->list_id)){
                $list_id = $request->list_id;
                $checklist = $request->list_id;
                $mobiles = $mobiles->where('list_id',$list_id);
            }
            else{
                $mobiles = $mobiles->whereIn('list_id',explode(",", $ingroupids));
            }

        }

        else if(!empty($request->list_id)){
            $list_id = $request->list_id;
            $checklist = $request->list_id;
            $mobiles = $mobiles->where('list_id',$list_id);
        }
            $mobiles = $mobiles->get();
        //print_r($mobiles); exit();

        $exports = array();
        $quests = array();
            $overall = array();
        $type = 'csv';
                $vehmodel = '';
                $vehchasis = '';
                $regno = '';
                $cname = '';
                $wipno = '';
                $showroom = '';
                $salesman = '';

            if ($checklist >= 4000 && $checklist <= 4008) {
            $list_id1 = 1004;
            }
            else if ($checklist >= 3001 && $checklist <= 3017) {
            $list_id1 = 1004;
            }
            else if ($checklist == 2003 || $checklist == 2004) {
            $list_id1 = 1004;
            }
            else if ($checklist >= 5000 && $checklist <= 5003) {
            $list_id1 = 1009;
            }
            else if ($checklist >= 8000 && $checklist <= 8009) {
            $list_id1 = 1009;
            }
            else if ($checklist >= 5004 && $checklist <= 5007) {
            $list_id1 = 10091;
            }
            else if ($checklist >= 9001 && $checklist <= 9006) {
            $list_id1 = 10091;
            }
            else if ($checklist == 5008 || $checklist == 5009 || $checklist == 2007 || $checklist == 2008) {
            $list_id1 = 1008;
            }
            else{
            $list_id1 = '';
            }

        if($request->exportstatus == '1' && !empty($list_id1)){

        foreach ($mobiles as $mobile) {

        $vehicles = MKvehic::select('magic','regno','model','chassis')->where('magic',$mobile->vehmagic)->first();
        $mktargt = MKtargt::select('magic','firstnam','surname','phone','phone002','phone004','phone001','phone003')->where('magic',$mobile->id_account)->first();

        $vehhisty = MKhisty::where('prime',$mobile->vehmagic)->where('tarmagic',$mobile->id_account)->orderBy('DATE','desc')->first();

        $newst = MKnewst::select('vehmagic','exec','exec001','selllocn','invdate','regn','desc001','deldate','model')->where('vehmagic',$mobile->vehmagic)->first();

                $serviceadvisor = $mobile->serviceadvisor;
                $listnames1 = VicidialLists::select('list_name')->where('list_id',$mobile->list_id)->first();
                $listname1 =  '';
                if($listnames1){
                    $serviceadvisor = $listnames1->list_name;
                } 
  
                $deliveryadvisor = $mobile->deliveryadvisor; 
                $salesman = $mobile->salesman; 

                if($vehicles){
                    $vehmodel = $vehicles->model;
                    $vehchasis = $vehicles->chassis;
                    $regno = $vehicles->regno;
                    $regno = $vehicles->regno;
                    $company = $vehicles->chassis;
                }
                if($mktargt){
                    $cname = $mktargt->firstnam.' '.$mktargt->surname;
                }
                if($vehhisty){
                    $wipno = $vehhisty->wipno;
                }
                if($newst){
                    $showroom = $newst->selllocn;
                    $salesman = $newst->exec.' ,'. $newst->exec001;
                }



        for ($i=1; $i <=20 ; $i++) { 
            ${"quess" . $i} = '';
            ${"anss" . $i} = '';
        }
        $reason5 = '';
        $reason4 = '';
        $notes = '';
        $reasonpurchase = '';
        $hearus = '';


        $tquestions = DB::table('csi_questions')->where('listid',$list_id1)->where('extract_order','>','0')->orderBy('extract_order','asc')->get(); 

        $qi = 1;
        foreach ($tquestions as $ques) {

            ${"quess" . $qi} = $ques->qtype;
            $answer = DB::table('csi_answers')->where('master_id',$mobile->id)->where('question_id',$ques->id)->orderBy('id','asc')->first();
            if ($answer) {
                if($ques->anstype == '3'){
                    if ($answer->answer == '5') {
                        ${"anss" . $qi} = 100;
                    }
                    else if ($answer->answer == '4') {
                        ${"anss" . $qi} = 75;
                    }
                    else if ($answer->answer == '3') {
                        ${"anss" . $qi} = 50;
                    }
                    else if ($answer->answer == '2') {
                        ${"anss" . $qi} = 25;
                    }
                    else{
                        ${"anss" . $qi} = "0";
                    }

                }
                else if($ques->anstype == '4'){
                ${"anss" . $qi} = $answer->answer*10;

                }
                else if($ques->anstype == '1' || $ques->anstype == '16'){
                    if ($answer->answer == 'Yes') {
                        ${"anss" . $qi} = 100;
                    }
                    else{
                        ${"anss" . $qi} = "0";
                    }

                }
                else{
                ${"anss" . $qi} = $answer->answer;

                }
            }
            $qi++;
        }

 
        if ($list_id1 == '1004') {

            $excname = 'SSS Extract_Service CSI';

                $q1reason = "";
                $q11reason = "";
                $q12reason = "";
            $answer = DB::table('csi_answers')->select('description')->where('master_id',$mobile->id)->where('question_id','4')->first();
            if ($answer) {
                $q1reason = $answer->description;
            }
            $answer = DB::table('csi_answers')->select('description')->where('master_id',$mobile->id)->where('question_id','20')->first();
            if ($answer) {
                $q11reason = $answer->description;
            }
            $answer = DB::table('csi_answers')->select('description')->where('master_id',$mobile->id)->where('question_id','21')->first();
            if ($answer) {
                $q12reason = $answer->description;
            }

         if(!empty($anss1) && !empty($anss2)) {
            $exports[] = array(
                'Primary' => $mobile->vehmagic,
                'AgentName' => $mobile->agent_id,
                'Target' => $mobile->id_account,
                'Company' => $company,
                'WIPNO' => $wipno,
                'ServAdv' => $serviceadvisor,
                'ServAdv Name' => $serviceadvisor,
                'Team' => '',
                'Type' => '',
                'DSA' => '',
                'Model' => $vehmodel,
                'CALLDATE' => date("d/m/Y",strtotime($mobile->date_time)),
                'Chassis' => $vehchasis,
                'Telephone' => $mobile->mobile,
                'CustomerName' => $cname,
                'Consent' => 'Y',
                $quess1 => $anss1,$quess2 => $anss2,$quess3 => $anss3,$quess4 => $anss4,$quess5 => $anss5,$quess6 => $anss6,$quess7 => $anss7,$quess8 => $anss8,$quess9 => $anss9,$quess10 => $anss10,$quess11 => $anss11,$quess12 => $anss12,$quess13 => $anss13,$quess14 => $anss14,$quess15 => $anss15,$quess16 => $anss16,$quess17 => $anss17,'Notes For "Q1"' => $q1reason,'Notes For "Q11"' => $q11reason,'Notes For "Q12"' => $q12reason
            );
        }
            
        }
 
        else if ($list_id1 == '1008') {

            $excname = 'PDSS Extract_Sales CSI';
                $q1reason = "";
                $q6reason = "";
                $q7reason = "";
            $answer = DB::table('csi_answers')->select('description')->where('master_id',$mobile->id)->where('question_id','25')->first();
            if ($answer) {
                $q1reason = $answer->description;
            }
            $answer = DB::table('csi_answers')->select('description')->where('master_id',$mobile->id)->where('question_id','36')->first();
            if ($answer) {
                $q6reason = $answer->description;
            }
            $answer = DB::table('csi_answers')->select('description')->where('master_id',$mobile->id)->where('question_id','37')->first();
            if ($answer) {
                $q7reason = $answer->description;
            }

         if(!empty($anss1) && !empty($anss2)) {
            $exports[] = array(
                'Primary' => $mobile->vehmagic,
                'SalesExec' => $mobile->agent_id,
                'UserName' => $mobile->agent_id,
                'AgentName' => $mobile->agent_id,
                'Magic' => $mobile->id_account,
                'Franchise' => $company,
                'ModelCode' => $vehmodel,
                'Telephone' => $mobile->mobile,
                'CustomerName' => $cname,
                'CALLDATE' => date("d/m/Y",strtotime($mobile->date_time)),
                'Showroom Locn' => $showroom,
                'Chassis' => $vehchasis,
                'Consent' => 'Y',
                $quess1 => $anss1,$quess2 => $anss2,$quess3 => $anss3,$quess4 => $anss4,$quess5 => $anss5,$quess6 => $anss6,$quess7 => $anss7,$quess8 => $anss8,$quess9 => $anss9,$quess10 => $anss10,$quess11 => $anss11,$quess12 => $anss12,$quess13 => $anss13,$quess14 => $anss14,$quess15 => $anss15,'Notes For "Q1"' => $q1reason,'Notes For "Q6"' => $q6reason,'Notes For "Q7"' => $q7reason
            );
        }
            
        }

        else if ($list_id1 == '1009' || $list_id1 == '10091') {

                $q1reason = "";
                $suggestion = "";
            if ($list_id1 == '1009') {
            $excname = 'BTB Extract_Quick_service CSI';
            $answer = DB::table('csi_answers')->select('description')->where('master_id',$mobile->id)->where('question_id','43')->first();
            if ($answer) {
                $q1reason = $answer->description;
            }
            $answer = DB::table('csi_answers')->select('description')->where('master_id',$mobile->id)->where('question_id','58')->first();
            if ($answer) {
                $suggestion = $answer->description;
            }
            }
            else if ($list_id1 == '10091') {
            $excname = 'BTB Extract_Quick_Lube CSI';
            $answer = DB::table('csi_answers')->select('description')->where('master_id',$mobile->id)->where('question_id','63')->first();
            if ($answer) {
                $q1reason = $answer->description;
            }
            $answer = DB::table('csi_answers')->select('description')->where('master_id',$mobile->id)->where('question_id','78')->first();
            if ($answer) {
                $suggestion = $answer->description;
            }
            }

         if(!empty($anss1) && !empty($anss2)) {
            $exports[] = array(
                'Primary' => $mobile->vehmagic,
                'AgentName' => $mobile->agent_id,
                'Target' => $mobile->id_account,
                'Service/Lubes' => $company,
                'Company' => $company,
                'WIPNO' => $wipno,
                'ServAdv' => $serviceadvisor,
                'ServAdv Name' => $serviceadvisor,
                'Team' => '',
                'Type' => '',
                'DSA' => '',
                'Model' => $vehmodel,
                'CALLDATE' => date("d/m/Y",strtotime($mobile->date_time)),
                'Chassis' => $vehchasis,
                'Telephone' => $mobile->mobile,
                'CustomerName' => $cname,
                'Consent' => 'Y',
                $quess1 => $anss1,$quess2 => $anss2,$quess3 => $anss3,$quess4 => $anss4,$quess5 => $anss5,$quess6 => $anss6,$quess7 => $anss7,$quess8 => $anss8,$quess9 => $anss9,$quess10 => $anss10,$quess11 => $anss11,$quess12 => $anss12,'Suggestion' => $suggestion,$quess13 => $anss13,$quess14 => $anss14,$quess15 => $anss15,'Notes For "Q1"' => $q1reason
            );
        }

        }
        
        else{

            $exports[] = array(
                'Agent Name' => $mobile->agent_id,
                'ServAdv Name' => '',
                'Model' => $vehmodel,
                'CALLDATE' => date("d/m/Y",strtotime($mobile->date_time)),
                'Chassis' => $vehchasis,
                'Telephone' => $mobile->mobile,
                'CustomerName' => $cname,
                'Consent' => 'Y',
                $quess1 => $anss1,$quess2 => $anss2,$quess3 => $anss3,$quess4 => $anss4,$quess5 => $anss5,$quess6 => $anss6,$quess7 => $anss7,$quess8 => $anss8,$quess9 => $anss9,$quess10 => $anss10,$quess11 => $anss11,$quess12 => $anss12,$quess13 => $anss13,$quess14 => $anss14,$quess15 => $anss15,$quess16 => $anss16,$quess17 => $anss17,$quess18 => $anss18,$quess19 => $anss19,$quess20 => $anss20
            );

        }
        }

        //print_r($excname); exit();

            $data = array();
            $excname = $excname.'_'.$list_id.'_'.$fromdate;
            foreach ($exports as $result) {
            $data[] = (array)$result; 
            }


                Excel::create($excname, function($excel) use($data) {

                $excel->sheet('Sheetname', function($sheet) use($data) {

                $sheet->fromArray($data);

                  });

                })->export('xlsx');

        }

        return view('useranswers',compact('mobiles','phone','fromdate','todate','campaigns','list_ids','list_id','camp_id'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function auto_dial()
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }

        $lists = VicidialLists::select('list_id','list_name','campaign_id')->get();
        //print_r($lists); exit();
        $campaignids = Session::get('campaignid');
        $campaigns = VicidialCampaign::select('campaign_id','campaign_name');
        if(!empty($campaignids)){
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
        }
        $campaigns = $campaigns->orderBy('campaign_name','asc')->get();
        
        // print_r($inbounds); exit();
        return view('auto_dial',compact('lists','campaigns'));
    }

    public function auto_dial1()
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }

        $lists = VicidialLists::select('list_id','list_name','campaign_id')->get();
        //print_r($lists); exit();
        $campaignids = Session::get('campaignid');
        $campaigns = VicidialCampaign::select('campaign_id','campaign_name');
        if(!empty($campaignids)){
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
        }
        $campaigns = $campaigns->orderBy('campaign_name','asc')->get();
        
        // print_r($inbounds); exit();
        return view('auto_dial1',compact('lists','campaigns'));
    }

    public function upload(Request $request)
    {

        header('Content-Type: text/html; charset=utf-8');
        //print_r($request->all()); exit();
        //$rUrl = 'https://chevrolet-autoline-prod-api.alghanim-prod-ase.p.azurewebsites.net/contact/getdetails?script=GSP';

        $rec_count = 0;
        $added = 0;
        $notadded = 0;
        $regno = '';
        $phone = '';
        $clnnumber = '';
        $vehmagic = '';
        $tarmagic = '';
        $clncode = $request->clnnumber;
        if(empty($request->import_file)){
        if(!empty($request->getdetails)){
        $data = json_decode($request->getdetails, true);

        //print_r(count($data['data'])); exit();
        if(count($data['data'])) {
        $datadetails = $data['data']['CLHDR'];
        foreach ($datadetails as $data1) {

            $clnnumber = $data1['CLNUMBER'];
            $datadetails1 = $data1['CLIST'];
            $rec_count = count($datadetails1);

        if(!empty($clncode)){

            $clncodes =  strpos($clncode,$clnnumber);  

            if($rec_count > 0) {
            if(is_numeric($clncodes)) {
            foreach ($datadetails1 as $data2) {
            // Output a row
            $tarmagic = $data2['TARMAGIC'];
            $vehmagic = $data2['VEHMAGIC'];  
            // print_r($data2['TARMAGIC']);
            // echo "<br>========================================================<br>";

            $mktargt = MKtargt::select('magic','firstnam','surname','phone','phone002','phone004','phone001','phone003')->where('magic',$tarmagic)->first();

            $vehicle = MKvehic::select('magic','regno','chassis')->where('magic',$vehmagic)->first();
            if($vehicle){
                    $regno = $vehicle->chassis; 
            }

            if($mktargt){
                //echo $mktargt->FIRSTNAM;
                if(!empty($mktargt->phone004)){
                    $phone = $mktargt->phone004;
                }
                else if(!empty($mktargt->phone002)){
                    $phone = $mktargt->phone002;

                }
                else if(!empty($mktargt->phone003)){
                    $phone = $mktargt->phone003;

                }
                else if(!empty($mktargt->phone001)){
                    $phone = $mktargt->phone001;

                }
                else{
                    $phone = $mktargt->phone;

                }

                $phone = preg_replace("/[^0-9]{1,4}/", '', $phone);

                $phone = substr($phone, 0, 8);
                if(!empty($phone)){
                    $added++;
                $lists = VicidialList::insert(['phone_number' => $phone,'first_name' => $mktargt->firstnam.' '.$mktargt->surname,'list_id' => $request->listid,'entry_date' => date("Y-m-d H:i:s"),'status'=>'NEW','called_since_last_reset'=>'N','vendor_lead_code' => $regno,'source_id' => $clnnumber,'batchno'=>$request->batchno]);
                //echo 'phone_number => '.$phone.'   first_name =>  '.$mktargt->FIRSTNAM.' '.$mktargt->SURNAME;
                }
                else{
                $notadded++;
                DB::table('remaining_lists')->insert(['tarmagic' => $tarmagic,'list_id' => $request->listid,'entry_date' => date("Y-m-d H:i:s"),'vendor_lead_code' => $regno,'source_id' => $clnnumber,'phone' => $phone,'vehmagic' => $vehmagic]);
                }

            }
            else{
                $notadded++;
                DB::table('remaining_lists')->insert(['tarmagic' => $tarmagic,'list_id' => $request->listid,'entry_date' => date("Y-m-d H:i:s"),'vendor_lead_code' => $regno,'source_id' => $clnnumber,'phone' => $phone,'vehmagic' => $vehmagic]);
            }
            //echo "<br>========================================================<br>";

            }
            }
            }
        }
        else{

            if($rec_count > 0) {
            foreach ($datadetails1 as $data2) {
            // Output a row
            $tarmagic = $data2['TARMAGIC'];
            $vehmagic = $data2['VEHMAGIC'];
            // print_r($data2['TARMAGIC']);
            // echo "<br>========================================================<br>";

            $mktargt = MKtargt::select('magic','firstnam','surname','phone','phone002','phone004','phone001','phone003')->where('magic',$tarmagic)->first();

            $vehicle = MKvehic::select('magic','regno','chassis')->where('magic',$vehmagic)->first();
            if($vehicle){
                    $regno = $vehicle->chassis;
            }

            if($mktargt){
                //echo $mktargt->FIRSTNAM;
                if(!empty($mktargt->phone004)){
                    $phone = $mktargt->phone004;
                }
                else if(!empty($mktargt->phone002)){
                    $phone = $mktargt->phone002;

                }
                else if(!empty($mktargt->phone003)){
                    $phone = $mktargt->phone003;

                }
                else if(!empty($mktargt->phone001)){
                    $phone = $mktargt->phone001;

                }
                else{
                    $phone = $mktargt->phone;

                }

                $phone = preg_replace("/[^0-9]{1,4}/", '', $phone);

                $phone = substr($phone, 0, 8);
                if(!empty($phone)){
                    $added++;
                $lists = VicidialList::insert(['phone_number' => $phone,'first_name' => $mktargt->firstnam.' '.$mktargt->surname,'list_id' => $request->listid,'entry_date' => date("Y-m-d H:i:s"),'status'=>'NEW','called_since_last_reset'=>'N','vendor_lead_code' => $regno,'source_id' => $clnnumber,'batchno'=>$request->batchno]);
                //echo 'phone_number => '.$phone.'   first_name =>  '.$mktargt->FIRSTNAM.' '.$mktargt->SURNAME;
                }
                else{
                $notadded++;
                DB::table('remaining_lists')->insert(['tarmagic' => $tarmagic,'list_id' => $request->listid,'entry_date' => date("Y-m-d H:i:s"),'vendor_lead_code' => $regno,'source_id' => $clnnumber,'phone' => $phone,'vehmagic' => $vehmagic]);
                }

            }
            else{
                $notadded++;
                DB::table('remaining_lists')->insert(['tarmagic' => $tarmagic,'list_id' => $request->listid,'entry_date' => date("Y-m-d H:i:s"),'vendor_lead_code' => $regno,'source_id' => $clnnumber,'phone' => $phone,'vehmagic' => $vehmagic]);
            }
            //echo "<br>========================================================<br>";

            }
            }

        }
        }
        }
        }
        if ($added == '0') {
            $alert = "<strong>Warning!</strong> No Records Added";
        }
        else{
            $alert = "<strong>Success!</strong> ".$added." Records Added Successfully <br><strong>Warning!</strong> ".$notadded." Not Added ";
        }
        
        }
        else{


        $path = $request->file('import_file')->getRealPath();

        $data = Excel::load($path)->get();
        
        $headerRow = $data->first()->keys()->toArray();
        $listid = $request->listid;
        //$listid = '1005';

        //print_r($headerRow); exit();


        if($data->count()){

            $rec_count = 0;

            foreach ($data as $key => $value) {

            //print_r($value);
            if(!empty($value->tel)){
            $lists = VicidialList::insert(['alt_lead_id' => $value->lead_id, 'Year' => $value->year, 'Sourceoflead' => $value->source_of_lead, 'Enquiry_type' => $value->enquiry_type, 'Source_of_business' => $value->source_of_business, 'Siebel' => $value->siebel_sob, 'Month' => $value->month, 'Allocation_date' => $value->allocation_date, 'Allocation_time' => $value->allocation_time, 'first_name' => $value->customer_name, 'phone_number' => $value->tel, 'cc_agent' => $value->cc_agent, 'email' => $value->email, 'modelofinterest' => $value->model_of_interest, 'callcentre_feedback' => $value->call_centre_feedback, 'appointment' => $value->appointment, 'showroom' => $value->showroom, 'sale_consultant' => $value->sales_consultant, 'test_appointment' => $value->test_drive_appointment, 'month_sent' => $value->month_sent, 'salesman_feedback' => $value->salesman_feedback, 'Visited' => $value->visited, 'Date' => $value->date, 'showup_enquiry' => $value->salesman_showup_enquiry, 'sold' => $value->sold_date, 'carmodel_conversion' => $value->car_model_conversion ,'list_id' => $listid,'entry_date' => date("Y-m-d H:i:s"),'status'=>'NEW','called_since_last_reset'=>'N','batchno'=>$request->batchno,'vendor_lead_code' => $value->model_of_interest,'vendor_lead_code' => $value->model_of_interest]);
            $rec_count++;
            }


                // /print_r($data);
            }
            $alert = $rec_count." Records Added Successfully";
            //exit();
        }

        }

        if (!empty($request->batchno)) {

        VicidialList::where('list_id',$request->listid)->where('status','NEW')->where('batchno','!=',$request->batchno)->update(['status'=>'DA']);
        DB::table('target_batches')->where('list_id',$request->listid)->update(['active'=>'N']);
        
        $checkid =  DB::table('target_batches')->where('list_id',$request->listid)->where('batchno',$request->batchno)->first();
        if($checkid){
        $batchid = $checkid->id;
        $remaining = $request->batchtarget - $checkid->achieved;
        $achieved = $request->batchtarget - $remaining;
            DB::table('target_batches')->where('list_id',$request->listid)->where('batchno',$request->batchno)->update(['totaltarget'=>$request->batchtarget,'achieved'=>$achieved,'remaining'=>$remaining,'active'=>'Y']);
        $description = $request->batchno.' '.'batch target updated with '.$request->batchtarget.' target(s)';
        }      
        else{   
        $remaining = $request->batchtarget;
        $achieved = $request->batchtarget - $remaining;       
        $batchid = DB::table('target_batches')->insertGetId(['list_id'=>$request->listid,'campaign_id'=>$request->campaignid,'batchno'=>$request->batchno,'totaltarget'=>$request->batchtarget,'achieved'=>$achieved,'remaining'=>$remaining,'active'=>'Y']);
        $description = $request->batchno.' '.'batch target inserted with '.$request->batchtarget.' target(s)';
        }

        DB::table('target_logs')->insert(['listid'=>$request->listid,'batchid'=>$request->batchno,'description'=>$description,'created_by'=>Session::get('userid')]); 

        }

        if (!empty($request->batchtarget)) {
            $checklistid =  DB::table('target_lists')->where('list_id',$request->listid)->first();
            if(empty($checklistid)){
                $remaining = $request->batchtarget;
                $achieved = $request->batchtarget - $remaining;       
                DB::table('target_lists')->insert(['list_id'=>$request->listid,'campaign_id'=>$request->campaignid,'totaltarget'=>$request->batchtarget,'achieved'=>$achieved,'remaining'=>$remaining]);
                
            } 
        }

        return redirect('/auto-dial1')->with('alert', $alert);



    }

    public function autodial_upload(Request $request)
    {
        header('Content-Type: text/html; charset=utf-8');
        //print_r($request->all()); exit();
        //$path = 'public/auto_dial/auto_dial.csv';


        $path = $request->file('import_file')->getRealPath();

        $data = Excel::load($path)->get();
        
        $headerRow = $data->first()->keys()->toArray();
        $listid = $request->listid;
        //$listid = '1005';

        //print_r($headerRow); exit();

        //print_r($ophtml); exit();

        if($data->count()){

            $rec_count = 0;

            foreach ($data as $key => $value) {

            //print_r($value);
            if($request->filetype == '1'){
            if(!empty($value->cust_tele_3)){

            $phone = str_replace("+","",$value->cust_tele_3);
            VicidialList::insert(['list_id'=>$listid,'phone_number'=>$phone,'status'=>'NEW','called_since_last_reset'=>'N','filetype'=>$request->filetype,'batchno'=>$request->batchno]);

            $leadids =  VicidialList::where('list_id',$listid)->where('phone_number',$phone)->orderBy('lead_id','desc')->first();
            $leadid = $leadids->lead_id; 


            DB::table('honda_post_sales_followup')->insert(['leadid' => $leadid,'location' => $value->location,'xco' => $value->xco,'vsb_no' => $value->vsb_no,'invoice_no' => $value->invoice_no,'chasis_no' => $value->chasis_no,'name' => $value->name,'fran' => $value->fran,'model' => $value->model,'variant' => $value->variant,'year' => $value->year,'tot_inscost' => $value->tot_inscost,'compinscost' => $value->compinscost,'free_service' => $value->free_service,'stype' => $value->stype,'quote_date' => $value->quote_date,'estdel' => $value->estdel,'deldate' => $value->deldate,'invoice_date' => $value->invoice_date,'sales_exec' => $value->sales_exec,'cust_a_c' => $value->cust_a_c,'customer_a_c_name' => $value->customer_a_c_name,'arrival_date' => $value->arrival_date,'tr_in_val' => $value->tr_in_val,'pr_disc' => $value->pr_disc,'civil_id' => $value->civil_id,'cust_tele_1' => $value->cust_tele_1,'cust_tele_2' => $value->cust_tele_2,'cust_tele_3' => $value->cust_tele_3,'nationality' => $value->nationality,'position' => $value->position,'ac_status' => $value->ac_status,'prog_status' => $value->prog_status,'deposit' => $value->deposit,'invoice_total' => $value->invoice_total,'custamount' => $value->custamount,'main_invoice' => $value->main_invoice,'total' => $value->total,'pfno' => $value->pfno,'card_used' => $value->card_used,'buyback_pol' => $value->buyback_pol,'target' => $value->target,'dob' => $value->dob,'accessory' => $value->accessory,'description' => $value->description,'gender' => $value->gender,'ad1' => $value->ad1,'ad2' => $value->ad2,'ad3' => $value->ad3,'ad4' => $value->ad4,'Deliverydate_by_delivery_team' => $value->Deliverydate_by_delivery_team,'pdi' => $value->pdi,'email' => $value->email,'language' => $value->language,'lastservicedate' => $value->lastservicedate]);
            $rec_count++;
            }
            }

            else if($request->filetype == '2'){
            if(!empty($value->mobile)){

            $phone = str_replace("+","",$value->mobile);
            VicidialList::insert(['list_id'=>$listid,'phone_number'=>$phone,'status'=>'NEW','called_since_last_reset'=>'N','filetype'=>$request->filetype,'batchno'=>$request->batchno]);

            $leadids =  VicidialList::where('list_id',$listid)->where('phone_number',$phone)->orderBy('lead_id','desc')->first();
            $leadid = $leadids->lead_id; 


            DB::table('honda_post_service_followup')->insert(['leadid' => $leadid,'account' => $value->account,'invoice' => $value->invoice,'wip_no' => $value->wip_no,'date' => $value->date,'registration_number' => $value->registration_number,'title_initls_surname' => $value->title_initls_surname,'mobile' => $value->mobile,'gen' => $value->gen,'nationality' => $value->nationality,'date_of_birth' => $value->date_of_birth,'model_code' => $value->model_code,'year' => $value->year,'oper_code' => $value->oper_code,'operatror_name' => $value->operatror_name,'target' => $value->target]);
            $rec_count++;
            }
            }
            
            else if($request->filetype == '3'){
            if(!empty($value->mobile)){

            $phone = str_replace("+","",$value->mobile);
            VicidialList::insert(['list_id'=>$listid,'phone_number'=>$phone,'status'=>'NEW','called_since_last_reset'=>'N','filetype'=>$request->filetype,'batchno'=>$request->batchno]);

            $leadids =  VicidialList::where('list_id',$listid)->where('phone_number',$phone)->orderBy('lead_id','desc')->first();
            $leadid = $leadids->lead_id; 


            DB::table('honda_post_service_body_shop')->insert(['leadid' => $leadid,'account' => $value->account,'invoice' => $value->invoice,'wip_no' => $value->wip_no,'date' => $value->date,'registration_number' => $value->registration_number,'title_initls_surname' => $value->title_initls_surname,'mobile' => $value->mobile,'gen' => $value->gen,'nationality' => $value->nationality,'date_of_birth' => $value->date_of_birth,'model_code' => $value->model_code,'year' => $value->year,'oper_code' => $value->oper_code,'operatror_name' => $value->operatror_name,'target' => $value->target,'relation' => $value->relation]);
            $rec_count++;
            }
            }
            
            else if($request->filetype == '4'){
            if(!empty($value->phone)){

            $phone = str_replace("+","",$value->phone);
            VicidialList::insert(['list_id'=>$listid,'phone_number'=>$phone,'status'=>'NEW','called_since_last_reset'=>'N','filetype'=>$request->filetype,'batchno'=>$request->batchno]);

            $leadids =  VicidialList::where('list_id',$listid)->where('phone_number',$phone)->orderBy('lead_id','desc')->first();
            $leadid = $leadids->lead_id; 


            DB::table('honda_service_reminder')->insert(['leadid' => $leadid,'contdate' => $value->contdate,'agent' => $value->agent,'followup_exec' => $value->followup_exec,'fup_date' => $value->fup_date,'origin' => $value->origin,'notes' => $value->notes,'target' => $value->target,'custname' => $value->custname,'phone' => $value->phone,'status' => $value->status,'no_of_flup' => $value->no_of_flup,'first_flup' => $value->first_flup,'last_flup' => $value->last_flup,'flup_notes' => $value->flup_notes,'email' => $value->email,'mileage' => $value->mileage,'regno' => $value->regno,'chassisno' => $value->chassisno,'model' => $value->model,'modelyear' => $value->modelyear,'last_comment' => $value->last_comment]);
            $rec_count++;
            }
            }
            
            else if($request->filetype == '5'){
            if(!empty($value->contact)){

            $phone = str_replace("+","",$value->contact);
            VicidialList::insert(['list_id'=>$listid,'phone_number'=>$phone,'status'=>'NEW','called_since_last_reset'=>'N','filetype'=>$request->filetype,'batchno'=>$request->batchno]);

            $leadids =  VicidialList::where('list_id',$listid)->where('phone_number',$phone)->orderBy('lead_id','desc')->first();
            $leadid = $leadids->lead_id; 


            DB::table('honda_test_drive_survey')->insert(['leadid' => $leadid,'date_out' => $value->date_out,'time_out' => $value->time_out,'model' => $value->model,'variant' => $value->variant,'status' => $value->status,'sold' => $value->sold,'c' => $value->c,'qc' => $value->qc,'e' => $value->e,'q' => $value->q,'o' => $value->o,'c2' => $value->C2,'a' => $value->a,'i' => $value->i,'l' => $value->l,'x' => $value->x,'qq' => $value->qq,'salesexec' => $value->salesexec,'targetno' => $value->targetno,'customer_nam' => $value->customer_nam,'contact' => $value->contact,'target_creator' => $value->target_creator,'approved_by' => $value->approved_by]);
            $rec_count++;
            }
            }
            
            else if($request->filetype == '6'){
            if(!empty($value->phone_number)){

            $phone = str_replace("+","",$value->phone_number);
            VicidialList::insert(['list_id'=>$listid,'phone_number'=>$phone,'status'=>'NEW','called_since_last_reset'=>'N','filetype'=>$request->filetype,'batchno'=>$request->batchno]);

            $leadids =  VicidialList::where('list_id',$listid)->where('phone_number',$phone)->orderBy('lead_id','desc')->first();
            $leadid = $leadids->lead_id; 


            DB::table('honda_leads')->insert(['leadid' => $leadid,'vehicle' => $value->vehicle,'created_time' => $value->created_time,'platform' => $value->platform,'current_car' => $value->current_car,'first_name' => $value->first_name,'last_name' => $value->last_name,'phone_number' => $value->phone_number,'email' => $value->email]);
            $rec_count++;
            }
            }


                // /print_r($data);
            }
            $alert = $rec_count." Records Added Successfully";
            //exit();
        }

        return redirect('/auto-dial')->with('alert', $alert);

    }

    public function auto_upload()
    {
        $lists = VicidialLists::select('list_id','list_name','campaign_id')->get();
        //print_r($lists); exit();
        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->get();
        

        $folder = DB::table('cron_folder')->where('delete_status','0')->first();
        
        // print_r($inbounds); exit();
        return view('autoupload_dial',compact('lists','campaigns','folder'));
    }

    public function autodial_folder(Request $request)
    {
        DB::table('cron_folder')->update(['delete_status' => '1']);
        DB::table('cron_folder')->insert(['location' => $request->directory]);
        return redirect('/autoupload-dial');
    }

    public function autodial_upload1(Request $request)
    {

        header('Content-Type: text/html; charset=utf-8');
        //print_r($request->all()); exit();
        //$path = 'public/auto_dial/auto_dial.csv';


        $path = $request->file('import_file')->getRealPath();

        $data = Excel::load($path)->get();
        
        $headerRow = $data->first()->keys()->toArray();


        //print_r($headerRow); exit();

        if($data->count()){

            $rec_count = 0;

            foreach ($data as $key => $value) {

                    //print_r($value->mobile);

            $lists = DB::table('cron_autodial')->insert(['phone_number' => $value->mobile,'first_name' => $value->name,'listid' => $request->listid,'campaignid' => $request->campaignid,'entry_datetime' => $request->entry_date]);

            $rec_count++;

                // /print_r($data);
            }
            $alert = $rec_count." Records Added Successfully";
            //exit();
        }

        $product_img = Input::file('import_file');
  
        //print_r($destinationPath1); exit();
        if($product_img)
         {
  
              $destinationPath1 = $_SERVER['DOCUMENT_ROOT'].'/alghanim/public/auto_dial';           
              $timestamp1 = str_replace([' ', ':'], '-', date("YmdHis"));
              $namefile1 = $product_img->getClientOriginalName();    
              $recfilename1 = preg_replace('/\s+/', '', $namefile1);
              $recfilename1 = $timestamp1."_123_".$recfilename1;
              $upload_success1 = Input::file('import_file')->move($destinationPath1, $recfilename1);
              $certificatePath1 = ('http://'.$_SERVER['HTTP_HOST']."/alghanim/public/auto_dial/".$recfilename1);

         }

        return redirect('/autoupload-dial')->with('alert', $alert);

    }

}
