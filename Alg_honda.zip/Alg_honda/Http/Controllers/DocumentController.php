<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\VehStatus;

class DocumentController extends Controller
{
   

    public function history($docref=0)
    { 

        $soapUrl = "http://172.16.4.16:790/AlghanimAutoline/WCOM?wsdl";
        //print_r($soapUrl); exit();
        //$soapUser = "username";  //  username
        //$soapPassword = "password"; // password

        // xml post structure
        $xml_post_string = '<?xml version="1.0" encoding="UTF-8"?>
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dcom="http://172.16.4.16:790/AlghanimAutoline/WCOM">
        <soapenv:Body>
        <dcom:GetArchivedDocument>
        <dcom:Identification>
        <dcom:SessionId>10000005</dcom:SessionId>
        </dcom:Identification>
        <dcom:LookupCodes>
        <dcom:RooftopId>TABYAAS01</dcom:RooftopId>
        <dcom:DocRef>'.$docref.'</dcom:DocRef>
        <dcom:Terminal>1021</dcom:Terminal>
        </dcom:LookupCodes>
        </dcom:GetArchivedDocument>
        </soapenv:Body>
        </soapenv:Envelope>';

        $headers = array(
        "Content-type: text/xml;charset=\"utf-8\"",
        "Accept: text/xml",
        "Cache-Control: no-cache",
        "Pragma: no-cache",
        "SOAPAction: urn:kcml-WCOM#GetArchivedDocument", 
        "Content-length: ".strlen($xml_post_string),
        ); //SOAPAction: your op URL

        $url = $soapUrl;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // converting
        $response = curl_exec($ch); 
        //$info = curl_getinfo($response);
        //echo var_dump($response);
        curl_close($ch);

        // converting
        $response1 = str_replace("<soap:Body>","",$response);
        $response2 = str_replace("</soap:Body>","",$response1);

        // convertingc to XML
        $parser = simplexml_load_string($response2);
        $txtfile = $response;
        $myfilename ="";
        $urls = explode("http://", $txtfile);
        foreach ($urls as $url) {
            if (strpos($url, '.txt') !== false) {
                $fileext = explode(".txt", $url);
                $myfilename ='http://'.$fileext[0].'.txt';
            }
        }
        if (empty($myfilename)) {
            return redirect()->back()->with('alert', 'IT IS EMPTY!');
        }
        else{
            
        return redirect($myfilename);
        }

    }




    public function showvehstatus(Request $request)
    {
    if($request->ajax())
    {
            $vehid = 0;
            $divhtml = '';  

        if(isset($_POST['vehid']) && !empty($_POST['vehid'])) {

            $vehmagic = $_POST['vehid'];
            $brand = $_POST['brand'];
            $centre = $_POST['centre'];

            $status = ' not found';
            $statuscode = '';
            $WIPNumber = ' not found';
            $Registration = ' not found';
            $WLInOut = ' not found';
            $WLDateIn = ' not found';
            $BookedInOperator = ' not found';
            $BookedOutOperator = ' not found';
            $OperatorName = ' not found';
            $OperatorName1 = ' not found';
            $InOperator = '';
            $OutOperator = '';



            $curl = curl_init();
            // $centre = 'SO_13';
            // $vehmagic = '633111';
            // $brand = 'Chevrolet';
            $date90 = date('Y-m-d', strtotime("-90 day"));
            //echo $date90;
            $sendDATA = "{\r\n\r\n    \"brand\":\"".$brand."\",\r\n    \"query\": \"SELECT  ".$centre."_Headr.BookedInOperator, ".$centre."_Headr.BookedOutOperator,".$centre."_Headr.WLInOut, ".$centre."_Headr.WLDateIn, ".$centre."_Headr.BookingStatus, ".$centre."_Headr.WIPNumber,".$centre."_Headr.Registration, ".$centre."_Headr.MagicMKVehicle, ".$centre."_Headr.Status FROM ".$centre."_Headr WHERE ( ".$centre."_Headr.WLDateOut Is Null) AND ( ".$centre."_Headr.WLInOut='IN') AND ( ".$centre."_Headr.MagicMKVehicle in (' ".$vehmagic." ')) AND (".$centre."_Headr.WLDateIn>{d '".$date90."'})\"\r\n}";
            curl_setopt_array($curl, array(
            CURLOPT_URL => "https://172.16.5.69/odbc/getdetailsfromodbc",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_POSTFIELDS =>$sendDATA,
            CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json"
            ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);
            //echo $response;
            $data = json_decode($response, true);
            if (!empty($data['data'])) {
            if($data['code'] == '200'){
            $statuscode = $data['data'][0]['BookingStatus'];
            $WIPNumber = $data['data'][0]['WIPNumber'];
            $Registration = $data['data'][0]['Registration'];
            $BookedInOperator = $data['data'][0]['BookedInOperator'];
            $BookedOutOperator = $data['data'][0]['BookedOutOperator'];
            $WLInOut = $data['data'][0]['WLInOut'];
            $WLDateIn = $data['data'][0]['WLDateIn'];
            $InOperator = intval($BookedInOperator);
            $OutOperator = intval($BookedOutOperator);
            }
            }

            if(!empty($InOperator)){
            $curl = curl_init();
            // $centre = 'SO_13';
            // $vehmagic = '633111';
            // $brand = 'Chevrolet';
            $date90 = date('Y-m-d', strtotime("-90 day"));
            //echo $date90;
            $sendDATA =  "{\r\n\r\n    \"brand\":\"".$brand."\",\r\n    \"query\": \"SELECT ".$centre."_opers.OperatorCode, ".$centre."_opers.OperatorNumber, ".$centre."_opers.OperatorName from ".$centre."_opers where ".$centre."_opers.OperatorCode='".$InOperator."'\"\r\n}";
           

            curl_setopt_array($curl, array(
            CURLOPT_URL => "https://172.16.5.69/odbc/getdetailsfromodbc",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_POSTFIELDS =>$sendDATA,
            CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json"
            ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);
            //echo $response;
            $data = json_decode($response, true);
            if (!empty($data['data'])) {
            if($data['code'] == '200'){
            $OperatorName = $data['data'][0]['OperatorName'];
            }
            }
            }  
            

            if(!empty($OutOperator)){      

            $curl = curl_init();
            // $centre = 'SO_13';
            // $vehmagic = '633111';
            // $brand = 'Chevrolet';
            $date90 = date('Y-m-d', strtotime("-90 day"));
            //echo $date90;
            $sendDATA =  "{\r\n\r\n    \"brand\":\"".$brand."\",\r\n    \"query\": \"SELECT ".$centre."_opers.OperatorCode, ".$centre."_opers.OperatorNumber, ".$centre."_opers.OperatorName from ".$centre."_opers where ".$centre."_opers.OperatorCode='".$OutOperator."'\"\r\n}";
           

            curl_setopt_array($curl, array(
            CURLOPT_URL => "https://172.16.5.69/odbc/getdetailsfromodbc",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_POSTFIELDS =>$sendDATA,
            CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json"
            ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);
            //echo $response;
            $data = json_decode($response, true);
            if($data['code'] == '200'){
            $OperatorName1 = $data['data'][0]['OperatorName'];
            }
            }


            $VehStatus = VehStatus::where('code',$statuscode)->get();
            if (count($VehStatus) > 0) {
                $status = $VehStatus[0]->desc;
            }
            $divhtml.='<b>Status</b> : '.$status .'<br>'; 
            $divhtml.='<b>WIPNumber</b> : '.$WIPNumber .'<br>'; 
            $divhtml.='<b>Registration</b> : '.$Registration .'<br>'; 
            $divhtml.='<b>BookedInOperator</b> : '.$BookedInOperator .'<br>'; 
            $divhtml.='<b>BookedOutOperator</b> : '.$BookedOutOperator .'<br>';  
            $divhtml.='<b>WLInOut</b> : '.$WLInOut .'<br>'; 
            $divhtml.='<b>WLDateIn</b> : '.$WLDateIn .'<br>'; 
            $divhtml.='<b>BookedInOperatorName</b> : '.$OperatorName .'<br>'; 
            $divhtml.='<b>BookedOutOperatorName</b> : '.$OperatorName1 .'<br>'; 


        }
        echo json_encode(array("divhtml"=>$divhtml));
    }

    }


}
