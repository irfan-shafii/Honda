<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
use App\VicidialLog;
use App\VicidialCloserLog;
use App\VicidialDialLog;
use App\VicidialList;
use App\VicidialLists;
use App\VicidialCampaign;
use App\VicidialAgentLog; 
use Illuminate\Support\Facades\Input; //header
use Excel;
use App\Average;
use App\MKtargt;
use App\MKhisty;
use App\MKvlink;
use App\MKvehic;
use App\MKnewst;
use App\VicidialAutoCalls;
use App\VicidialLiveAgent;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index(Request $request,$monthly='')
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $current_date = date('Y-m-d');
        //$current_date = '2019-11-17';
        $day = date('d');
        $month = date('m');
        $year = date('Y');
        $phone = '';
        $campaignids = Session::get('campaignid');

        $inbound_count = 0;
        $outbound_count = 0;
        $missed_count = 0;
        $missedtotal = 0;
        $outbound_connected = 0;

        if (empty($monthly)) {
            $fromdate = date('Y-m-d');
            $todate = date('Y-m-d');
            if(!empty($request->day)){
                $day = $request->day;
                $month = $request->month;
                $year = $request->year;
                $fromdate = $year. '-' . $month. '-' . $day;
                $todate = $year. '-' . $month. '-' . $day;
            }
        }
        else{
            $fromdate = date('Y-m-01');
            $todate = date('Y-m-31');
            if(!empty($request->day)){
                $day = $request->day;
                $month = $request->month;
                $year = $request->year;
                $fromdate = $year. '-' . $month. '-01';
                $todate = $year. '-' . $month. '-31';
            }
        }
        //print_r($monthly); exit();
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));


        $ingroupids = '';
        if(!empty($campaignids)){
            $ingroups = DB::table('user_campaigns')->select('campaigns','ingroups')->whereIn('campaigns',explode(",", $campaignids))->get();
            if(count($ingroups) > 0) {
                foreach ($ingroups as $ing) {
                    $ingrps[] = $ing->ingroups;
                }
            $ingroupids = implode(",", $ingrps);
            //print_r($ingroupids); exit();
            }
        }


        $outbound = VicidialLog::whereBetween('call_date',[$fromdate, $todate1]);
        $outbound1 = VicidialLog::where('list_id','1001')->whereBetween('call_date',[$fromdate, $todate1])->get();

        $outbound_pu = $outbound1->where('status','PU')->count();
        $outbound_pm = $outbound1->where('status','PM')->count();
        $outbound_ab = $outbound1->where('status','AB')->count();
        $outbound_na1 = $outbound1->where('status','NA')->count();
        $outbound_b1 = $outbound1->where('status','B')->count();

        if(!empty($campaignids)){
            $outbound = $outbound->whereIn('campaign_id',explode(",", $campaignids));
        }
        $outbound = $outbound->get();
        $inbound = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','!=','DROP');
        if(!empty($campaignids)){
            $inbound = $inbound->whereIn('campaign_id',explode(",", $ingroupids));
        }
        $inbound = $inbound->get();
        $missed = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','=','DROP');
        if(!empty($campaignids)){
            $missed = $missed->whereIn('campaign_id',explode(",", $ingroupids));
        }
        $missed = $missed->get();
        if(!empty($request->phone)){
            $phone = $request->phone;
            $inbound = $inbound->where('phone_number',$phone);
            $outbound = $outbound->where('phone_number',$phone);
            $missed = $missed->where('phone_number',$phone);
        }
        $inbound_count = $inbound->count();
        $outbound_count = $outbound->count();
        $missedtotal = $missed->count();
        $outbound_connected = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->where('length_in_sec','>','0')->count();

            foreach($missed as $mlog){
             $status_answer = VicidialCloserLog::where('phone_number',$mlog->phone_number)->where('call_date','>',$mlog->call_date)->where('closecallid','>',$mlog->closecallid)->where('status','!=','DROP')->where('length_in_sec','>','0')->count();
             $status_log = VicidialLog::where('phone_number',$mlog->phone_number)->where('call_date','>',$mlog->call_date)->where('length_in_sec','>','0')->count();

             if($status_answer == 0 && $status_log == 0 ){
               $missed_count++;
                }

           }

        $outbound_a = $outbound->where('status','Answer')->count();
        $outbound_na = $outbound->where('status','NA')->count();
        $outbound_b = $outbound->where('status','B')->count();
        $outbound_d = $outbound->where('status','DROP')->count();

        $vicidial_agent_log = VicidialAgentLog::join('vicidial_users', 'vicidial_agent_log.user', '=', 'vicidial_users.user')->whereBetween('event_time',[$fromdate, $todate1])->where('talk_sec','<','65000')->where('pause_sec','<','65000')->where('wait_sec','<','65000')->where('dispo_sec','<','65000')->where('status','!=',null);

        $top_agents = $vicidial_agent_log->select('vicidial_agent_log.user', DB::raw('count(*) as calls'))->addSelect('vicidial_users.full_name','vicidial_agent_log.user_group')->groupBy('vicidial_agent_log.user','vicidial_users.full_name'); 

        if(!empty($campaignids)){
            $top_agents = $top_agents->whereIn('campaign_id',explode(",", $campaignids));
        }
        $top_agents = $top_agents->orderBy('calls','desc')->get();

        $agentcounts = VicidialAgentLog::select('user','event_time')->whereBetween('event_time',[$fromdate, $todate1])->where('status','!=',null);
        if(!empty($campaignids)){
            $agentcounts = $agentcounts->whereIn('campaign_id',explode(",", $campaignids));
        }
        $agentcounts = $agentcounts->count();

        $hourly = array();
        for ($time=0; $time <= 24 ; $time++) { 
            $time1 = $time+1;
            $fromtime = date("$year-$month-$day $time:00:00");
            $totime = date("$year-$month-$day $time1:00:00");
            $mstatus = 'DROP,NANQUE';
            $hourcalls = VicidialCloserLog::whereBetween('call_date',[$fromtime, $totime])->where('status','!=','DROP')->count();
            $mcalls = VicidialCloserLog::whereBetween('call_date',[$fromtime, $totime])->whereIn('status',explode(",", $mstatus))->count();
            $ocalls = VicidialLog::whereBetween('call_date',[$fromtime, $totime])->count();
            $occalls = VicidialLog::whereBetween('call_date',[$fromtime, $totime])->where('length_in_sec','>','0')->count();
        //print_r($fromtime . ' - '.$totime . ' - '.$hourcalls.'<br>');

            $hourly[] = array(
                        "hour" => $time,
                        "calls" =>$hourcalls,
                        "mcalls" =>$mcalls,
                        "ocalls" =>$ocalls,
                        "occalls" =>$occalls
                        );

        }


        $enquiry_categories = DB::table('enquiry_categories')->where('leadid','INBOUND')->where('parent_id','0')->orderBy('id_enquiry_category','asc')->get();
        $enqlabel1 ='';
        $enqlabel2 ='';
        $enqlists = array();
        $enqtotal =0;
        $enqcounttotal = 0;
        $enqnames = '';
        $enqdata = '';

        $colorcount = 0;
        if($enquiry_categories){

            $fromtime = date("$year-$month-$day 00:00:00");
            $totime = date("$year-$month-$day 23:59:59");

        foreach ($enquiry_categories as $cat) {

            $enqcounttotal = DB::table('opportunity')->select('date_add','enquiry_category','id_enquiry_category')->whereBetween('date_add',[$fromtime, $totime])->where('enquiry_category',$cat->id_enquiry_category)->count();
            $enqtotal += $enqcounttotal;

            $enqnames .= '"'.$cat->category_name.'",';
            $enqdata .= $enqcounttotal.',';
                //$enqnames[] =array("name" => $cat->category_name,"count" => $enqcounttotal);

        }

        foreach ($enquiry_categories as $cat) {

            $enqcount1 = DB::table('opportunity')->select('date_add','enquiry_category')->whereBetween('date_add',[$fromtime, $totime])->where('enquiry_category',$cat->id_enquiry_category)->count();
            $enqcounttotal = DB::table('opportunity')->select('date_add','enquiry_category')->whereBetween('date_add',[$fromtime, $totime])->count();
            
            $enqlabel1 .=" {
                label: '".$cat->category_name." (".Average::MathPER($enqcount1,$enqtotal)."%) - ".$enqcount1."',";
            if ($colorcount == 0) {
                $bgcolor = "#3e95cd";
            $enqlabel1 .=" backgroundColor: color(window.chartColors.red).alpha(0.5).rgbString(),
                borderColor: window.chartColors.red,";
            }
            else if ($colorcount == 1) {
                $bgcolor = "#8e5ea2";
            $enqlabel1 .=" backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
                borderColor: window.chartColors.blue,";
            }
            else if ($colorcount == 2) {
                $bgcolor = "#3cba9f";
            $enqlabel1 .=" backgroundColor: color(window.chartColors.yellow).alpha(0.5).rgbString(),
                borderColor: window.chartColors.yellow,";
            }
            else if ($colorcount == 3) {
                $bgcolor = "#e8c3b9";
            $enqlabel1 .=" backgroundColor: color(window.chartColors.purple).alpha(0.5).rgbString(),
                borderColor: window.chartColors.purple,";
            }
            else if ($colorcount == 4) {
                $bgcolor = "#c45850";
            $enqlabel1 .=" backgroundColor: color(window.chartColors.green).alpha(0.5).rgbString(),
                borderColor: window.chartColors.green,";
            }
            else if ($colorcount == 5) {
                $bgcolor = "#95D7BB";
            $enqlabel1 .=" backgroundColor: color(window.chartColors.grey).alpha(0.5).rgbString(),
                borderColor: window.chartColors.grey,";
            }
            else{
                $bgcolor = "#E67A77";
            $enqlabel1 .=" backgroundColor: color(window.chartColors.orange).alpha(0.5).rgbString(),
                borderColor: window.chartColors.orange,";
            }
            $colorcount++;
            $enqlabel1 .=" borderWidth: 1,
                data: [";


            $enqlabel1 .= $enqcount1.",";

            $enqlists[] = array(
                        "value" => $enqcount1,
                        "label" =>$cat->category_name,
                        "enqid" =>$cat->id_enquiry_category,
                        "bgcolor" =>$bgcolor,
                        "formatted" =>round(Average::MathPER($enqcount1,$enqtotal))
                        );

            $enqlabel2 .= "{value: ".$enqcount1.", label: '".$cat->category_name."', formatted: '".round(Average::MathPER($enqcount1,$enqtotal))."%' },";

            $enqlabel1 .="]
            },";
        }
        }



        $listids = '';
        if(!empty($campaignids)){
            $lists = VicidialLists::select('list_id','list_name','campaign_id')->whereIn('campaign_id',explode(",", $campaignids))->get();
            if(count($lists) > 0) {
                foreach ($lists as $list) {
                    $listgrps[] = $list->list_id;
                }
            $listids = implode(",", $listgrps);
            }
        }
        $list_idss = VicidialLists::select('list_id','list_name')->where('active','Y')->orderBy('list_name','asc')->get();

        $statuses = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->where('list_id','1001')->select('status', DB::raw('count(*) as statuses'))->groupBy('status')->get();
        $statname = '';
        $statcount = '';
        $stats = '';
        $statc = '';
        foreach($statuses as $stat){
        $outboundstat = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->where('status',$stat->status)->count();
        $stats[] = '"'.$stat->status.'"';
        $statc[] = $outboundstat;

        }
        //$statname = implode(",", $stats);
        //$statcount = implode(",", $statc);
        // print_r($statname);
         // print_r('<br>'.$enqnames);
         // exit();


        $queue_count = VicidialAutoCalls::where('status','=','LIVE')->count();
        $queue_calls = VicidialAutoCalls::where('status','=','LIVE')->get();

        $liveagents = VicidialLiveAgent::select('live_agent_id','user','extension','status','campaign_id','conf_exten','calls_today')->orderBy('status','asc')->get();


        return view('dashboard.dashboard',compact('inbound_count','outbound_count','missed_count','outbound_connected','missedtotal','top_agents','agentcounts','year','month','day','hourly','enqnames','enqdata','enqlabel1','enqlabel2','enqlists','enqtotal','listids','campaignids','outbound_a','outbound_na','outbound_b','outbound_na1','outbound_b1','outbound_d','outbound_pu','outbound_pm','outbound_ab','list_idss','statname','statcount','liveagents','queue_calls','monthly','fromdate','todate1'));
    }




    public function index1(Request $request,$monthly='')
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $current_date = date('Y-m-d');
        //$current_date = '2019-11-17';
        $day = date('d');
        $month = date('m');
        $year = date('Y');
        $day1 = date('d');
        $month1 = date('m');
        $year1 = date('Y');
        $phone = '';
        $campaignids = Session::get('campaignid');

        $inbound_count = 0;
        $outbound_count = 0;
        $missed_count = 0;
        $missedtotal = 0;
        $outbound_connected = 0;

        if(!empty($request->day)){
            $day = $request->day;
            $month = $request->month;
            $year = $request->year;
        }
        if(!empty($request->day)){
            $day1 = $request->day1;
            $month1 = $request->month1;
            $year1 = $request->year1;
        }
            $fromdate = $year. '-' . $month. '-' . $day;
            $todate = $year1. '-' . $month1. '-' . $day1;
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));


        $ingroupids = '';
        if(!empty($campaignids)){
            $ingroups = DB::table('user_campaigns')->select('campaigns','ingroups')->whereIn('campaigns',explode(",", $campaignids))->get();
            if(count($ingroups) > 0) {
                foreach ($ingroups as $ing) {
                    $ingrps[] = $ing->ingroups;
                }
            $ingroupids = implode(",", $ingrps);
            //print_r($ingroupids); exit();
            }
        }


        $outbound = VicidialLog::whereBetween('call_date',[$fromdate, $todate1]);
        $outbound1 = VicidialLog::where('list_id','1001')->whereBetween('call_date',[$fromdate, $todate1])->get();

        $outbound_pu = $outbound1->where('status','PU')->count();
        $outbound_pm = $outbound1->where('status','PM')->count();
        $outbound_ab = $outbound1->where('status','AB')->count();
        $outbound_na1 = $outbound1->where('status','NA')->count();
        $outbound_b1 = $outbound1->where('status','B')->count();

        if(!empty($campaignids)){
            $outbound = $outbound->whereIn('campaign_id',explode(",", $campaignids));
        }
        $outbound = $outbound->get();
        $inbound = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','!=','DROP');
        if(!empty($campaignids)){
            $inbound = $inbound->whereIn('campaign_id',explode(",", $ingroupids));
        }
        $inbound = $inbound->get();
        $missed = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','=','DROP');
        if(!empty($campaignids)){
            $missed = $missed->whereIn('campaign_id',explode(",", $ingroupids));
        }
        $missed = $missed->get();
        if(!empty($request->phone)){
            $phone = $request->phone;
            $inbound = $inbound->where('phone_number',$phone);
            $outbound = $outbound->where('phone_number',$phone);
            $missed = $missed->where('phone_number',$phone);
        }
        $inbound_count = $inbound->count();
        $outbound_count = $outbound->count();
        $missedtotal = $missed->count();
        $outbound_connected = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->where('length_in_sec','>','0')->count();

            foreach($missed as $mlog){
             $status_answer = VicidialCloserLog::where('phone_number',$mlog->phone_number)->where('call_date','>',$mlog->call_date)->where('closecallid','>',$mlog->closecallid)->where('status','!=','DROP')->where('length_in_sec','>','0')->count();
             $status_log = VicidialLog::where('phone_number',$mlog->phone_number)->where('call_date','>',$mlog->call_date)->where('length_in_sec','>','0')->count();

             if($status_answer == 0 && $status_log == 0 ){
               $missed_count++;
                }

           }

        $outbound_a = $outbound->where('status','Answer')->count();
        $outbound_na = $outbound->where('status','NA')->count();
        $outbound_b = $outbound->where('status','B')->count();
        $outbound_d = $outbound->where('status','DROP')->count();

        $vicidial_agent_log = VicidialAgentLog::join('vicidial_users', 'vicidial_agent_log.user', '=', 'vicidial_users.user')->whereBetween('event_time',[$fromdate, $todate1])->where('talk_sec','<','65000')->where('pause_sec','<','65000')->where('wait_sec','<','65000')->where('dispo_sec','<','65000')->where('status','!=',null);

        $top_agents = $vicidial_agent_log->select('vicidial_agent_log.user', DB::raw('count(*) as calls'))->addSelect('vicidial_users.full_name','vicidial_agent_log.user_group')->groupBy('vicidial_agent_log.user','vicidial_users.full_name'); 

        if(!empty($campaignids)){
            $top_agents = $top_agents->whereIn('campaign_id',explode(",", $campaignids));
        }
        $top_agents = $top_agents->orderBy('calls','desc')->get();

        $agentcounts = VicidialAgentLog::select('user','event_time')->whereBetween('event_time',[$fromdate, $todate1])->where('status','!=',null);
        if(!empty($campaignids)){
            $agentcounts = $agentcounts->whereIn('campaign_id',explode(",", $campaignids));
        }
        $agentcounts = $agentcounts->count();

        $hourly = array();
        for ($time=0; $time <= 24 ; $time++) { 
            $time1 = $time+1;
            $fromtime = date("$year-$month-$day $time:00:00");
            $totime = date("$year1-$month1-$day1 $time1:00:00");
            $mstatus = 'DROP,NANQUE';
            $hourcalls = VicidialCloserLog::whereBetween('call_date',[$fromtime, $totime])->where('status','!=','DROP')->get();
                  $hourc=0;  
            foreach ($hourcalls as $hourcall) {
                if(date("H",strtotime($hourcall->call_date)) == $time){
                  $hourc++;  
                }
            }
            $mcalls = VicidialCloserLog::whereBetween('call_date',[$fromtime, $totime])->whereIn('status',explode(",", $mstatus))->get();
                  $mcal=0;  
            foreach ($mcalls as $mcall) {
                if(date("H",strtotime($mcall->call_date)) == $time){
                  $mcal++;  
                }
            }
        //print_r($fromtime . ' - '.$totime . ' - '.$hourcalls.'<br>');

            $hourly[] = array(
                        "hour" => $time,
                        "calls" =>$hourc,
                        "mcalls" =>$mcal
                        );

        }


        $enquiry_categories = DB::table('enquiry_categories')->where('leadid','INBOUND')->where('parent_id','0')->orderBy('id_enquiry_category','asc')->get();
        $enqlabel1 ='';
        $enqtotal =0;
        $enqcounttotal = 0;
        $enqnames = array();

        $colorcount = 0;
        if($enquiry_categories){

            $fromtime = date("$year-$month-$day 00:00:00");
            $totime = date("$year1-$month1-$day1 23:59:59");

        foreach ($enquiry_categories as $cat) {

            $enqcounttotal = DB::table('opportunity')->select('date_add','enquiry_category')->whereBetween('date_add',[$fromtime, $totime])->where('enquiry_category',$cat->id_enquiry_category)->count();
            $enqtotal += $enqcounttotal;
        }
        foreach ($enquiry_categories as $cat) {

            $enqcount1 = DB::table('opportunity')->select('date_add','enquiry_category')->whereBetween('date_add',[$fromtime, $totime])->where('enquiry_category',$cat->id_enquiry_category)->count();
            $enqcounttotal = DB::table('opportunity')->select('date_add','enquiry_category')->whereBetween('date_add',[$fromtime, $totime])->count();
            
            $enqlabel1 .=" {
                label: '".$cat->category_name." (".Average::MathPER($enqcount1,$enqtotal)."%) - ".$enqcount1."',";
            if ($colorcount == 0) {
            $enqlabel1 .=" backgroundColor: color(window.chartColors.red).alpha(0.5).rgbString(),
                borderColor: window.chartColors.red,";
            }
            else if ($colorcount == 1) {
            $enqlabel1 .=" backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
                borderColor: window.chartColors.blue,";
            }
            else if ($colorcount == 2) {
            $enqlabel1 .=" backgroundColor: color(window.chartColors.yellow).alpha(0.5).rgbString(),
                borderColor: window.chartColors.yellow,";
            }
            else if ($colorcount == 3) {
            $enqlabel1 .=" backgroundColor: color(window.chartColors.purple).alpha(0.5).rgbString(),
                borderColor: window.chartColors.purple,";
            }
            else if ($colorcount == 4) {
            $enqlabel1 .=" backgroundColor: color(window.chartColors.green).alpha(0.5).rgbString(),
                borderColor: window.chartColors.green,";
            }
            else if ($colorcount == 5) {
            $enqlabel1 .=" backgroundColor: color(window.chartColors.grey).alpha(0.5).rgbString(),
                borderColor: window.chartColors.grey,";
            }
            else{
            $enqlabel1 .=" backgroundColor: color(window.chartColors.orange).alpha(0.5).rgbString(),
                borderColor: window.chartColors.orange,";
            }
            $colorcount++;
            $enqlabel1 .=" borderWidth: 1,
                data: [";


            $enqlabel1 .= $enqcount1.",";

            $enqlabel1 .="]
            },";
        }
        }



        $listids = '';
        if(!empty($campaignids)){
            $lists = VicidialLists::select('list_id','list_name','campaign_id')->whereIn('campaign_id',explode(",", $campaignids))->get();
            if(count($lists) > 0) {
                foreach ($lists as $list) {
                    $listgrps[] = $list->list_id;
                }
            $listids = implode(",", $listgrps);
            }
        }
        $list_idss = VicidialLists::select('list_id','list_name')->where('active','Y')->orderBy('list_name','asc')->get();

        $statuses = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->where('list_id','1001')->select('status', DB::raw('count(*) as statuses'))->groupBy('status')->get();
        $statname = '';
        $statcount = '';
        $stats = '';
        $statc = '';
        foreach($statuses as $stat){
        $outboundstat = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->where('status',$stat->status)->count();
        $stats[] = '"'.$stat->status.'"';
        $statc[] = $outboundstat;

        }
        //$statname = implode(",", $stats);
        //$statcount = implode(",", $statc);
        // print_r($statname);
        // print_r('<br>'.$statcount);
        // exit();


        $queue_count = VicidialAutoCalls::where('status','=','LIVE')->count();
        $queue_calls = VicidialAutoCalls::where('status','=','LIVE')->get();

        $liveagents = VicidialLiveAgent::select('live_agent_id','user','extension','status','campaign_id','conf_exten','calls_today')->orderBy('status','asc')->get();


        return view('dashboard.dashboard1',compact('inbound_count','outbound_count','missed_count','outbound_connected','missedtotal','top_agents','agentcounts','year','month','day','year1','month1','day1','hourly','enqlabel1','enqtotal','listids','campaignids','outbound_a','outbound_na','outbound_b','outbound_na1','outbound_b1','outbound_d','outbound_pu','outbound_pm','outbound_ab','list_idss','statname','statcount','liveagents','queue_calls','monthly','fromdate','todate1'));
        
    }

    public function index2(Request $request,$monthly='')
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $current_date = date('Y-m-d');
        //$current_date = '2019-11-17';
        $day = date('d');
        $month = date('m');
        $year = date('Y');
        $day1 = date('d');
        $month1 = date('m');
        $year1 = date('Y');
        $phone = '';
        $campaignids = Session::get('campaignid');

        if(!empty($request->day)){
            $day = $request->day;
            $month = $request->month;
            $year = $request->year;
        }
        if(!empty($request->day)){
            $day1 = $request->day1;
            $month1 = $request->month1;
            $year1 = $request->year1;
        }
            $fromdate = $year. '-' . $month. '-' . $day;
            $todate = $year1. '-' . $month1. '-' . $day1;
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));

        $listids = '';
        if(!empty($campaignids)){
            $lists = VicidialLists::select('list_id','list_name','campaign_id')->whereIn('campaign_id',explode(",", $campaignids))->get();
            if(count($lists) > 0) {
                foreach ($lists as $list) {
                    $listgrps[] = $list->list_id;
                }
            $listids = implode(",", $listgrps);
            }
        }

        $list_idss = VicidialLists::select('list_id','list_name')->whereBetween('list_id',['3001', '4008'])->where('active','Y')->orderBy('list_name','asc')->get();

        $statuses = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->where('list_id','1001')->select('status', DB::raw('count(*) as statuses'))->groupBy('status')->get();
        $statname = '';
        $statcount = '';
        $stats = '';
        $statc = '';
        foreach($statuses as $stat){
        $outboundstat = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->where('status',$stat->status)->count();
        $stats[] = '"'.$stat->status.'"';
        $statc[] = $outboundstat;

        }
        //$statname = implode(",", $stats);
        //$statcount = implode(",", $statc);
        // print_r($statname);
        // print_r('<br>'.$statcount);
        // exit();


        return view('dashboard.dashboard2',compact('year','month','day','year1','month1','day1','listids','campaignids','list_idss','monthly','fromdate','todate1'));
        
    }



    public function export(Request $request)
    {

        //print_r($request->all()); exit();
        $campaignids = Session::get('campaignid');
        $exports = array();
        $expname = '';

        if($request->exporttype == 'enquiry'){

        $inquiries = DB::table('opportunity')->whereBetween('date_add',[$request->fromdate, $request->todate])->where('enquiry_category',$request->list_id)->get();  
            foreach ($inquiries as $app) {
                    $enq_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$app->enquiry_category)->first();
                    $enq_sub_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$app->enquiry_subcategory)->first();
                    $enq_category = '';
                    $enq_subcategory = '';
                    $enq_subcategory2 = '';
                    $enq_subcategory3 = '';

                     if(!empty($app->enquiry_subcategory2) || $app->enquiry_subcategory2 == '0'){

                     $enq_sub_cat2 = DB::table('enquiry_categories')->where('id_enquiry_category',$app->enquiry_subcategory2)->first();

                    if(count($enq_sub_cat2) > 0){
                      $enq_subcategory2 = ", ".$enq_sub_cat2->category_name;
                    }

                    }

                    if(!empty($app->enquiry_subcategory3) || $app->enquiry_subcategory3 == '0'){

                     $enq_sub_cat3 = DB::table('enquiry_categories')->where('id_enquiry_category',$app->enquiry_subcategory3)->first();

                    if(count($enq_sub_cat3) > 0){
                      $enq_subcategory3 = ", ".$enq_sub_cat3->category_name;
                    }
                     }
                    if(count($enq_cat) > 0){
                      $enq_category = $enq_cat->category_name;
                    }
                    if(count($enq_sub_cat) > 0){
                      $enq_subcategory = $enq_sub_cat->category_name;
                    }

                               
                    $listnames = VicidialLists::select('list_name')->where('list_id',$app->id_list)->get();
                    $listname =  '';
                    $listid =  $app->id_list;
                    if(count($listnames) > 0){
                        
                        if($listid == '999'){
                            $listname =  ' Incoming';
                        }
                        else{
                            $listname =  ' Outgoing - '.$listnames[0]->list_name;
                        }
                    } 

                            $brand = '';
                            $interest = '';
                            $showroom = '';
                            $salesman = '';
                            $servicecenter = '';
                            $advisorname = '';
                            $source = '';
                            $appdate = '';
                            $apptime = '';
                            $apptype = '';
                            $appcode = '';
                        if($app->appointment_booked =='Yes'){
                          $appdetail = DB::table('appointments')->where('opp_id',$app->id_opp)->first();
                        if($appdetail){
                            $brand = $appdetail->brand;
                            $interest = $appdetail->interest;
                            $showroom = $appdetail->showroom;
                            $salesman = $appdetail->salesman;
                            $servicecenter = $appdetail->servicecenter;
                            $advisorname = $appdetail->advisorname;
                            $source = $appdetail->source_name;
                            $appdate = $appdetail->appointment_date;
                            $apptime = $appdetail->appointment_time;
                            $apptype = $appdetail->appointmenttype;
                            $appcode = $appdetail->appointmentcode;
                        }
                        }

        $expname = $enq_category;
            $exports[] = array('#' => $app->id_opp,'Name' => $app->first_name." ".$app->last_name,'Mobile Number' => $app->mobile_number,'Call Type' => $listname,'Id Agent' => $app->id_agent,'Categories' => $enq_category,'Sub Category' => $enq_subcategory." ".$enq_subcategory2." ".$enq_subcategory3,'Description' => $app->description,'Campaign' => $app->campaign_id,'Date Added' => $app->date_add,'Appointment Booked' => $app->appointment_booked,'Source of Business' => $source,'Brand' => $brand,'Model' => $interest,'Showroom' => $showroom,'Salesman' => $salesman,'Service Center' => $servicecenter,'Advisor Name' => $advisorname,'Appointment Date' => $appdate,'Appointment Time' => $apptime,'Appointment Type' => $apptype,'Appointment Code' => $appcode );
            }

        }

        if($request->exporttype == 'outbound'){
        $dial_logs = VicidialLog::whereBetween('call_date',[$request->fromdate, $request->todate])->where('status',$request->list_id);
        if(!empty($campaignids)){
            $dial_logs = $dial_logs->whereIn('campaign_id',explode(",", $campaignids));
        }
        $dial_logs = $dial_logs->get();

            foreach ($dial_logs as $log) {

            $listnames = VicidialLists::select('list_name')->where('list_id',$log->list_id)->get();
            $listname =  'ListName';
            if(count($listnames) > 0){
               $listname =  $listnames[0]->list_name;
            } 

        $expname = 'Outbound';

            $exports[] = array('Lead Id' => $log->lead_id,'Phone' => $log->phone_number,'Campaign' => $log->campaign_id,'List Name' => $listname,'Call Date' => $log->call_date,'Status' => $log->status,'User' => $log->user,'Length' => Average::toMinutes($log->length_in_sec),'Dial' => $log->alt_dial );

            }

        }
        else{
        $dial_lists = VicidialList::whereBetween('modify_date',[$request->fromdate, $request->todate])->where('lead_id','>','0')->where('list_id',$request->list_id)->get();
    
        //print_r($dial_lists); exit();

            $listnames = VicidialLists::select('list_name')->where('list_id',$request->list_id)->get();
            $listname =  'ListName';
            if(count($listnames) > 0){
               $listname =  $listnames[0]->list_name;
            } 

        $expname = $listname;
            foreach ($dial_lists as $log) {

            $inquiry = DB::table('opportunity')->where('id_process_lead',$log->lead_id)->first();
            if ($inquiry) {
                    $enq_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$inquiry->enquiry_category)->first();
                    $enq_sub_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$inquiry->enquiry_subcategory)->first();
                    $enq_category = '';
                    $enq_subcategory = '';
                    $enq_subcategory2 = '';
                    $enq_subcategory3 = '';

                     if(!empty($inquiry->enquiry_subcategory2) || $inquiry->enquiry_subcategory2 == '0'){

                     $enq_sub_cat2 = DB::table('enquiry_categories')->where('id_enquiry_category',$inquiry->enquiry_subcategory2)->first();

                    if(count($enq_sub_cat2) > 0){
                      $enq_subcategory2 = ", ".$enq_sub_cat2->category_name;
                    }

                    }

                    if(!empty($inquiry->enquiry_subcategory3) || $inquiry->enquiry_subcategory3 == '0'){

                     $enq_sub_cat3 = DB::table('enquiry_categories')->where('id_enquiry_category',$inquiry->enquiry_subcategory3)->first();

                    if(count($enq_sub_cat3) > 0){
                      $enq_subcategory3 = ", ".$enq_sub_cat3->category_name;
                    }
                     }
                    if(count($enq_cat) > 0){
                      $enq_category = $enq_cat->category_name;
                    }
                    if(count($enq_sub_cat) > 0){
                      $enq_subcategory = $enq_sub_cat->category_name;
                    } 

                            $brand = '';
                            $interest = '';
                            $showroom = '';
                            $salesman = '';
                            $servicecenter = '';
                            $advisorname = '';
                            $source = '';
                            $appdate = '';
                            $apptime = '';
                            $apptype = '';
                            $appcode = '';
                        if($inquiry->appointment_booked =='Yes'){
                          $appdetail = DB::table('appointments')->where('opp_id',$inquiry->id_opp)->first();
                        if($appdetail){
                            $brand = $appdetail->brand;
                            $interest = $appdetail->interest;
                            $showroom = $appdetail->showroom;
                            $salesman = $appdetail->salesman;
                            $servicecenter = $appdetail->servicecenter;
                            $advisorname = $appdetail->advisorname;
                            $source = $appdetail->source_name;
                            $appdate = $appdetail->appointment_date;
                            $apptime = $appdetail->appointment_time;
                            $apptype = $appdetail->appointmenttype;
                            $appcode = $appdetail->appointmentcode;
                        }
                        }

            $exports[] = array('Lead Id' => $log->lead_id,'Entry Date' => $log->entry_date,'Phone' => $log->phone_number,'List Name' => $listname,'Status' => $log->status,'User' => $log->user,'Call Count' => $log->called_count,'Enq Id' => $inquiry->id_opp,'Name' => $inquiry->first_name." ".$inquiry->last_name,'Mobile Number' => $inquiry->mobile_number,'Call Type' => $listname,'Id Agent' => $inquiry->id_agent,'Categories' => $enq_category,'Sub Category' => $enq_subcategory." ".$enq_subcategory2." ".$enq_subcategory3,'Description' => $inquiry->description,'Campaign' => $inquiry->campaign_id,'Date Added' => $inquiry->date_add,'Appointment Booked' => $inquiry->appointment_booked,'Source of Business' => $source,'Brand' => $brand,'Model' => $interest,'Showroom' => $showroom,'Salesman' => $salesman,'Service Center' => $servicecenter,'Advisor Name' => $advisorname,'Appointment Date' => $appdate,'Appointment Time' => $apptime,'Appointment Type' => $apptype,'Appointment Code' => $appcode );

            }
            else{
            $exports[] = array('Lead Id' => $log->lead_id,'Entry Date' => $log->entry_date,'Phone' => $log->phone_number,'List Name' => $listname,'Status' => $log->status,'User' => $log->user,'Call Count' => $log->called_count,'Enq Id' => "",'Name' => "",'Mobile Number' => "",'Call Type' => "",'Id Agent' => "",'Categories' => "",'Sub Category' => "",'Description' => "",'Campaign' => "",'Date Added' => "",'Appointment Booked' => "",'Source of Business' => "",'Brand' => "",'Model' => "",'Showroom' => "",'Salesman' => "",'Service Center' => "",'Advisor Name' => "",'Appointment Date' => "",'Appointment Time' => "",'Appointment Type' => "",'Appointment Code' => "" );

            }

            }
        }

            $type = 'xlsx';

            $data = array();
            foreach ($exports as $result) {
            $data[] = (array)$result; 
            }
                Excel::create($expname.' - Dialer Leads Details', function($excel) use($data) {

                $excel->sheet('Sheetname', function($sheet) use($data) {

                $sheet->fromArray($data);

                  });

                })->export('xlsx');
    }

}
