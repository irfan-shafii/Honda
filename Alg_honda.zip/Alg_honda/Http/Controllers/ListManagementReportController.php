<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
use App\VicidialList;
use App\VicidialCloserLog;
use App\VicidialLog;
use App\VicidialLists;
use App\VicidialCampaign;
use Excel;

class ListManagementReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $list_id = '';
        $status = '';
        $batchno = '';
        $fromdate = date("Y-m-d");
        if (!empty($request->fromdate)) {
            $fromdate = date('Y-m-d',strtotime($request->fromdate));
        }

        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
        $campaignids = Session::get('campaignid');

        //print_r($fromdate); exit();

        VicidialList::where('user','VDAD')->where('status','Answer')->update(['status'=>'NA']);
        if(!empty($fromdate)){
        $currentdate = date("Y-m-d");
        $currentdate1 = date('Y-m-d', strtotime("+1 day", strtotime($currentdate)));
        $nadrop = 'NA,DROP,B,DA';
        $droplists = VicidialList::select('phone_number','status','modify_date','lead_id')->whereBetween('modify_date',[$currentdate, $currentdate1])->whereIn('status',explode(",", $nadrop))->get();
        //print_r($droplists); exit();
        foreach($droplists as $droplist){
            $status_answer = VicidialCloserLog::where('phone_number',$droplist->phone_number)->where('call_date','>',$droplist->modify_date)->where('status','!=','DROP')->where('length_in_sec','>','0')->first();
            //$status_log = VicidialLog::where('phone_number',$droplist->phone_number)->where('call_date','>',$droplist->modify_date)->where('length_in_sec','>','0')->first();
            if($status_answer){
                VicidialList::where('lead_id',$droplist->lead_id)->update(['status'=>'Answer','user'=>$status_answer->user]);
             }

        }
    	}


        $listids = '';
        if(!empty($campaignids)){
            $lists = VicidialLists::select('list_id','list_name','campaign_id')->whereIn('campaign_id',explode(",", $campaignids))->get();
            if(count($lists) > 0) {
                foreach ($lists as $list) {
                    $listgrps[] = $list->list_id;
                }
            $listids = implode(",", $listgrps);
            }
        }

        $list_ids = VicidialLists::select('list_id','list_name','campaign_id');
        if(!empty($campaignids)){
            $list_ids = $list_ids->whereIn('list_id',explode(",", $listids));
        }
        $list_ids = $list_ids->orderBY('list_name','asc')->get();

        $statuses = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->select(DB::raw('count(*) as status_count, status'))->groupBy('status')->get();

        $batches = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('lead_id','>','0')->where('batchno','!=','')->select('batchno', DB::raw('count(*) as batches'))->groupBy('batchno')->get();

        $dial_lists = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('lead_id','>','0');

        if(!empty($campaignids)){
            $dial_lists = $dial_lists->whereIn('list_id',explode(",", $listids));
        }
        if(!empty($request->list_id)){

        $list_id = intval($request->list_id);
            $dial_lists = $dial_lists->where('list_id',$list_id);
        $batches = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$list_id)->where('lead_id','>','0')->where('batchno','!=','')->select('batchno', DB::raw('count(*) as batches'))->groupBy('batchno')->get();
        }
        if(!empty($request->batchno)){
        $batchno = $request->batchno;
            $dial_lists = $dial_lists->where('batchno',$batchno);
        }
        if(!empty($request->status)){
            $status = implode(",", $request->status);
            $list_id = intval($request->list_id);
            if($status == 'answer'){
                $status = 'answer,NI,N,SALE,PU';
            }

            $dial_lists = $dial_lists->whereIn('status',explode(",", $status));
            //print_r($dial_lists);exit();
        }


            if($request->clearstatus == '1'){
                $dial_lists->delete();
            }
            if($request->resetstatus == '1'){
                $dial_lists->update(['called_since_last_reset'=>'N','status'=>'NEW']);
            }

            $dial_lists = $dial_lists->get();  
            $dial_lists_count = $dial_lists->count();  
            //print_r($dial_lists); exit();

        $exports = array();
        if($request->exportstatus == '1'){
            //print_r($dial_lists);exit();


            foreach ($dial_lists as $log) {

            $listnames = VicidialLists::select('list_name')->where('list_id',$log->list_id)->get();
            $listname =  'ListName';
            if(count($listnames) > 0){
               $listname =  $listnames[0]->list_name;
            }

            $inquiry = DB::table('opportunity')->where('id_process_lead',$log->lead_id)->first();
            if ($inquiry) {
                    $enq_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$inquiry->enquiry_category)->first();
                    $enq_sub_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$inquiry->enquiry_subcategory)->first();
                    $enq_category = '';
                    $enq_subcategory = '';
                    $enq_subcategory2 = '';
                    $enq_subcategory3 = '';

                     if(!empty($inquiry->enquiry_subcategory2) || $inquiry->enquiry_subcategory2 == '0'){

                     $enq_sub_cat2 = DB::table('enquiry_categories')->where('id_enquiry_category',$inquiry->enquiry_subcategory2)->first();

                    if(count($enq_sub_cat2) > 0){
                      $enq_subcategory2 = ", ".$enq_sub_cat2->category_name;
                    }

                    }

                    if(!empty($inquiry->enquiry_subcategory3) || $inquiry->enquiry_subcategory3 == '0'){

                     $enq_sub_cat3 = DB::table('enquiry_categories')->where('id_enquiry_category',$inquiry->enquiry_subcategory3)->first();

                    if(count($enq_sub_cat3) > 0){
                      $enq_subcategory3 = ", ".$enq_sub_cat3->category_name;
                    }
                     }
                    if(count($enq_cat) > 0){
                      $enq_category = $enq_cat->category_name;
                    }
                    if(count($enq_sub_cat) > 0){
                      $enq_subcategory = $enq_sub_cat->category_name;
                    } 

                            $brand = '';
                            $interest = '';
                            $showroom = '';
                            $salesman = '';
                            $servicecenter = '';
                            $advisorname = '';
                            $source = '';
                            $appdate = '';
                            $apptime = '';
                            $apptype = '';
                            $appcode = '';
                        if($inquiry->appointment_booked =='Yes'){
                          $appdetail = DB::table('appointments')->where('opp_id',$inquiry->id_opp)->first();
                        if($appdetail){
                            $brand = $appdetail->brand;
                            $interest = $appdetail->interest;
                            $showroom = $appdetail->showroom;
                            $salesman = $appdetail->salesman;
                            $servicecenter = $appdetail->servicecenter;
                            $advisorname = $appdetail->advisorname;
                            $source = $appdetail->source_name;
                            $appdate = $appdetail->appointment_date;
                            $apptime = $appdetail->appointment_time;
                            $apptype = $appdetail->appointmenttype;
                            $appcode = $appdetail->appointmentcode;
                        }
                        }

            $exports[] = array('Lead Id' => $log->lead_id,'Entry Date' => $log->entry_date,'Phone' => $log->phone_number,'List Name' => $listname,'Status' => $log->status,'User' => $log->user,'Call Count' => $log->called_count,'Enq Id' => $inquiry->id_opp,'Name' => $inquiry->first_name." ".$inquiry->last_name,'Mobile Number' => $inquiry->mobile_number,'Call Type' => $listname,'Id Agent' => $inquiry->id_agent,'Categories' => $enq_category,'Sub Category' => $enq_subcategory." ".$enq_subcategory2." ".$enq_subcategory3,'Description' => $inquiry->description,'Campaign' => $inquiry->campaign_id,'Date Added' => $inquiry->date_add,'Appointment Booked' => $inquiry->appointment_booked,'Source of Business' => $source,'Brand' => $brand,'Model' => $interest,'Showroom' => $showroom,'Salesman' => $salesman,'Service Center' => $servicecenter,'Advisor Name' => $advisorname,'Appointment Date' => $appdate,'Appointment Time' => $apptime,'Appointment Type' => $apptype,'Appointment Code' => $appcode );

            }
            else{
            $exports[] = array('Lead Id' => $log->lead_id,'Entry Date' => $log->entry_date,'Phone' => $log->phone_number,'List Name' => $listname,'Status' => $log->status,'User' => $log->user,'Call Count' => $log->called_count,'Enq Id' => "",'Name' => "",'Mobile Number' => "",'Call Type' => "",'Id Agent' => "",'Categories' => "",'Sub Category' => "",'Description' => "",'Campaign' => "",'Date Added' => "",'Appointment Booked' => "",'Source of Business' => "",'Brand' => "",'Model' => "",'Showroom' => "",'Salesman' => "",'Service Center' => "",'Advisor Name' => "",'Appointment Date' => "",'Appointment Time' => "",'Appointment Type' => "",'Appointment Code' => "" );

            }



            }

            $type = 'xlsx';

            $data = array();
            foreach ($exports as $result) {
            $data[] = (array)$result; 
            }
                Excel::create('Dialer Leads Details', function($excel) use($data) {

                $excel->sheet('Sheetname', function($sheet) use($data) {

                $sheet->fromArray($data);

                  });

                })->export('xlsx');
        }

        return view('list.index',compact('dial_lists','fromdate','phone','user','status','list_id','dial_lists_count','list_ids','statuses','batchno','batches'));
    }

    public function resetid($userids)
    {
        $lead_ids = explode(",", $userids);
        foreach ($lead_ids as $lead) {
        VicidialList::where('list_id',$lead)->update(['status'=>'NEW','called_since_last_reset'=>'N']);
        }
        return redirect('/leads/list');
    }

    public function status(Request $request)
    {
        //print_r($request->all()); exit();
        $list_id = '';
        $status = '';
        $campaign_id = '';
        $campaignids = Session::get('campaignid');


        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y')->get();

        $listids = '';
            $lists = VicidialLists::select('list_id','list_name','campaign_id','list_description','active')->get();
        if(!empty($campaignids)){
            $lists = $lists->whereIn('campaign_id',explode(",", $campaignids));
            if(count($lists) > 0) {
                foreach ($lists as $list) {
                    $listgrps[] = $list->list_id;
                }
            $listids = implode(",", $listgrps);
            }
        }
        if(!empty($request->campaigns)){
            $campaign_id = $request->campaigns;
            $lists = $lists->where('campaign_id',$campaign_id);
        }
        return view('list.status',compact('lists','fromdate','todate','status','campaign_id','campaigns'));
    }


    public function batch(Request $request)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
    //print_r($request->all()); exit();
        $fromdate = date("Y-m-d");
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
        $campaign_id = '';
        $list_id = '';
        $batchno = '';
        $campaignids = Session::get('campaignid');
        $listids = '';
        if(!empty($campaignids)){
            $lists = VicidialLists::select('list_id','list_name','campaign_id')->whereIn('campaign_id',explode(",", $campaignids))->get();
            if(count($lists) > 0) {
                foreach ($lists as $list) {
                    $listgrps[] = $list->list_id;
                }
            $listids = implode(",", $listgrps);
            }
        }

        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y');
        $lists = VicidialLists::select('list_id','list_name','campaign_id');
        $target_lists = DB::table('target_batches');
        if(!empty($request->campaigns)){
            $campaign_id = $request->campaigns;
        $target_lists = $target_lists->where('campaign_id',$campaign_id);
        }
        if(!empty($request->lists)){
            $list_id = $request->lists;
        $target_lists = $target_lists->where('list_id',$list_id);
        }
        if(!empty($request->batchno)){
            $batchno = $request->batchno;
        $target_lists = $target_lists->where('batchno',$batchno);
        }
        //print_r($listids); exit();
        if(!empty($campaignids)){
            $lists = $lists->whereIn('list_id',explode(",", $listids));
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
        $target_lists = $target_lists->whereIn('list_id',explode(",", $listids));
        $batches = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->whereIn('list_id',explode(",", $listids))->where('lead_id','>','0')->where('batchno','!=','')->select('batchno', DB::raw('count(*) as batches'))->groupBy('batchno')->get();
        }
        else{
        $batches = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('lead_id','>','0')->where('batchno','!=','')->select('batchno', DB::raw('count(*) as batches'))->groupBy('batchno')->get();
        }
        $target_lists = $target_lists->orderBy('id','desc')->get();
        $campaigns = $campaigns->orderBY('campaign_name','asc')->get();
        $lists = $lists->orderBY('list_name','asc')->get();
        //print_r($lists); exit();
        return view('list.batch',compact('campaigns','lists','batches','batchno','target_lists','campaign_id','list_id','totaltarget'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
