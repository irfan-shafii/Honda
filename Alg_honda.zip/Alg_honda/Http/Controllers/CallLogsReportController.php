<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
use App\VicidialLog;
use App\VicidialCloserLog;
use App\VicidialDialLog;
use App\VicidialIngroup;
use App\VicidialCampaign;
use App\Average;
use App\VicidialLists;
use Excel;

class CallLogsReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $current_date = date('Y-m-d');
        //$current_date = '2019-11-17';
        $fromdate = date('Y-m-d');
        $todate = date('Y-m-d');
        $phone = '';
        $campaigns1  = '';
        $campaignids = Session::get('campaignid');

        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts1 = explode('-',$todate);
            $todate = $parts1[2] . '-' . $parts1[0] . '-' . $parts1[1];
        }
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));

        $dial_logs = VicidialLog::whereBetween('call_date',[$fromdate, $todate1]);
        if(!empty($campaignids)){
            $dial_logs = $dial_logs->whereIn('campaign_id',explode(",", $campaignids));
        }


        if(!empty($request->campaigns1)){
        if (count($request->campaigns1) > 0) {
        $campaigns1 = implode(",", $request->campaigns1);
            $dial_logs = $dial_logs->whereIn('campaign_id',explode(",", $campaigns1));
        }
        }

        if(!empty($request->phone)){
            $phone = $request->phone;
            $dial_logs = $dial_logs->where('phone_number',$phone);
        }

        $dial_logs = $dial_logs->get();

        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y');

        if(!empty($campaignids)){
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
        }
        $campaigns = $campaigns->get();



        $exports = array();
        if($request->exportstatus == '1'){


            foreach ($dial_logs as $log) {

            $listnames = VicidialLists::select('list_name')->where('list_id',$log->list_id)->get();
            $listname =  'ListName';
            if(count($listnames) > 0){
               $listname =  $listnames[0]->list_name;
            } 

            $exports[] = array('Lead Id' => $log->lead_id,'Phone' => $log->phone_number,'Campaign' => $log->campaign_id,'List Name' => $listname,'Call Date' => $log->call_date,'Status' => $log->status,'User' => $log->user,'Length' => Average::toMinutes($log->length_in_sec),'Dial' => $log->alt_dial );

            }

            $type = 'xlsx';

            $data = array();
            foreach ($exports as $result) {
            $data[] = (array)$result; 
            }
                Excel::create('Call Log Outbound Details', function($excel) use($data) {

                $excel->sheet('Sheetname', function($sheet) use($data) {

                $sheet->fromArray($data);

                  });

                })->export('xlsx');
            }

        //print_r($dial_logs); exit();
        return view('callLog.index',compact('dial_logs','fromdate','todate','phone','campaigns','campaigns1'));
    }

    public function inbound(Request $request)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $current_date = date('Y-m-d');
        //$current_date = '2019-11-17';
        $fromdate = date('Y-m-d');
        $todate = date('Y-m-d');
        $phone = '';
        $ingroups1 = '';
        $campaignids = Session::get('campaignid');


        $ingroupids = '';
        if(!empty($campaignids)){
            $ingroups = DB::table('user_campaigns')->select('campaigns','ingroups')->whereIn('campaigns',explode(",", $campaignids))->get();
            if(count($ingroups) > 0) {
                foreach ($ingroups as $ing) {
                    $ingrps[] = $ing->ingroups;
                }
            $ingroupids = implode(",", $ingrps);
            //print_r($ingroupids); exit();
            }
        }

        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts1 = explode('-',$todate);
            $todate = $parts1[2] . '-' . $parts1[0] . '-' . $parts1[1];
        }
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));
        $dial_logs = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','!=','DROP');
        if(!empty($campaignids)){
            $dial_logs = $dial_logs->whereIn('campaign_id',explode(",", $ingroupids));
        }

        if(!empty($request->groups)){
        if (count($request->groups) > 0) {
        $ingroups1 = implode(",", $request->groups);
            $dial_logs = $dial_logs->whereIn('campaign_id',explode(",", $ingroups1));
        }
        }

        $dial_logs = $dial_logs->orderBY('closecallid','desc')->get();

        if(!empty($request->phone)){
            $phone = $request->phone;
            $dial_logs = $dial_logs->where('phone_number',$phone);
        }


        $ingroups = VicidialIngroup::select('group_id','group_name')->get();
        if(!empty($campaignids)){
            $ingroups = $ingroups->whereIn('group_id',explode(",", $ingroupids));
        }
        //print_r($dial_logs); exit();

        $exports = array();
        if($request->exportstatus == '1'){


            foreach ($dial_logs as $log) {

            $listnames = VicidialLists::select('list_name')->where('list_id',$log->list_id)->get();
            $listname =  'ListName';
            if(count($listnames) > 0){
               $listname =  $listnames[0]->list_name;
            } 

            $exports[] = array('Lead Id' => $log->lead_id,'Phone' => $log->phone_number,'Ingroup' => $log->campaign_id,'List Name' => $listname,'Call Date' => $log->call_date,'Status' => $log->status,'User' => $log->user,'Length' => Average::toMinutes($log->length_in_sec) );

            }

            $type = 'xlsx';

            $data = array();
            foreach ($exports as $result) {
            $data[] = (array)$result; 
            }
                Excel::create('Call Log Inbound Details', function($excel) use($data) {

                $excel->sheet('Sheetname', function($sheet) use($data) {

                $sheet->fromArray($data);

                  });

                })->export('xlsx');
            }

        return view('callLog.inbound',compact('dial_logs','fromdate','todate','phone','ingroups','ingroups1'));
    }

    public function missed(Request $request)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $current_date = date('Y-m-d');
        //$current_date = '2019-11-17';
        $fromdate = date('Y-m-d');
        $todate = date('Y-m-d');
        $phone = '';
        $ingroups1 = '';
        $listid = '';
        $campaignids = Session::get('campaignid');

        $ingroupids = '';
        if(!empty($campaignids)){
            $ingroups = DB::table('user_campaigns')->select('campaigns','ingroups')->whereIn('campaigns',explode(",", $campaignids))->get();
            if(count($ingroups) > 0) {
                foreach ($ingroups as $ing) {
                    $ingrps[] = $ing->ingroups;
                }
            $ingroupids = implode(",", $ingrps);
            //print_r($ingroupids); exit();
            }
        }


        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts1 = explode('-',$todate);
            $todate = $parts1[2] . '-' . $parts1[0] . '-' . $parts1[1];
        }
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));
            $mstatus = 'DROP,NANQUE';
        $dial_logs = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->whereIn('status',explode(",", $mstatus));

        if(!empty($campaignids)){
            $dial_logs = $dial_logs->whereIn('campaign_id',explode(",", $ingroupids));
        }

        if(!empty($request->groups)){
        if (count($request->groups) > 0) {
        $ingroups1 = implode(",", $request->groups);
            $dial_logs = $dial_logs->whereIn('campaign_id',explode(",", $ingroups1));
        }
        }


        if(!empty($request->phone)){
            $phone = $request->phone;
            $dial_logs = $dial_logs->where('phone_number',$phone);
        }

        if(!empty($request->listid)){
            $listid = $request->listid;
            $dial_logs = $dial_logs->where('list_id',$listid);
        }

        $dial_logs = $dial_logs->orderBY('closecallid','desc')->get();

        $total_count=count($dial_logs);
        $missed_count=0;
        foreach($dial_logs as $mlog){
        $status_answer = VicidialCloserLog::where('phone_number',$mlog->phone_number)->where('call_date','>',$mlog->call_date)->where('closecallid','>',$mlog->closecallid)->where('status','!=','DROP')->where('length_in_sec','>','0')->count();
        $status_log = VicidialLog::where('phone_number',$mlog->phone_number)->where('call_date','>',$mlog->call_date)->where('length_in_sec','>','0')->count();

        if($status_answer == 0 && $status_log == 0 ){
        $missed_count++;
        }

        }

        $ingroups = VicidialIngroup::select('group_id','group_name')->get();
        if(!empty($campaignids)){
            $ingroups = $ingroups->whereIn('group_id',explode(",", $ingroupids));
        }
        //print_r($dial_logs); exit();
        
        $exports = array();
        if($request->exportstatus == '1'){


            foreach ($dial_logs as $log) {

            $listnames = VicidialLists::select('list_name')->where('list_id',$log->list_id)->get();
            $listname =  'ListName';
            if(count($listnames) > 0){
               $listname =  $listnames[0]->list_name;
            } 

            $exports[] = array('Lead Id' => $log->lead_id,'Phone' => $log->phone_number,'Ingroup' => $log->campaign_id,'List Name' => $listname,'Call Date' => $log->call_date,'Status' => $log->status,'User' => $log->user,'Length' => Average::toMinutes($log->length_in_sec) );

            }

            $type = 'xlsx';

            $data = array();
            foreach ($exports as $result) {
            $data[] = (array)$result; 
            }
                Excel::create('Call Log Missed Details', function($excel) use($data) {

                $excel->sheet('Sheetname', function($sheet) use($data) {

                $sheet->fromArray($data);

                  });

                })->export('xlsx');
            }

            $fname = ''; 
            $rec_count = 0;
            $answer = 0;
            $callbk = 0;
            $answer1 = 0;

        if($request->uploadstatus == '1'){   
            foreach($dial_logs as $droplist){
                $status_answer = VicidialCloserLog::where('phone_number',$droplist->phone_number)->where('call_date','>',$droplist->call_date)->where('status','!=','DROP')->where('length_in_sec','>','0')->count();
                $status_log = VicidialLog::where('phone_number',$droplist->phone_number)->where('call_date','>',$droplist->call_date)->where('length_in_sec','>','0')->count();
                if($status_answer == '0' && $status_log == '0'){
                    //print_r($droplist->phone_number);
                    if(!empty($request->listid)){
                        VicidialList::where('lead_id',$droplist->lead_id)->where('list_id',$request->listid)->where('phone_number',$droplist->phone_number)->update(['status'=>'NEW','called_since_last_reset'=>'N']);
                    //print_r($droplist->lead_id." - Answer "."<br>");
                        $rec_count++;
                    }
                 }
                 else if($status_answer > 0 ){
                    $answer++;

                 }
                 else if($status_log > 0 ){
                    $callbk++;

                 }
                 else{
                    $answer1++;
                 }

            }
        }

        if($rec_count > 0){
            $alert = $rec_count." Records Added Successfully";
        }
        else{
            $alert = '';
        }

            $lists = VicidialLists::select('list_id','list_name','campaign_id')->get();
        return view('callLog.missed',compact('dial_logs','fromdate','todate','phone','missed_count','total_count','ingroups','ingroups1','lists','listid','alert'));
    }

    public function call_log(Request $request)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $current_date = date('Y-m-d');
        //$current_date = '2019-11-17';
        $fromdate = date('Y-m-d');
        $todate = date('Y-m-d');
        $phone = '';
        $campaignids = Session::get('campaignid');



        $ingroupids = '';
        if(!empty($campaignids)){
            $ingroups = DB::table('user_campaigns')->select('campaigns','ingroups')->whereIn('campaigns',explode(",", $campaignids))->get();
            if(count($ingroups) > 0) {
                foreach ($ingroups as $ing) {
                    $ingrps[] = $ing->ingroups;
                }
            $ingroupids = implode(",", $ingrps);
            //print_r($ingroupids); exit();
            }
        }

        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts1 = explode('-',$todate);
            $todate = $parts1[2] . '-' . $parts1[0] . '-' . $parts1[1];
        }
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));
        $outbounds = VicidialLog::whereBetween('call_date',[$fromdate, $todate1]);

        if(!empty($campaignids)){
            $outbounds = $outbounds->whereIn('campaign_id',explode(",", $campaignids));
        }
        $outbounds = $outbounds->paginate(100);
            $mstatus = 'DROP,NANQUE';
        $missed = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->whereIn('status',explode(",", $mstatus));
        $inbounds = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','!=','DROP');
        if(!empty($campaignids)){
            $missed = $missed->whereIn('campaign_id',explode(",", $ingroupids));
            $inbounds = $inbounds->whereIn('campaign_id',explode(",", $ingroupids));
        }
        $missed = $missed->orderBY('closecallid','desc')->get();
        $inbounds = $inbounds->orderBY('closecallid','desc')->get();

        //print_r($outbounds); exit();
        if(!empty($request->phone)){
            $phone = $request->phone;
            $outbounds = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->where('phone_number',$phone)->paginate(100);
            $missed = $missed->where('phone_number',$phone);
            $inbounds = $inbounds->where('phone_number',$phone);
        }
        //print_r($dial_logs); exit();
        return view('callLog.all',compact('outbounds','inbounds','missed','fromdate','todate','phone'));
    }
    public function callapi()
    {
        return view('callLog.callapi');
    }
    public function callapi2()
    {
        return view('callLog.callapi2');
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
